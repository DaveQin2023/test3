```mermaid
---
config:
  flowchart:
    curve: linear
---
graph TD;
	__start__([<p>__start__</p>]):::first
	list_files(list_files)
	select_next_file(select_next_file)
	read_file(read_file)
	summarize_file(summarize_file)
	append_summary(append_summary)
	__end__([<p>__end__</p>]):::last
	__start__ --> list_files;
	append_summary --> select_next_file;
	list_files --> select_next_file;
	read_file --> summarize_file;
	select_next_file -. &nbsp;END&nbsp; .-> __end__;
	select_next_file -.-> read_file;
	summarize_file --> append_summary;
	select_next_file -.-> select_next_file;
	classDef default fill:#f2f0ff,line-height:1.2
	classDef first fill-opacity:0
	classDef last fill:#bfb6fc

```
