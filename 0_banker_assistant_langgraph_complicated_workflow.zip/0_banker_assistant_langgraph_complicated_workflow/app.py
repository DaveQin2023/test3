# app.py
import os
from typing import TypedDict, Annotated, List, Dict, Any, Union
from langgraph.graph import StateGraph, END
from enum import Enum
import json # For saving dynamic config
from openai import OpenAI


# Import all tools
# CRITICAL: Ensure these functions are correctly defined and exported in tools.py
from tools import (
    list_all_files_recursively, read_file_content, append_to_summary_file,
    summarize_content, load_summarization_config, get_dynamic_prompt,
    evaluate_summary, generate_config_from_request,
    search_files_tool,
    search_emails_tool, read_email_tool, summarize_email_tool,
    get_client_data_tool, get_opportunity_data_tool,
    search_confluence_tool, read_confluence_page_tool, summarize_confluence_tool,
    add_todo_tool, list_todos_tool, mark_todo_complete_tool,
    generate_insights_tool,
    product_recommendation_tool, client_approach_recommendation_tool
)

# --- Define Intents (for Intent_Classifier_Node) ---
class Intent(str, Enum):
    """Enumeration of possible user intents."""
    SUMMARIZE_DOCUMENT = "SUMMARIZE_DOCUMENT"
    SEARCH_FILE = "SEARCH_FILE"
    SEARCH_EMAIL = "SEARCH_EMAIL"
    READ_EMAIL_CONTENT = "READ_EMAIL_CONTENT"
    SUMMARIZE_EMAIL = "SUMMARIZE_EMAIL"
    GET_SALESFORCE_CLIENT_DATA = "GET_SALESFORCE_CLIENT_DATA"
    GET_SALESFORCE_OPPORTUNITY_DATA = "GET_SALESFORCE_OPPORTUNITY_DATA"
    SEARCH_CONFLUENCE = "SEARCH_CONFLUENCE"
    READ_CONFLUENCE_PAGE = "READ_CONFLUENCE_PAGE"
    SUMMARIZE_CONFLUENCE = "SUMMARIZE_CONFLUENCE"
    ADD_TODO = "ADD_TODO"
    LIST_TODOS = "LIST_TODOS"
    MARK_TODO_COMPLETE = "MARK_TODO_COMPLETE"
    GENERATE_INSIGHTS = "GENERATE_INSIGHTS"
    GET_PRODUCT_RECOMMENDATION = "GET_PRODUCT_RECOMMENDATION"
    GET_CLIENT_APPROACH_RECOMMENDATION = "GET_CLIENT_APPROACH_RECOMMENDATION"
    UNKNOWN = "UNKNOWN"
    COMBINE_DATA_AND_INSIGHTS = "COMBINE_DATA_AND_INSIGHTS"


# --- Agent State (Comprehensive) ---
class AgentState(TypedDict):
    """
    Represents the comprehensive state of the banker assistant's workflow.
    """
    user_request: str # The initial raw request from the banker
    intent: Intent # Classified intent of the user's request
    task_details: Dict[str, Any] # Parameters extracted for the specific task

    # Data sources for processing/retrieval
    base_directory: str # For file system operations
    summarization_config: Dict # Dynamic configuration for summarization prompts

    # Intermediate data for file summarization sub-workflow
    all_files: Annotated[List[str], []]
    files_to_process_for_summary: Annotated[List[str], []] # Renamed from txt_files_to_process for clarity
    current_file: str
    file_content: str
    generated_prompt: str
    summary_quality_check_result: str
    retry_count: int
    summary_accumulator: str # Stores summaries of processed files

    # Data from other tools/sources
    search_results: Annotated[List[str], []] # For file search, email search, confluence search
    email_content: str
    salesforce_data: Dict[str, Any]
    confluence_page_content: str
    todo_list_data: Annotated[List[Dict], []] # For to-do list operations
    combined_data_summary: str # For insights generation
    recommendation_result: str # For product/client data_processor recommendations

    final_response: str # The ultimate response presented to the banker

# --- Nodes ---

# Orchestrator Nodes
def intent_classifier_node(state: AgentState) -> AgentState:
    """
    Classifies the user's request into a specific intent and extracts task details.
    """
    print(f"\n--- Executing intent_classifier_node for request: {state['user_request']} ---")
    user_request = state["user_request"]
    
    # LLM call to classify intent and extract details
    #client = OpenAI()

    apikey='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'


    client = OpenAI(api_key=apikey)

    
    # Define the schema for the LLM's output
    response_schema = {
        "type": "object",
        "properties": {
            "intent": {
                "type": "string",
                "enum": [e.value for e in Intent], # Use values from Intent enum
                "description": "The classified intent of the user's request."
            },
            "task_details": {
                "type": "object",
                "description": "A dictionary of extracted parameters for the intent. e.g., 'query', 'client_id', 'file_path', 'task_description'."
            }
        },
        "required": ["intent", "task_details"]
    }

    prompt_messages = [
        {"role": "system", "content": f"""You are an intelligent assistant for a commercial banker. Your role is to understand the banker's request and classify their intent, extracting all necessary details.

        Available intents and their required/optional parameters:
        - {Intent.SUMMARIZE_DOCUMENT.value}: {{'file_path': 'path/to/document', 'query': 'optional keywords for specific summary'}}
        - {Intent.SEARCH_FILE.value}: {{'directory': 'path/to/search', 'query': 'keywords'}}
        - {Intent.SEARCH_EMAIL.value}: {{'sender': 'email@example.com', 'subject_keywords': 'keyword1, keyword2', 'content_keywords': 'keyword3, keyword4'}}
        - {Intent.READ_EMAIL_CONTENT.value}: {{'email_id': 'unique_email_identifier'}}
        - {Intent.SUMMARIZE_EMAIL.value}: {{'email_content': 'full email text'}}
        - {Intent.GET_SALESFORCE_CLIENT_DATA.value}: {{'client_id': 'client_id'}}
        - {Intent.GET_SALESFORCE_OPPORTUNITY_DATA.value}: {{'client_id': 'client_id', 'opportunity_id': 'optional_id'}}
        - {Intent.SEARCH_CONFLUENCE.value}: {{'query': 'search terms'}}
        - {Intent.READ_CONFLUENCE_PAGE.value}: {{'page_id': 'confluence_page_id'}}
        - {Intent.SUMMARIZE_CONFLUENCE.value}: {{'page_content': 'full page text'}}
        - {Intent.ADD_TODO.value}: {{'task_description': 'description of task'}}
        - {Intent.LIST_TODOS.value}: {{}}
        - {Intent.MARK_TODO_COMPLETE.value}: {{'task_id': 'id of task to complete'}}
        - {Intent.GENERATE_INSIGHTS.value}: {{'combined_data_summary': 'summary of data to analyze', 'banker_goal': 'optional goal'}}
        - {Intent.GET_PRODUCT_RECOMMENDATION.value}: {{'client_profile': 'summary of client needs', 'product_catalog_summary': 'summary of available products'}}
        - {Intent.GET_CLIENT_APPROACH_RECOMMENDATION.value}: {{'client_history_summary': 'summary of client interactions', 'current_goal': 'optional goal'}}
        - {Intent.COMBINE_DATA_AND_INSIGHTS.value}: {{'data_sources': ['email', 'salesforce', 'files'], 'query': 'keywords for insights'}} (This intent implies fetching data first)
        - {Intent.UNKNOWN.value}: For requests that cannot be classified.

        If a file path or directory is mentioned, assume it's relative to the current working directory or provide a full path if given.
        Your output MUST be a JSON object with 'intent' and 'task_details' keys, strictly following the schema.
        
        Example outputs:
        - Request: "Summarize the Java controller at C:/project/src/UserController.java"
          Output: {{"intent": "SUMMARIZE_DOCUMENT", "task_details": {{"file_path": "C:/project/src/UserController.java"}}}}
        - Request: "Find emails from 'client@example.com' about 'loan agreement'"
          Output: {{"intent": "SEARCH_EMAIL", "task_details": {{"sender": "client@example.com", "subject_keywords": "loan agreement"}}}}
        - Request: "What insights can you get from John Doe's salesforce data and recent emails about him?"
          Output: {{"intent": "COMBINE_DATA_AND_INSIGHTS", "task_details": {{"data_sources": ["salesforce", "email"], "query": "John Doe"}}}}
        - Request: "Add 'Follow up with Bank A for Q3 report' to my to-do list"
          Output: {{"intent": "ADD_TODO", "task_details": {{"task_description": "Follow up with Bank A for Q3 report"}}}}
        - Request: "Recommend a product for a small business client looking for financing"
          Output: {{"intent": "GET_PRODUCT_RECOMMENDATION", "task_details": {{"client_profile": "small business client looking for financing", "product_catalog_summary": "provide available products for context"}}}}
        """},
        {"role": "user", "content": user_request}
    ]

    try:
        response = client.chat.completions.create(
            model="gpt-4o", # Using a more capable model for intent classification
            messages=prompt_messages,
            response_format={"type": "json_object"},
            temperature=0.0 # Keep it deterministic for classification
        )
        
        if response.choices and len(response.choices) > 0 and response.choices[0].message:
            llm_output_str = response.choices[0].message.content
            print(f"LLM Intent Classifier raw output:\n{llm_output_str}")
            parsed_output = json.loads(llm_output_str)
            
            intent = parsed_output.get("intent", Intent.UNKNOWN.value)
            task_details = parsed_output.get("task_details", {})

            return {"intent": Intent(intent), "task_details": task_details}
        else:
            print("Error: No valid intent classification from LLM. Defaulting to UNKNOWN.")
            return {"intent": Intent.UNKNOWN, "task_details": {}}
    except json.JSONDecodeError as e:
        print(f"Error decoding JSON from Intent Classifier LLM: {e}. Raw output: {llm_output_str}")
        return {"intent": Intent.UNKNOWN, "task_details": {}}
    except Exception as e:
        print(f"Error during Intent Classification: {e}")
        return {"intent": Intent.UNKNOWN, "task_details": {}}

# --- Handlers for Specific Intents ---

# File Summarization Sub-workflow Nodes (re-used from previous version)
def list_files_for_summary_node(state: AgentState) -> AgentState:
    """Filters files based on the summarization config for processing."""
    print("\n--- Executing list_files_for_summary_node ---")
    base_dir = state["base_directory"]
    # The 'file_path' can be directly provided in task_details if user requests specific file
    specific_file_path = state["task_details"].get("file_path")
    
    processable_files = []
    if specific_file_path:
        # If a specific file is requested, ensure it exists and is a file
        full_specific_path = os.path.abspath(os.path.join(base_dir, specific_file_path)) # Resolve relative path
        if os.path.exists(full_specific_path) and os.path.isfile(full_specific_path):
            processable_files = [full_specific_path]
            print(f"User requested specific file: {full_specific_path}")
        else:
            print(f"Error: Specified file not found or is not a file: {full_specific_path}")
            # If specific file not found, we should still proceed, but with an empty list
            # The next node (select_next_file_for_summary_node) will handle this.
    else:
        # If no specific file, list all and filter by config
        all_files = list_all_files_recursively(base_dir)
        config_extensions = {ext.lower() for ext in state["summarization_config"].keys() if ext != "default"}
        
        for f in all_files:
            _, file_extension = os.path.splitext(f)
            file_extension_lower = file_extension.lower()

            if file_extension_lower in config_extensions:
                processable_files.append(f)
            elif not file_extension and "default" in state["summarization_config"]:
                if os.path.isfile(f): 
                    processable_files.append(f)

        print(f"Found {len(all_files)} total files, {len(processable_files)} processable files based on config.")

    return {
        "files_to_process_for_summary": processable_files,
        "summary_accumulator": "", # Reset accumulator for each new summarization request
        "processed_files_count": 0,
        "retry_count": 0
    }

def select_next_file_for_summary_node(state: AgentState) -> AgentState:
    """Selects the next file for summarization and resets retry count."""
    print("\n--- Executing select_next_file_for_summary_node ---")
    files_to_process = state.get("files_to_process_for_summary", [])
    if files_to_process:
        next_file = files_to_process.pop(0)
        print(f"Selected file for summarization: {next_file}")
        return {"current_file": next_file, "files_to_process_for_summary": files_to_process, "retry_count": 0}
    else:
        print("No more files for summarization.")
        return {"current_file": ""} # Indicate no more files

def read_file_for_summary_node(state: AgentState) -> AgentState:
    """Reads the content of the current file for summarization."""
    print("\n--- Executing read_file_for_summary_node ---")
    current_file = state["current_file"]
    if current_file:
        content = read_file_content(current_file)
        print(f"Read content from {current_file} (length: {len(content)}).")
        return {"file_content": content}
    return {"file_content": ""} # Ensure file_content is not None

def determine_prompt_for_summary_node(state: AgentState) -> AgentState:
    """Determines the appropriate summarization prompt."""
    print("\n--- Executing determine_prompt_for_summary_node ---")
    current_file = state["current_file"]
    file_content = state["file_content"]
    summarization_config = state["summarization_config"]
    retry_count = state.get("retry_count", 0)

    dynamic_prompt = get_dynamic_prompt(current_file, file_content, summarization_config)
    
    if retry_count > 0:
        print(f"Attempting retry {retry_count} for {os.path.basename(current_file)}. Modifying prompt.")
        dynamic_prompt = f"Previous summary attempt was insufficient. Please provide a more detailed and comprehensive summary for this file, incorporating all key aspects requested in the initial prompt:\n\n{dynamic_prompt}"

    print(f"Generated dynamic prompt for {os.path.basename(current_file)}.")
    return {"generated_prompt": dynamic_prompt}


def summarize_file_content_node(state: AgentState) -> AgentState:
    """Summarizes file content using the generated prompt."""
    print("\n--- Executing summarize_file_content_node ---")
    generated_prompt = state["generated_prompt"]
    current_file = state["current_file"]

    if generated_prompt:
        print(f"Summarizing content for {current_file} using dynamic prompt...")
        summary = summarize_content(generated_prompt)
        print(f"Summary generated for {current_file}.")
        return {"summary_quality_check_result": "", "generated_prompt": "", "file_content": summary} # Store summary in file_content for critical review
    return {"file_content": ""} # Ensure file_content is not None

def critical_review_summary_node(state: AgentState) -> AgentState:
    """Critically reviews the generated summary."""
    print("\n--- Executing critical_review_summary_node ---")
    latest_summary = state["file_content"]
    current_file_path = state["current_file"]
    
    # In a real implementation, you'd pass original content to LLM.
    # For now, pass a placeholder as original_content_placeholder
    original_content_placeholder = "Original content was here, but for critical review, focus on summary coherence relative to file type and initial prompt."
    
    _, file_extension = os.path.splitext(current_file_path)
    file_type_for_eval = file_extension.lstrip('.')
    if not file_type_for_eval and "default" in state["summarization_config"]: # For files with no extension that use default
        file_type_for_eval = "default_file"
    
    print(f"Critically reviewing summary for {os.path.basename(current_file_path)} (Type: {file_type_for_eval})...")
    
    quality_result = evaluate_summary(latest_summary, original_content_placeholder, file_type_for_eval)
    
    print(f"Critical review result for {os.path.basename(current_file_path)}: {quality_result}")
    
    new_retry_count = state.get("retry_count", 0)
    if quality_result == "NEEDS_IMPROVEMENT":
        new_retry_count += 1
        print(f"Summary needs improvement. Incrementing retry_count to {new_retry_count}.")
    else:
        new_retry_count = 0

    return {
        "summary_quality_check_result": quality_result,
        "retry_count": new_retry_count,
        "file_content": latest_summary # Keep the latest summary in file_content for append_summary_node
    }


def collect_and_append_summary_node(state: AgentState) -> AgentState:
    """Appends summary to accumulator and writes to file."""
    print("\n--- Executing collect_and_append_summary_node ---")
    latest_summary = state["file_content"]
    current_file_path = state["current_file"]
    quality_result = state["summary_quality_check_result"]
    
    note = ""
    max_retries = 2 # Should match the max_retries in decide_next_step_after_summarize
    
    if quality_result == "NEEDS_IMPROVEMENT" and state["retry_count"] <= max_retries and state["retry_count"] > 0:
        note = f" (FLAGGED: Needs Improvement, Retried {state['retry_count']} time(s))"
    elif quality_result == "NEEDS_IMPROVEMENT" and state["retry_count"] > max_retries:
        note = f" (FLAGGED: Needs Improvement - Max Retries ({max_retries}) Reached)"
    elif quality_result == "BAD":
        note = " (FLAGGED: Poor Quality Summary)"

    updated_summary_accumulator = state["summary_accumulator"] + f"\n\n--- Summary of {os.path.basename(current_file_path)}{note} ---\n{latest_summary}"

    processed_count = state.get("processed_files_count", 0) + 1
    base_dir = state["base_directory"]

    print(f"Appending final summary for {os.path.basename(current_file_path)} to summary file in {base_dir}.")
    append_to_summary_file(updated_summary_accumulator, base_dir)
    return {"processed_files_count": processed_count, "summary_accumulator": updated_summary_accumulator}

# --- New Specialized Task Nodes ---

def file_search_node(state: AgentState) -> AgentState:
    """Handles file search requests."""
    print(f"\n--- Executing file_search_node ---")
    directory = state["task_details"].get("directory", state["base_directory"])
    query = state["task_details"].get("query")
    if not query:
        return {"final_response": "Error: File search query not provided."}

    results = search_files_tool(directory, query)
    if results:
        response_str = "Found matching files:\n" + "\n".join(results)
    else:
        response_str = f"No files found matching '{query}' in '{directory}'."
    return {"final_response": response_str}

def handle_email_search_node(state: AgentState) -> AgentState:
    """Handles email search requests."""
    print(f"\n--- Executing handle_email_search_node ---")
    sender = state["task_details"].get("sender")
    subject_keywords = state["task_details"].get("subject_keywords")
    content_keywords = state["task_details"].get("content_keywords")

    results = search_emails_tool(sender, subject_keywords, content_keywords)
    if results:
        response_str = "Found emails:\n" + "\n".join([f"ID: {e['id']}, Subject: {e['subject']}" for e in results])
        return {"final_response": response_str, "search_results": results} # Store full email dicts for later use
    else:
        return {"final_response": "No emails found matching your criteria."}

def handle_read_email_node(state: AgentState) -> AgentState:
    """Handles reading specific email content."""
    print(f"\n--- Executing handle_read_email_node ---")
    email_id = state["task_details"].get("email_id")
    if email_id is None: # check for None, as ID can be 0
        return {"final_response": "Error: Email ID not provided."}
    
    try:
        email_id = int(email_id) # Ensure integer ID
    except ValueError:
        return {"final_response": "Error: Invalid Email ID. Please provide a number."}

    content = read_email_tool(email_id)
    if content:
        return {"final_response": f"Content of email {email_id}:\n{content}", "email_content": content}
    else:
        return {"final_response": f"Email with ID {email_id} not found."}

def handle_summarize_email_node(state: AgentState) -> AgentState:
    """Handles summarizing email content."""
    print(f"\n--- Executing handle_summarize_email_node ---")
    email_content = state["task_details"].get("email_content")
    if not email_content and state.get("email_content"): # Use state email_content if not explicitly provided in task_details
        email_content = state["email_content"]
    
    if not email_content:
        return {"final_response": "Error: Email content not provided for summarization."}
    
    summary = summarize_email_tool(email_content)
    return {"final_response": f"Summary of email:\n{summary}"}

def handle_salesforce_client_data_node(state: AgentState) -> AgentState:
    """Handles retrieving Salesforce client data."""
    print(f"\n--- Executing handle_salesforce_client_data_node ---")
    client_id = state["task_details"].get("client_id")
    if not client_id:
        return {"final_response": "Error: Client ID not provided."}
    
    data = get_client_data_tool(client_id)
    if data:
        response_str = f"Salesforce Client Data for {client_id}:\n" + json.dumps(data, indent=2)
        return {"final_response": response_str, "salesforce_data": data}
    else:
        return {"final_response": f"No Salesforce data found for client ID {client_id}."}

def handle_salesforce_opportunity_data_node(state: AgentState) -> AgentState:
    """Handles retrieving Salesforce opportunity data."""
    print(f"\n--- Executing handle_salesforce_opportunity_data_node ---")
    client_id = state["task_details"].get("client_id")
    opportunity_id = state["task_details"].get("opportunity_id")

    if not client_id and not opportunity_id:
        return {"final_response": "Error: Client ID or Opportunity ID not provided."}

    data = get_opportunity_data_tool(client_id, opportunity_id)
    if data:
        response_str = f"Salesforce Opportunity Data for Client {client_id} (Opp ID: {opportunity_id}):\n" + json.dumps(data, indent=2)
        return {"final_response": response_str, "salesforce_data": data}
    else:
        return {"final_response": f"No Salesforce opportunity data found for client ID {client_id} and opportunity ID {opportunity_id}."}

def handle_confluence_search_node(state: AgentState) -> AgentState:
    """Handles Confluence search requests."""
    print(f"\n--- Executing handle_confluence_search_node ---")
    query = state["task_details"].get("query")
    if not query:
        return {"final_response": "Error: Confluence search query not provided."}
    
    results = search_confluence_tool(query)
    if results:
        response_str = "Found Confluence pages:\n" + "\n".join([f"ID: {p['id']}, Title: {p['title']}" for p in results])
        return {"final_response": response_str, "search_results": results}
    else:
        return {"final_response": f"No Confluence pages found matching '{query}'."}

def handle_read_confluence_node(state: AgentState) -> AgentState:
    """Handles reading specific Confluence page content."""
    print(f"\n--- Executing handle_read_confluence_node ---")
    page_id = state["task_details"].get("page_id")
    if page_id is None: # check for None, as ID can be 0
        return {"final_response": "Error: Confluence Page ID not provided."}
    
    try:
        page_id = int(page_id) # Ensure integer ID
    except ValueError:
        return {"final_response": "Error: Invalid Confluence Page ID. Please provide a number."}

    content = read_confluence_page_tool(page_id)
    if content:
        return {"final_response": f"Content of Confluence page {page_id}:\n{content}", "confluence_page_content": content}
    else:
        return {"final_response": f"Confluence page with ID {page_id} not found."}

def handle_summarize_confluence_node(state: AgentState) -> AgentState:
    """Handles summarizing Confluence page content."""
    print(f"\n--- Executing handle_summarize_confluence_node ---")
    page_content = state["task_details"].get("page_content")
    if not page_content and state.get("confluence_page_content"):
        page_content = state["confluence_page_content"]
    
    if not page_content:
        return {"final_response": "Error: Confluence page content not provided for summarization."}
    
    summary = summarize_confluence_tool(page_content)
    return {"final_response": f"Summary of Confluence page:\n{summary}"}

def handle_add_todo_node(state: AgentState) -> AgentState:
    """Handles adding a new to-do task."""
    print(f"\n--- Executing handle_add_todo_node ---")
    task_description = state["task_details"].get("task_description")
    if not task_description:
        return {"final_response": "Error: To-do task description not provided."}
    
    add_todo_tool(task_description)
    return {"final_response": f"To-do task added: '{task_description}'."}

def handle_list_todos_node(state: AgentState) -> AgentState:
    """Handles listing all to-do tasks."""
    print(f"\n--- Executing handle_list_todos_node ---")
    todos = list_todos_tool()
    if todos:
        todo_list_str = "Your To-Do List:\n"
        for todo in todos:
            status = "[DONE]" if todo.get("completed", False) else "[PENDING]"
            todo_list_str += f"- {todo['id']}: {status} {todo['description']}\n"
        return {"final_response": todo_list_str, "todo_list_data": todos}
    else:
        return {"final_response": "Your To-Do List is empty."}

def handle_mark_todo_complete_node(state: AgentState) -> AgentState:
    """Handles marking a to-do task as complete."""
    print(f"\n--- Executing handle_mark_todo_complete_node ---")
    task_id = state["task_details"].get("task_id")
    if task_id is None:
        return {"final_response": "Error: To-do Task ID not provided for completion."}
    
    try:
        task_id = int(task_id) # Ensure task_id is integer
    except ValueError:
        return {"final_response": "Error: Invalid To-do Task ID. Please provide a number."}

    success = mark_todo_complete_tool(task_id)
    if success:
        return {"final_response": f"To-do task {task_id} marked as complete."}
    else:
        return {"final_response": f"To-do task {task_id} not found or already complete."}

def handle_generate_insights_node(state: AgentState) -> AgentState:
    """Handles generating insights from combined data."""
    print(f"\n--- Executing handle_generate_insights_node ---")
    combined_data_summary = state["task_details"].get("combined_data_summary")
    banker_goal = state["task_details"].get("banker_goal")
    
    if not combined_data_summary and state.get("combined_data_summary"): # Use state if not explicitly provided
        combined_data_summary = state["combined_data_summary"]

    if not combined_data_summary:
        return {"final_response": "Error: Data summary not provided for insights generation. Please provide relevant data first."}
    
    insights = generate_insights_tool(combined_data_summary, banker_goal)
    return {"final_response": f"Insights:\n{insights}"}

def handle_product_recommendation_node(state: AgentState) -> AgentState:
    """Handles generating product recommendations."""
    print(f"\n--- Executing handle_product_recommendation_node ---")
    client_profile = state["task_details"].get("client_profile")
    product_catalog_summary = state["task_details"].get("product_catalog_summary")
    
    if not client_profile:
        return {"final_response": "Error: Client profile not provided for product recommendation."}
    
    if not product_catalog_summary:
        product_catalog_summary = "Standard banking products including loans, credit lines, treasury services, and investment options." # Default for mock

    recommendation = product_recommendation_tool(client_profile, product_catalog_summary)
    return {"final_response": f"Product Recommendation:\n{recommendation}"}

def handle_client_approach_recommendation_node(state: AgentState) -> AgentState:
    """Handles generating client approach recommendations."""
    print(f"\n--- Executing handle_client_approach_recommendation_node ---")
    client_history_summary = state["task_details"].get("client_history_summary")
    current_goal = state["task_details"].get("current_goal")

    if not client_history_summary:
        return {"final_response": "Error: Client history summary not provided for approach recommendation."}
    
    recommendation = client_approach_recommendation_tool(client_history_summary, current_goal)
    return {"final_response": f"Client Approach Recommendation:\n{recommendation}"}

def handle_combine_data_and_insights_node(state: AgentState) -> AgentState:
    """
    Handles requests to combine data from multiple sources and generate insights.
    This node would orchestrate calls to data retrieval tools and then pass to generate_insights.
    """
    print(f"\n--- Executing handle_combine_data_and_insights_node ---")
    data_sources = state["task_details"].get("data_sources", []) # e.g., ["email", "salesforce", "files"]
    query = state["task_details"].get("query", "") # General query for insights
    client_id_for_combine = state["task_details"].get("client_id") # Specific client ID if needed for combine

    combined_data_text = []

    if "files" in data_sources and query:
        print(f"Searching files for '{query}' for combined insights...")
        file_search_results = search_files_tool(state["base_directory"], query)
        for file_path in file_search_results:
            file_content = read_file_content(file_path)
            combined_data_text.append(f"File {os.path.basename(file_path)}: {file_content[:500]}...") # Truncate for brevity
    
    if "email" in data_sources and query:
        print(f"Searching emails for '{query}' for combined insights...")
        email_results = search_emails_tool(content_keywords=query)
        for email in email_results:
            combined_data_text.append(f"Email (Subject: {email['subject']}): {email['content'][:500]}...")

    if "salesforce" in data_sources and client_id_for_combine:
        print(f"Fetching Salesforce data for client {client_id_for_combine} for combined insights...")
        sf_client_data = get_client_data_tool(client_id_for_combine)
        if sf_client_data:
            combined_data_text.append(f"Salesforce Client Data for {client_id_for_combine}: {json.dumps(sf_client_data, indent=2)}")

    if not combined_data_text:
        return {"final_response": "Could not find relevant data from the specified sources for combining. Please ensure client ID or relevant keywords are provided for search."}

    # Summarize the collected data before passing to insights generation
    summarized_combined_data = summarize_content("\n".join(combined_data_text) + "\n\nProvide a concise summary of the collected data for insight generation.")
    
    # Now, pass to generate insights
    insights = generate_insights_tool(summarized_combined_data, f"Insights related to: {query} for client {client_id_for_combine if client_id_for_combine else 'N/A'}")

    return {"final_response": f"Combined Data Insights related to '{query}' (for Client ID: {client_id_for_combine}):\n{insights}", "combined_data_summary": summarized_combined_data}


# --- Response Synthesizer Node ---
def response_synthesizer_node(state: AgentState) -> AgentState:
    """
    Synthesizes the final response for the banker.
    This node acts as a passthrough if final_response is already set by a task-specific node.
    Otherwise, it can generate a default response for UNKNOWN intents or other cases.
    """
    print("\n--- Executing response_synthesizer_node ---")
    if state.get("final_response"):
        return {"final_response": state["final_response"]}
    elif state.get("intent") == Intent.UNKNOWN:
        return {"final_response": f"I'm sorry, I could not understand your request: '{state['user_request']}'. Please try rephrasing."}
    else:
        # Fallback if no specific response was generated by a task node
        return {"final_response": f"Task completed for intent '{state['intent']}', but no explicit final response was set. This might indicate an unhandled case or a task that completed without a direct user-facing message."}


# --- Conditional Logic (Routers) ---

def decide_next_step_after_summarize_subworkflow(state: AgentState) -> str:
    """
    Decides the next step after critical review for the summarization sub-workflow.
    """
    print("\n--- Conditional Edge: decide_next_step_after_summarize_subworkflow ---")
    quality_result = state["summary_quality_check_result"]
    retry_count = state["retry_count"]
    max_retries = 2

    if quality_result == "GOOD":
        print("Summary is GOOD. Proceeding to collect and append.")
        return "collect_and_append_summary_node"
    elif quality_result == "NEEDS_IMPROVEMENT" and retry_count <= max_retries:
        print(f"Summary needs improvement. Retrying (attempt {retry_count}/{max_retries}). Looping back to determine prompt.")
        return "determine_prompt_for_summary_node"
    else:
        print(f"Summary quality is {quality_result} or max retries ({max_retries}) reached. Proceeding to collect and append with flag.")
        return "collect_and_append_summary_node"

def decide_next_file_for_summary_subworkflow(state: AgentState) -> str:
    """
    Decides whether to process the next file in the summarization sub-workflow or return to main response.
    """
    print("\n--- Conditional Edge: decide_next_file_for_summary_subworkflow ---")
    files_to_process = state.get("files_to_process_for_summary", [])
    current_file = state.get("current_file", "") 

    if current_file: # A file was selected in select_next_file_for_summary_node
        print(f"Selected new file '{os.path.basename(current_file)}'. Proceeding to read.")
        return "read_file_for_summary_node"
    elif files_to_process: # This condition suggests there are still files but current_file wasn't set, which might be a bug.
                            # For robustness, if files_to_process still has items, try to select next.
                            # Otherwise, if no current_file and no files left to process, end.
        print("More files in queue, but current_file is empty. Attempting to select next file.")
        return "select_next_file_for_summary_node" # Loop back to select next if list not empty but current_file missing
    else: # No current_file and no more files in queue
        print("No more files for summarization. Returning to response synthesizer.")
        return "response_synthesizer"


def router_node(state: AgentState) -> str:
    """
    Main router node that directs the workflow based on the classified intent.
    Returns the Intent enum member itself (e.g., Intent.SUMMARIZE_DOCUMENT).
    """
    print(f"\n--- Executing router_node. Intent: {state['intent']} ---")
    # CRITICAL FIX: Return the Intent enum member itself, not its .value
    # Langgraph uses the enum member as the key for conditional edges directly.
    return state["intent"]


# --- Build the Main Orchestrator Graph ---
workflow = StateGraph(AgentState)

# Add Orchestrator Nodes
workflow.add_node("intent_classifier", intent_classifier_node)
workflow.add_node("response_synthesizer", response_synthesizer_node)

# Add all specialized task handler nodes
# File Summarization Nodes
workflow.add_node("list_files_for_summary_node", list_files_for_summary_node)
workflow.add_node("select_next_file_for_summary_node", select_next_file_for_summary_node)
workflow.add_node("read_file_for_summary_node", read_file_for_summary_node)
workflow.add_node("determine_prompt_for_summary_node", determine_prompt_for_summary_node)
workflow.add_node("summarize_file_content_node", summarize_file_content_node)
workflow.add_node("critical_review_summary_node", critical_review_summary_node)
workflow.add_node("collect_and_append_summary_node", collect_and_append_summary_node)

# Other Task Specific Nodes
workflow.add_node("file_search_node", file_search_node)
workflow.add_node("handle_email_search_node", handle_email_search_node)
workflow.add_node("handle_read_email_node", handle_read_email_node)
workflow.add_node("handle_summarize_email_node", handle_summarize_email_node)
workflow.add_node("handle_salesforce_client_data_node", handle_salesforce_client_data_node)
workflow.add_node("handle_salesforce_opportunity_data_node", handle_salesforce_opportunity_data_node)
workflow.add_node("handle_confluence_search_node", handle_confluence_search_node)
workflow.add_node("handle_read_confluence_node", handle_read_confluence_node)
workflow.add_node("handle_summarize_confluence_node", handle_summarize_confluence_node)
workflow.add_node("handle_add_todo_node", handle_add_todo_node)
workflow.add_node("handle_list_todos_node", handle_list_todos_node)
workflow.add_node("handle_mark_todo_complete_node", handle_mark_todo_complete_node)
workflow.add_node("handle_generate_insights_node", handle_generate_insights_node)
workflow.add_node("handle_product_recommendation_node", handle_product_recommendation_node)
workflow.add_node("handle_client_approach_recommendation_node", handle_client_approach_recommendation_node)
workflow.add_node("handle_combine_data_and_insights_node", handle_combine_data_and_insights_node)


# Set entry point
workflow.set_entry_point("intent_classifier")

# Now, the conditional edges start directly from intent_classifier, using router_node as the decision function
workflow.add_conditional_edges(
    "intent_classifier",
    router_node, # The router_node function is the callable that determines the next path
    {
        Intent.SUMMARIZE_DOCUMENT: "list_files_for_summary_node", # Keys are now Intent enum members
        Intent.SEARCH_FILE: "file_search_node",
        Intent.SEARCH_EMAIL: "handle_email_search_node",
        Intent.READ_EMAIL_CONTENT: "handle_read_email_node",
        Intent.SUMMARIZE_EMAIL: "handle_summarize_email_node",
        Intent.GET_SALESFORCE_CLIENT_DATA: "handle_salesforce_client_data_node",
        Intent.GET_SALESFORCE_OPPORTUNITY_DATA: "handle_salesforce_opportunity_data_node",
        Intent.SEARCH_CONFLUENCE: "handle_confluence_search_node",
        Intent.READ_CONFLUENCE_PAGE: "handle_read_confluence_node",
        Intent.SUMMARIZE_CONFLUENCE: "handle_summarize_confluence_node",
        Intent.ADD_TODO: "handle_add_todo_node",
        Intent.LIST_TODOS: "handle_list_todos_node",
        Intent.MARK_TODO_COMPLETE: "handle_mark_todo_complete_node",
        Intent.GENERATE_INSIGHTS: "handle_generate_insights_node",
        Intent.GET_PRODUCT_RECOMMENDATION: "handle_product_recommendation_node",
        Intent.GET_CLIENT_APPROACH_RECOMMENDATION: "handle_client_approach_recommendation_node",
        Intent.COMBINE_DATA_AND_INSIGHTS: "handle_combine_data_and_insights_node",
        Intent.UNKNOWN: "response_synthesizer",
        # "__default__": "response_synthesizer" # Consider adding a default if router_node can return other unexpected values
    }
)

# Edges for File Summarization Sub-workflow
workflow.add_conditional_edges(
    "list_files_for_summary_node",
    decide_next_file_for_summary_subworkflow,
    {
        "read_file_for_summary_node": "read_file_for_summary_node",
        "response_synthesizer": "response_synthesizer"
    }
)
workflow.add_edge("read_file_for_summary_node", "determine_prompt_for_summary_node")
workflow.add_edge("determine_prompt_for_summary_node", "summarize_file_content_node")
workflow.add_edge("summarize_file_content_node", "critical_review_summary_node")
workflow.add_conditional_edges(
    "critical_review_summary_node",
    decide_next_step_after_summarize_subworkflow,
    {
        "collect_and_append_summary_node": "collect_and_append_summary_node",
        "determine_prompt_for_summary_node": "determine_prompt_for_summary_node" # Loop back for retry
    }
)
workflow.add_edge("collect_and_append_summary_node", "select_next_file_for_summary_node")


# Edges from all other specialized task nodes to the final response synthesizer
workflow.add_edge("file_search_node", "response_synthesizer")
workflow.add_edge("handle_email_search_node", "response_synthesizer")
workflow.add_edge("handle_read_email_node", "response_synthesizer")
workflow.add_edge("handle_summarize_email_node", "response_synthesizer")
workflow.add_edge("handle_salesforce_client_data_node", "response_synthesizer")
workflow.add_edge("handle_salesforce_opportunity_data_node", "response_synthesizer")
workflow.add_edge("handle_confluence_search_node", "response_synthesizer")
workflow.add_edge("handle_read_confluence_node", "response_synthesizer")
workflow.add_edge("handle_summarize_confluence_node", "response_synthesizer")
workflow.add_edge("handle_add_todo_node", "response_synthesizer")
workflow.add_edge("handle_list_todos_node", "response_synthesizer")
workflow.add_edge("handle_mark_todo_complete_node", "response_synthesizer")
workflow.add_edge("handle_generate_insights_node", "response_synthesizer")
workflow.add_edge("handle_product_recommendation_node", "response_synthesizer")
workflow.add_edge("handle_client_approach_recommendation_node", "response_synthesizer") 
workflow.add_edge("handle_combine_data_and_insights_node", "response_synthesizer")


# Set the END point for the entire graph
workflow.set_finish_point("response_synthesizer")


# Compile the graph
app = workflow.compile()

# --- Mock Filesystem Setup ---
def setup_mock_filesystem(base_dir: str):
    """Creates a mock directory structure and files for testing."""
    if not os.path.exists(base_dir):
        os.makedirs(base_dir)

    # Clear summary.txt if it exists from previous runs
    summary_file_path = os.path.join(base_dir, "summary.txt")
    if os.path.exists(summary_file_path):
        os.remove(summary_file_path)
    
    # Clear todos.json if it exists
    todos_file_path = os.path.join(base_dir, "todos.json")
    if os.path.exists(todos_file_path):
        os.remove(todos_file_path)

    os.makedirs(os.path.join(base_dir, "dir1"), exist_ok=True)
    os.makedirs(os.path.join(base_dir, "dir2", "subdirA"), exist_ok=True)

    with open(os.path.join(base_dir, "meeting_notes.txt"), "w") as f:
        f.write("Meeting Notes: Discussed Q2 performance, new client acquisition strategy, and budget allocations. John Doe client meeting scheduled for next week.")
    with open(os.path.join(base_dir, "project_plan.txt"), "w") as f:
        f.write("Project Plan for New Loan System: Phase 1 - Requirement gathering. Phase 2 - Development. Phase 3 - Testing. Deadline: End of Q3.")
    with open(os.path.join(base_dir, "financial_report.pdf"), "w") as f: # Dummy non-text file
        f.write("This is a dummy PDF file content.")
    
    # Adding diverse Java files for testing
    with open(os.path.join(base_dir, "UserController.java"), "w") as f:
        f.write("""
        package com.example.app.controller;
        import org.springframework.web.bind.annotation.GetMapping;
        import org.springframework.web.bind.annotation.RestController;
        @RestController
        public class UserController {
            @GetMapping("/users")
            public String getAllUsers() { return "List of users"; }
            @PostMapping("/user")
            public String createUser() { return "User created"; }
        }
        """)
    with open(os.path.join(base_dir, "ProductService.java"), "w") as f:
        f.write("""
        package com.example.app.service;
        import org.springframework.stereotype.Service;
        @Service
        public class ProductService {
            public String getProductDetails(String productId) { return "Details for product " + productId; }
            public void updateProduct(String productId, String details) { /* Updates product details in DB */ }
        }
        """)
    with open(os.path.join(base_dir, "AuthApi.java"), "w") as f:
        f.write("""
        package com.example.app.api;
        public interface AuthApi {
            String authenticate(String username, String password);
            void logout();
        }
        """)
    with open(os.path.join(base_dir, "MainApplication.java"), "w") as f:
        f.write("""
        package com.example.app;
        import org.springframework.boot.SpringApplication;
        import org.springframework.boot.autoconfigure.SpringBootApplication;
        @SpringBootApplication
        public class MainApplication {
            public static void main(String[] args) {
                SpringApplication.run(MainApplication.class, args);
                System.out.println("Application started successfully!");
            }
        }
        """)
    with open(os.path.join(base_dir, "README.md"), "w") as f:
        f.write("""
        # Project README
        This project is a demonstration of Langgraph agent capabilities.
        ## Features
        - File listing
        - Dynamic summarization
        - OpenAI integration
        """)
    with open(os.path.join(base_dir, "data_processor.py"), "w") as f:
        f.write("""
        def process_data(data): # This function takes data and processes it
            result = data * 2
            return result
        class DataHandler:
            def __init__(self, name):
                self.name = name
            def handle(self, item):
                return f"Handling {item} with {self.name}"
        """)
    with open(os.path.join(base_dir, "index.html"), "w") as f:
        f.write("""
        <!DOCTYPE html>
        <html>
        <head>
            <title>My Web Page</title>
        </head>
        <body>
            <h1>Welcome to My Page</h1>
            <p>This is a simple paragraph for demonstration.</p>
            <button>Click Me</button>
        </body>
        </html>
        """)

    print(f"Mock filesystem created at '{base_dir}' with diverse file types.")

# --- Run the Assistant ---
if __name__ == "__main__":
    dynamic_folder_name = "banker_assistant_data" # Central data directory for the assistant
    full_dynamic_path = os.path.join(os.getcwd(), dynamic_folder_name)

    # Ensure mock filesystem is set up
    setup_mock_filesystem(full_dynamic_path)

    # --- Step 1: Dynamic Configuration Generation (if desired) ---
    print("\n--- Assistant Configuration ---")
    configure_dynamically = input("Do you want to dynamically configure summarization rules (y/n)? (Existing config will be overwritten): ").lower()
    
    config_path = os.path.join(os.getcwd(), "summarization_config.json")
    summarization_config_data = {}

    if configure_dynamically == 'y':
        user_config_request = input("Describe how you want different file types summarized (e.g., 'Summarize Python files by their main functions, Java controllers by their endpoints, and HTML by structure.'): \n")
        print("\nGenerating dynamic summarization configuration...")
        try:
            dynamically_generated_config = generate_config_from_request(user_config_request)
            with open(config_path, 'w', encoding='utf-8') as f:
                json.dump(dynamically_generated_config, f, indent=4)
            print(f"Dynamically generated config saved to: {config_path}")
            summarization_config_data = dynamically_generated_config
        except Exception as e:
            print(f"Error generating dynamic configuration: {e}. Falling back to default config.")
            summarization_config_data = load_summarization_config(config_path) # Load existing default
    else:
        print("Loading existing summarization configuration.")
        summarization_config_data = load_summarization_config(config_path)
    
    if not summarization_config_data:
        print("Error: Could not load any summarization_config.json. Exiting.")
        exit()

    # --- Step 2: Main Assistant Interaction Loop ---
    print("\n--- Commercial Banker Assistant Ready ---")
    while True:
        user_input = input("\nBanker Request (or 'exit' to quit): \n")
        if user_input.lower() == 'exit':
            break

        print("\nProcessing your request...")
        initial_state = {
            "user_request": user_input,
            "base_directory": full_dynamic_path, # Pass the base directory
            "summarization_config": summarization_config_data # Pass the loaded config
        }

        # The 'try...except' block is re-enabled here, as requested by the user.
        try: 
            initial_state["final_response"] = "" 
            final_state = app.invoke(initial_state, config={"recursion_limit": 500})
            print("\n--- Assistant Response ---")
            print(final_state.get("final_response", "No specific response generated."))
            
            if final_state.get("intent") == Intent.SUMMARIZE_DOCUMENT:
                print("\n--- Full Summarization File Content (summary.txt) ---")
                try:
                    with open(os.path.join(full_dynamic_path, "summary.txt"), "r", encoding="utf-8") as f:
                        print(f.read())
                except FileNotFoundError:
                    print("summary.txt not found. No file summaries generated yet or error occurred.")
        except Exception as e:
            print(f"\nAn error occurred during processing: {e}")
            print("Please try rephrasing your request.")

    print("\nAssistant session ended.")