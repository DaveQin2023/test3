# graph_plotter.py
import os
# Assuming 'app' (the compiled workflow) is imported from your app.py
# Make sure app.py is in the same directory or properly importable
try:
    from app import app
except ImportError:
    print("Error: Could not import 'app' from 'app.py'. Please ensure app.py is in the same directory.")
    print("Also, ensure `app = workflow.compile()` has been executed in app.py before running this script.")
    exit() # Exit if app cannot be imported

try:
    # Get the graph object
    graph = app.get_graph()
    
    # Generate Mermaid text representation of the graph
    # This method creates a string that can be used in Mermaid diagrams
    mermaid_diagram = graph.draw_mermaid() # Changed from draw_mermaid_yaml() to draw_mermaid()

    # Define the path for the output Mermaid Markdown file
    mermaid_file_path = os.path.join(os.getcwd(), "langgraph_workflow.md")
    
    # Write the Mermaid diagram to a Markdown file
    with open(mermaid_file_path, "w") as f:
        f.write("```mermaid\n") # Start of Mermaid block in Markdown
        f.write(mermaid_diagram)
        f.write("\n```\n") # End of Mermaid block

    print(f"Langgraph workflow graph (Mermaid format) saved to: {mermaid_file_path}")
    print("\nTo view this graph:")
    print("1. Open the 'langgraph_workflow.md' file.")
    print("2. Copy the content (including the ```mermaid and ``` tags).")
    print("3. Paste it into an online Mermaid Live Editor (e.g., https://mermaid.live/)")
    print("   or a Markdown viewer that supports Mermaid (like VS Code with the Mermaid extension).")

except Exception as e:
    print(f"An error occurred while trying to generate the Mermaid graph: {e}")

