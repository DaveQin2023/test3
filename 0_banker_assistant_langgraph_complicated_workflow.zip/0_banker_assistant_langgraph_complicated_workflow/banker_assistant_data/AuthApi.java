
        package com.example.app.api;
        public interface AuthApi {
            String authenticate(String username, String password);
            void logout();
        }
        