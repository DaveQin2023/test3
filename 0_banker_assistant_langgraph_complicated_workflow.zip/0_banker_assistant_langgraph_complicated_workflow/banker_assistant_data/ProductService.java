
        package com.example.app.service;
        import org.springframework.stereotype.Service;
        @Service
        public class ProductService {
            public String getProductDetails(String productId) { return "Details for product " + productId; }
            public void updateProduct(String productId, String details) { /* Updates product details in DB */ }
        }
        