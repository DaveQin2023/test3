
        package com.example.app.controller;
        import org.springframework.web.bind.annotation.GetMapping;
        import org.springframework.web.bind.annotation.RestController;
        @RestController
        public class UserController {
            @GetMapping("/users")
            public String getAllUsers() { return "List of users"; }
            @PostMapping("/user")
            public String createUser() { return "User created"; }
        }
        