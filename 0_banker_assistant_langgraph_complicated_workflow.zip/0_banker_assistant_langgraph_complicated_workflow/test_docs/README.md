
        # Project README
        
        This project is a demonstration of Langgraph agent capabilities.
        
        ## Features
        - File listing
        - Dynamic summarization
        - OpenAI integration
        