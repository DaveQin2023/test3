
        def process_data(data):
            # This function takes data and processes it
            result = data * 2
            return result

        class DataHandler:
            def __init__(self, name):
                self.name = name

            def handle(self, item):
                return f"Handling {item} with {self.name}"
        