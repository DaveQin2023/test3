
        package com.example.app.api;

        public interface AuthApi {
            // Authenticates a user
            String authenticate(String username, String password);
            // Logs out a user
            void logout();
        }
        