
        package com.example.app.service;

        import org.springframework.stereotype.Service;
        
        @Service
        public class ProductService {
            public String getProductDetails(String productId) {
                // Complex business logic here to retrieve product details from DB
                return "Details for product " + productId;
            }
            public void updateProduct(String productId, String details) {
                // Updates product details in the database
            }
        }
        