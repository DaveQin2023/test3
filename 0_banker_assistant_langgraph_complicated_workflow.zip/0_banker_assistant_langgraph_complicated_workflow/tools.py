# tools.py
import os
from typing import List, Dict, Any
import json
from openai import OpenAI
import time # For mocking delays

# --- Configuration for Mock Data ---
MOCK_EMAIL_DB_PATH = "banker_assistant_data/mock_emails.json"
MOCK_SALESFORCE_DB_PATH = "banker_assistant_data/mock_salesforce.json"
MOCK_CONFLUENCE_DB_PATH = "banker_assistant_data/mock_confluence.json"
MOCK_TODO_DB_PATH = "banker_assistant_data/todos.json"

# Helper to ensure mock data files exist
def _ensure_mock_data_file(file_path: str, default_content: Any):
    os.makedirs(os.path.dirname(file_path), exist_ok=True)
    if not os.path.exists(file_path):
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(default_content, f, indent=4)
        print(f"Created mock data file: {file_path}")

# --- File System Operations ---

def list_all_files_recursively(directory: str) -> List[str]:
    """
    Lists all files recursively within a given directory.
    """
    print(f"Tool: Listing files recursively in {directory}...")
    file_list = []
    if not os.path.exists(directory):
        print(f"Error: Directory not found at {directory}")
        return []
    for root, _, files in os.walk(directory):
        for file in files:
            file_list.append(os.path.join(root, file))
    return file_list

def read_file_content(file_path: str) -> str:
    """
    Reads the content of a specified file, attempting multiple encodings.
    """
    print(f"Tool: Reading content from {file_path}...")
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            content = f.read()
        return content
    except UnicodeDecodeError:
        print(f"UnicodeDecodeError: Could not decode file {file_path} with utf-8. Trying latin-1...")
        try:
            with open(file_path, "r", encoding="latin-1") as f:
                content = f.read()
            return content
        except Exception as e:
            print(f"Error reading file {file_path} even with latin-1 encoding: {e}")
            return ""
    except FileNotFoundError:
        print(f"Error: File not found at {file_path}")
        return ""

def append_to_summary_file(summary_text: str, base_directory: str):
    """
    Writes the provided summary text to a designated summary file, overwriting existing content.
    """
    summary_file_path = os.path.join(base_directory, "summary.txt")
    print(f"Tool: Appending summary to {summary_file_path}...")
    try:
        with open(summary_file_path, "w", encoding="utf-8") as f:
            f.write(summary_text)
        print("Summary successfully written to file.")
    except IOError as e:
        print(f"Error writing to summary file: {e}")

def search_files_tool(directory: str, query: str) -> List[str]:
    """
    Mocks searching for files containing specific keywords within a directory.
    In a real scenario, this would be more advanced (e.g., indexed search).
    """
    print(f"Tool: Searching files in '{directory}' for '{query}'...")
    matching_files = []
    all_files = list_all_files_recursively(directory)
    for file_path in all_files:
        if os.path.isfile(file_path): # Ensure it's a file
            try:
                content = read_file_content(file_path)
                if query.lower() in content.lower():
                    matching_files.append(file_path)
            except Exception as e:
                print(f"Could not read {file_path} for search: {e}")
    time.sleep(0.5) # Simulate work
    return matching_files

# --- LLM-Powered Tools ---

def summarize_content(prompt: str) -> str:
    """
    Generates a summary using the OpenAI API.
    """
    print("Tool: Calling LLM for summarization (OpenAI)...")


    apikey='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'


    client = OpenAI(api_key=apikey)

    try:
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "user", "content": prompt}
            ],
            max_tokens=250
        )
        if response.choices and len(response.choices) > 0 and response.choices[0].message:
            return response.choices[0].message.content
        else:
            print("Error: Unexpected response structure from OpenAI API.")
            return "Summarization failed: Unexpected LLM response."
    except Exception as e:
        print(f"Error calling OpenAI API for summarization: {e}")
        return f"Summarization failed: OpenAI API error - {e}"

def evaluate_summary(summary: str, original_content_placeholder: str, file_type: str) -> str:
    """
    Evaluates the quality of a generated summary using OpenAI, acting as a critical agent.
    Returns "GOOD", "NEEDS_IMPROVEMENT", or "BAD".
    """
    print(f"Tool: Critically evaluating summary for file type: {file_type}...")

    apikey='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'


    client = OpenAI(api_key=apikey)


    ##client = OpenAI()
    
    evaluation_prompt = f"""You are a critical assistant. Your task is to evaluate the quality of a summary generated for a file.
    
    File Type: {file_type}
    Generated Summary:
    {summary}

    Based on the file type, assess if the summary is:
    - **GOOD**: Comprehensive, accurate, and captures the key information for this file type.
    - **NEEDS_IMPROVEMENT**: Missing some key details, too brief, slightly inaccurate, or could be more focused.
    - **BAD**: Significantly inaccurate, irrelevant, or fails to capture the core purpose of the content.

    Provide only one of these words as your output: GOOD, NEEDS_IMPROVEMENT, BAD
    """

    try:
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "You are a critical assistant evaluating summaries. Respond only with GOOD, NEEDS_IMPROVEMENT, or BAD."},
                {"role": "user", "content": evaluation_prompt}
            ],
            max_tokens=10,
            temperature=0.0
        )
        if response.choices and len(response.choices) > 0 and response.choices[0].message:
            feedback = response.choices[0].message.content.strip().upper()
            if feedback in ["GOOD", "NEEDS_IMPROVEMENT", "BAD"]:
                return feedback
            else:
                print(f"Warning: Unexpected feedback from critic LLM: {feedback}. Defaulting to GOOD.")
                return "GOOD"
        else:
            print("Error: No valid feedback from critic LLM.")
            return "GOOD"
    except Exception as e:
        print(f"Error calling critic LLM: {e}")
        return "GOOD"

def generate_insights_tool(combined_data_summary: str, banker_goal: str = None) -> str:
    """
    Generates insights from a summary of combined data.
    """
    print("Tool: Generating insights using LLM...")

    apikey='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'


    client = OpenAI(api_key=apikey)


    ###client = OpenAI()
    
    prompt = f"Analyze the following summary of information:\n\n{combined_data_summary}\n\n"
    if banker_goal:
        prompt += f"Focus on insights relevant to the banker's goal: '{banker_goal}'.\n\n"
    prompt += "Provide actionable insights for a commercial banker based on this data."

    try:
        response = client.chat.completions.create(
            model="gpt-4o", # Use a more capable model for insights
            messages=[
                {"role": "system", "content": "You are an AI assistant specialized in generating actionable insights for commercial bankers."},
                {"role": "user", "content": prompt}
            ],
            max_tokens=300,
            temperature=0.7
        )
        if response.choices and len(response.choices) > 0 and response.choices[0].message:
            return response.choices[0].message.content
        else:
            return "Failed to generate insights."
    except Exception as e:
        print(f"Error generating insights: {e}")
        return "Error generating insights."

def product_recommendation_tool(client_profile: str, product_catalog_summary: str) -> str:
    """
    Generates product recommendations for a client based on their profile and available products.
    """
    print("Tool: Generating product recommendations using LLM...")

    apikey='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'


    client = OpenAI(api_key=apikey)


    ###client = OpenAI()
    
    prompt = f"""Based on the following client profile and available product catalog, recommend suitable commercial banking products.
    Client Profile: {client_profile}
    Available Products Summary: {product_catalog_summary}

    Provide specific product recommendations and a brief justification for each."""

    try:
        response = client.chat.completions.create(
            model="gpt-4o",
            messages=[
                {"role": "system", "content": "You are a commercial banking product recommender. Be concise and relevant."},
                {"role": "user", "content": prompt}
            ],
            max_tokens=250,
            temperature=0.7
        )
        if response.choices and len(response.choices) > 0 and response.choices[0].message:
            return response.choices[0].message.content
        else:
            return "Failed to generate product recommendations."
    except Exception as e:
        print(f"Error generating product recommendations: {e}")
        return "Error generating product recommendations."

def client_approach_recommendation_tool(client_history_summary: str, current_goal: str = None) -> str:
    """
    Generates recommendations on how to approach a client based on their history and current goal.
    """
    print("Tool: Generating client approach recommendations using LLM...")

    apikey='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'


    client = OpenAI(api_key=apikey)


    ##client = OpenAI()
    
    prompt = f"Based on the following client interaction history: {client_history_summary}\n\n"
    if current_goal:
        prompt += f"Considering the current goal: '{current_goal}'.\n\n"
    prompt += "Recommend the best approach for a commercial banker to interact with this client. Be specific and actionable."

    try:
        response = client.chat.completions.create(
            model="gpt-4o",
            messages=[
                {"role": "system", "content": "You are a commercial banker's strategy advisor. Provide actionable client approach recommendations."},
                {"role": "user", "content": prompt}
            ],
            max_tokens=250,
            temperature=0.7
        )
        if response.choices and len(response.choices) > 0 and response.choices[0].message:
            return response.choices[0].message.content
        else:
            return "Failed to generate client approach recommendations."
    except Exception as e:
        print(f"Error generating client approach recommendations: {e}")
        return "Error generating client approach recommendations."


def generate_config_from_request(user_request: str) -> Dict[str, Any]:
    """
    Uses an LLM to dynamically generate the summarization configuration JSON from a user request.
    """
    print("Tool: Calling LLM to generate dynamic summarization config...")

    apikey='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'


    client = OpenAI(api_key=apikey)


    ##client = OpenAI()

    config_schema = {
        "type": "object",
        "properties": {
            "default": {
                "type": "object",
                "properties": {
                    "prompt_template": {"type": "string", "description": "Default prompt template for unhandled file types. Use '{file_name}' and '{file_content}' placeholders."}
                },
                "required": ["prompt_template"]
            },
            "patternProperties": {
                "^\.": {
                    "type": "object",
                    "properties": {
                        "prompt_template": {"type": "string", "description": "Prompt template for this specific file type. Use '{file_name}' and '{file_content}' placeholders."},
                        "default_java_prompt": {"type": "string", "description": "Default prompt for .java if no sub-type matches."},
                        "sub_types": {
                            "type": "array",
                            "items": {
                                "type": "object",
                                "properties": {
                                    "name": {"type": "string"},
                                    "patterns": {"type": "array", "items": {"type": "string"}, "description": "Keywords or patterns to identify this sub-type."},
                                    "prompt_template": {"type": "string", "description": "Prompt template for this sub-type. Use '{file_name}' and '{file_content}' placeholders."}
                                },
                                "required": ["name", "patterns", "prompt_template"]
                            }
                        }
                    },
                    "oneOf": [
                        {"required": ["prompt_template"]},
                        {"required": ["default_java_prompt", "sub_types"]}
                    ],
                    "minProperties": 1
                }
            }
        },
        "required": ["default"],
        "minProperties": 1
    }

    json_example = json.dumps({
        "default": {
            "prompt_template": "Provide a general summary of '{file_name}':\n\n{file_content}"
        },
        ".py": {
            "prompt_template": "Summarize the Python file '{file_name}', focusing on functions, classes, and main logic:\n\n{file_content}"
        },
        ".html": {
            "prompt_template": "Summarize the HTML structure and content of '{file_name}', highlighting its layout and main elements:\n\n{file_content}"
        },
        ".java": {
            "default_java_prompt": "General summary of Java file '{file_name}':\n\n{file_content}",
            "sub_types": [
                {
                    "name": "controller",
                    "patterns": ["@RestController", "@Controller"],
                    "prompt_template": "Summarize Java controller '{file_name}' focusing on API endpoints and request handling:\n\n{file_content}"
                },
                {
                    "name": "service",
                    "patterns": ["@Service", "class .*Service"],
                    "prompt_template": "Summarize Java service '{file_name}' highlighting its business logic and dependencies:\n\n{file_content}"
                }
            ]
        }
    }, indent=4)


    prompt_messages = [
        {"role": "system", "content": f"""You are a configuration generator assistant. Your task is to interpret a user's natural language request for how to summarize different file types and convert it into a valid JSON configuration object.
        
        The JSON object must strictly adhere to the following schema and format.
        
        General rules:
        - Use '{'{file_name}'}' and '{'{file_content}'}' as placeholders in all 'prompt_template' strings.
        - Always include a 'default' entry with a 'prompt_template'.
        - For each file extension (e.g., '.py', '.html'), create a top-level key like ".<extension>".
        - For '.java' files, if the user describes different types of Java files (e.g., controllers, services, APIs), create a 'sub_types' array. Each 'sub_type' must have a 'name', a 'patterns' array (keywords or code snippets to look for), and a 'prompt_template'. Also provide a 'default_java_prompt' for .java files that don't match any sub_type.
        - If the user asks for a general summary for a file type, provide a general prompt_template for it.
        - If the user asks for specific information (e.g., 'main functions' for Python, 'endpoints' for controllers), craft the prompt_template to extract that specific information.
        - Ensure all generated JSON is valid and complete.

        Here's an example of the desired JSON structure based on a sample request:
        ```json
        {json_example}
        ```
        
        Now, generate the JSON configuration based on the user's request.
        """},
        {"role": "user", "content": user_request}
    ]

    try:
        response = client.chat.completions.create(
            model="gpt-4o", # Using a more capable model for config generation
            messages=prompt_messages,
            response_format={"type": "json_object"},
            temperature=0.2
        )
        
        if response.choices and len(response.choices) > 0 and response.choices[0].message:
            generated_json_str = response.choices[0].message.content
            print(f"LLM generated config (raw):\n{generated_json_str}")
            parsed_config = json.loads(generated_json_str)
            print("Successfully parsed LLM generated config.")
            return parsed_config
        else:
            print("Error: No valid JSON config generated by LLM.")
            return {}
    except json.JSONDecodeError as e:
        print(f"Error decoding JSON from LLM response: {e}")
        print(f"Raw LLM output that caused error: {generated_json_str}")
        return {}
    except Exception as e:
        print(f"Error calling LLM for config generation: {e}")
        return {}

# --- Config Loading and Dynamic Prompt Generation ---

def load_summarization_config(config_path: str) -> Dict:
    """
    Loads the summarization configuration from a JSON file.
    """
    print(f"Tool: Loading summarization configuration from {config_path}...")
    try:
        with open(config_path, 'r', encoding='utf-8') as f:
            config = json.load(f)
        print("Summarization config loaded successfully.")
        return config
    except FileNotFoundError:
        print(f"Error: Configuration file not found at {config_path}. Please ensure it exists or use dynamic generation.")
        return {}
    except json.JSONDecodeError as e:
        print(f"Error: Invalid JSON in configuration file {config_path}: {e}")
        return {}

def get_dynamic_prompt(file_path: str, file_content: str, config: Dict) -> str:
    """
    Determines and formats the appropriate prompt based on file extension and content.
    For .java files, it performs content-based classification.
    """
    file_name = os.path.basename(file_path)
    _, file_extension = os.path.splitext(file_name)
    file_extension_lower = file_extension.lower()

    prompt_template = None

    # Handle Java files with content-based classification
    if file_extension_lower == ".java" and ".java" in config:
        java_config = config[".java"]
        sub_types = java_config.get("sub_types", [])
        
        for sub_type in sub_types:
            patterns = sub_type.get("patterns", [])
            for pattern in patterns:
                if pattern in file_content:
                    prompt_template = sub_type.get("prompt_template")
                    print(f"Matched Java sub-type: {sub_type.get('name')} for {file_name}")
                    break
            if prompt_template:
                break
        
        if not prompt_template:
            prompt_template = java_config.get("default_java_prompt")
            print(f"No specific Java sub-type matched for {file_name}. Using default Java prompt.")

    if not prompt_template:
        prompt_template = config.get(file_extension_lower, config.get("default", {})).get("prompt_template")

    if not file_extension and "default" in config and config["default"].get("prompt_template"):
        if os.path.exists(file_path) and os.path.isfile(file_path):
            if "." not in os.path.basename(file_path):
                prompt_template = config["default"].get("prompt_template")

    if not prompt_template:
        print(f"Warning: No prompt template found for extension '{file_extension}' or 'default'. Using a generic fallback.")
        prompt_template = "Summarize the following content from file '{file_name}':\n\n{file_content}"

    return prompt_template.format(file_name=file_name, file_content=file_content)


# --- Mocked External System Tools ---
# These functions simulate API calls to external systems like Email, Salesforce, Confluence.
# In a real application, you would replace these with actual API clients and authentication.

#MOCK_EMAIL_DATA = [
#    {"id": 1, "sender": "client@example.com", "subject": "Loan Application Query", "content": "Dear Banker, I have a query regarding my recent loan application. Can we discuss the terms?"},
#    {"id": 2, "sender": "colleague@bank.com", "subject": "Meeting Agenda Q3", "content": "Hi team, please review the Q3 planning meeting agenda attached."},
##    {"id": 3, "sender": "client@example.com", "subject": "Follow-up on financing", "content": "Following up on our discussion about the business financing options. Are there any updates?"},
#   {"id": 4, "sender": "marketing@bank.com", "subject": "New Product Launch", "content": "Announcing our new SME business credit line. Details attached."}
#]

MOCK_EMAIL_DATA = [
    {"id": "C1001", "sender": "client@example.com", "subject": "Loan Application Query", "content": "Dear Banker, I have a query regarding my recent loan application. Can we discuss the terms?"},
    {"id": "C1001", "sender": "colleague@bank.com", "subject": "Meeting Agenda Q3", "content": "Hi team, please review the Q3 planning meeting agenda attached."},
    {"id": "C1002", "sender": "client@example.com", "subject": "Follow-up on financing", "content": "Following up on our discussion about the business financing options. Are there any updates?"},
    {"id": "C1002", "sender": "marketing@bank.com", "subject": "New Product Launch", "content": "Announcing our new SME business credit line. Details attached."}
]

def search_emails_tool(sender: str = None, subject_keywords: str = None, content_keywords: str = None) -> List[Dict]:
    """Mocks searching for emails."""
    print(f"Tool: Mock searching emails (sender={sender}, subject='{subject_keywords}', content='{content_keywords}')...")
    time.sleep(1) # Simulate API call
    results = []
    for email in MOCK_EMAIL_DATA:
        match = True
        if sender and sender.lower() not in email['sender'].lower():
            match = False
        if subject_keywords and not any(kw.lower() in email['subject'].lower() for kw in subject_keywords.split(',')):
            match = False
        if content_keywords and not any(kw.lower() in email['content'].lower() for kw in content_keywords.split(',')):
            match = False
        if match:
            results.append(email)
    return results

def read_email_tool(email_id: int) -> str:
    """Mocks reading a specific email's content."""
    print(f"Tool: Mock reading email ID {email_id}...")
    time.sleep(0.5)
    for email in MOCK_EMAIL_DATA:
        if email['id'] == email_id:
            return email['content']
    return ""

def summarize_email_tool(email_content: str) -> str:
    """Summarizes email content using LLM."""
    print("Tool: Summarizing email content...")
    return summarize_content(f"Summarize the following email content:\n\n{email_content}")

MOCK_SALESFORCE_DATA = {
    "C1001": {"name": "ABC Corp", "industry": "Manufacturing", "revenue": "50M", "contact": "Jane Doe", "opportunities": [{"id": "O200", "name": "Expansion Loan", "status": "Pending", "amount": "10M"}]},
    "C1002": {"name": "XYZ Solutions", "industry": "Technology", "revenue": "20M", "contact": "John Smith", "opportunities": [{"id": "O201", "name": "Credit Line Increase", "status": "Approved", "amount": "2M"}]},
}

def get_client_data_tool(client_id: str) -> Dict[str, Any]:
    """Mocks retrieving client data from Salesforce."""
    print(f"Tool: Mock getting Salesforce client data for '{client_id}'...")
    time.sleep(1)
    return MOCK_SALESFORCE_DATA.get(client_id, {})

def get_opportunity_data_tool(client_id: str = None, opportunity_id: str = None) -> Dict[str, Any]:
    """Mocks retrieving opportunity data from Salesforce."""
    print(f"Tool: Mock getting Salesforce opportunity data (client='{client_id}', opp='{opportunity_id}')...")
    time.sleep(1)
    if client_id and client_id in MOCK_SALESFORCE_DATA:
        client_data = MOCK_SALESFORCE_DATA[client_id]
        if opportunity_id:
            for opp in client_data.get("opportunities", []):
                if opp["id"] == opportunity_id:
                    return opp
        else: # Return all opportunities for client if no specific opp_id
            return client_data.get("opportunities", [])
    return {}

#MOCK_CONFLUENCE_DATA = [
#    {"id": 101, "title": "Loan Approval Process", "content": "This page outlines the steps for approving commercial loans, including documentation required and approval thresholds."},
#    {"id": 102, "title": "Client Onboarding Checklist", "content": "Checklist for onboarding new commercial banking clients."},
#    {"id": 103, "title": "Treasury Services Overview", "content": "Detailed overview of treasury management services offered by the bank."}
#]


MOCK_CONFLUENCE_DATA = [
    {"id": "C1002", "title": "Loan Approval Process", "content": "This page outlines the steps for approving commercial loans, including documentation required and approval thresholds."},
    {"id": "C1002", "title": "Client Onboarding Checklist", "content": "Checklist for onboarding new commercial banking clients."},
    {"id": "C1001", "title": "Treasury Services Overview", "content": "Detailed overview of treasury management services offered by the bank."}
]


def search_confluence_tool(query: str) -> List[Dict]:
    """Mocks searching Confluence pages."""
    print(f"Tool: Mock searching Confluence for '{query}'...")
    time.sleep(1)
    results = []
    for page in MOCK_CONFLUENCE_DATA:
        if query.lower() in page['title'].lower() or query.lower() in page['content'].lower():
            results.append(page)
    return results

def read_confluence_page_tool(page_id: int) -> str:
    """Mocks reading a specific Confluence page's content."""
    print(f"Tool: Mock reading Confluence page ID {page_id}...")
    time.sleep(0.5)
    for page in MOCK_CONFLUENCE_DATA:
        if page['id'] == page_id:
            return page['content']
    return ""

def summarize_confluence_tool(page_content: str) -> str:
    """Summarizes Confluence page content using LLM."""
    print("Tool: Summarizing Confluence page content...")
    return summarize_content(f"Summarize the following Confluence page content:\n\n{page_content}")

# --- To-Do List Tools (with simple JSON persistence) ---
def _load_todos() -> List[Dict]:
    """Loads to-do items from a JSON file."""
    _ensure_mock_data_file(MOCK_TODO_DB_PATH, [])
    try:
        with open(MOCK_TODO_DB_PATH, 'r', encoding='utf-8') as f:
            return json.load(f)
    except json.JSONDecodeError:
        return [] # Return empty list if file is empty or malformed

def _save_todos(todos: List[Dict]):
    """Saves to-do items to a JSON file."""
    with open(MOCK_TODO_DB_PATH, 'w', encoding='utf-8') as f:
        json.dump(todos, f, indent=4)

def add_todo_tool(task_description: str) -> Dict:
    """Adds a new to-do task."""
    print(f"Tool: Adding to-do task: '{task_description}'...")
    todos = _load_todos()
    new_id = 1 if not todos else max(t['id'] for t in todos) + 1
    new_todo = {"id": new_id, "description": task_description, "completed": False}
    todos.append(new_todo)
    _save_todos(todos)
    time.sleep(0.1)
    return new_todo

def list_todos_tool() -> List[Dict]:
    """Lists all to-do tasks."""
    print("Tool: Listing to-do tasks...")
    time.sleep(0.1)
    return _load_todos()

def mark_todo_complete_tool(task_id: int) -> bool:
    """Marks a to-do task as complete."""
    print(f"Tool: Marking to-do task {task_id} as complete...")
    todos = _load_todos()
    found = False
    for todo in todos:
        if todo['id'] == task_id:
            todo['completed'] = True
            found = True
            break
    if found:
        _save_todos(todos)
    time.sleep(0.1)
    return found

