import React, { useState } from 'react';
import {
  Layers,
  Briefcase,
  Users,
  Target,
  ChevronRight, // Common icon for all layer 2 items
} from 'lucide-react';

const Sidebar = () => {
  const [openSections, setOpenSections] = useState<{ [key: string]: boolean }>({
    portfolioPrioritization: true,
    myEngagements: false,
    myClients: false,
    myProspects: false,
  });

  const [openSubSections, setOpenSubSections] = useState<{ [key: string]: boolean }>({});

  const toggleSection = (section: string) => {
    setOpenSections((prev) => ({ ...prev, [section]: !prev[section] }));
  };

  const toggleSubSection = (subSection: string) => {
    setOpenSubSections((prev) => ({ ...prev, [subSection]: !prev[subSection] }));
  };

  const handlePopup = (message: string) => {
    alert(message);
  };

  return (
    // Increased sidebar width from w-60 to w-72 for better text fit
    <aside className='w-72 bg-[#112B45] p-6 text-white h-full overflow-y-auto'>
      <h1 className='text-2xl font-bold mb-6'>J.P.Morgan</h1>

      <ul className='space-y-2'>
        <li>
          <button className='font-semibold w-full text-left flex items-center gap-2' onClick={() => toggleSection('portfolioPrioritization')}>
            <Layers size={16} /> Portfolio Prioritization
          </button>
          {openSections.portfolioPrioritization && (
            // Reverted to space-y-1 for vertical list, removed flex-wrap
            <ul className='ml-4 mt-1 space-y-1'>
              <li>
                {/* Added whitespace-nowrap to keep text on one line */}
                <button className='text-sm text-blue-300 flex items-center gap-2 px-2 py-1 rounded hover:bg-gray-700 whitespace-nowrap' onClick={() => toggleSubSection('contactOverdue')}>
                  <ChevronRight size={16} /> Contact Overdue (2)
                </button>
                {openSubSections.contactOverdue && (
                  <ul className='ml-4 mt-1 space-y-1 text-xs'>
                    <li className='cursor-pointer hover:underline' onClick={() => handlePopup("⏱️ No contact in 3 months — re-engage to maintain relationship tier")}>
                      ## Stratus Capital Partners
                    </li>
                    <li className='cursor-pointer hover:underline' onClick={() => handlePopup("Last meeting was 90 days ago — schedule QBR or health check-in")}>
                      ## Redwood Energy Group
                    </li>
                  </ul>
                )}
              </li>
              <li>
                {/* Added whitespace-nowrap */}
                <button className='text-sm text-blue-300 flex items-center gap-2 px-2 py-1 rounded hover:bg-gray-700 whitespace-nowrap' onClick={() => toggleSubSection('decliningEngagement')}>
                  <ChevronRight size={16} /> Declining Engagement (2)
                </button>
                {openSubSections.decliningEngagement && (
                  <ul className='ml-4 mt-1 space-y-1 text-xs'>
                    <li className='cursor-pointer hover:underline' onClick={() => handlePopup("40% drop in email opens, no recent file activity — investigate")}>
                      ## Veridian Technologies
                    </li>
                    <li className='cursor-pointer hover:underline' onClick={() => handlePopup("No responses to last 2 follow-ups — check for product or service issues")}>
                      ## Mosaic Manufacturing
                    </li>
                  </ul>
                )}
              </li>
              <li>
                {/* Added whitespace-nowrap */}
                <button className='text-sm text-blue-300 flex items-center gap-2 px-2 py-1 rounded hover:bg-gray-700 whitespace-nowrap' onClick={() => toggleSubSection('highPotentialLowTouch')}>
                  <ChevronRight size={16} /> High-Potential, Low-Touch (2)
                </button>
                {openSubSections.highPotentialLowTouch && (
                  <ul className='ml-4 mt-1 space-y-1 text-xs'>
                    <li className='cursor-pointer hover:underline' onClick={() => handlePopup("High product usage, but no recent strategic interaction — suggest planning session")}>
                      ## Clearview Logistics
                    </li>
                    <li className='cursor-pointer hover:underline' onClick={() => handlePopup("Revenue grew 18% YoY — explore cross-sell opportunity")}>
                      ## HarborPoint Software
                    </li>
                  </ul>
                )}
              </li>
              <li>
                {/* Added whitespace-nowrap */}
                <button className='text-sm text-blue-300 flex items-center gap-2 px-2 py-1 rounded hover:bg-gray-700 whitespace-nowrap' onClick={() => toggleSubSection('nearTermRisk')}>
                  <ChevronRight size={16} /> Near-Term Risk (2)
                </button>
                {openSubSections.nearTermRisk && (
                  <ul className='ml-4 mt-1 space-y-1 text-xs'>
                    <li className='cursor-pointer hover:underline' onClick={() => handlePopup("Loan renewal in 2 weeks, no meeting scheduled")}>
                      ## UnionBridge Holdings
                    </li>
                    <li className='cursor-pointer hover:underline' onClick={() => handlePopup("Credit line nearing limit — review structure proactively")}>
                      ## CrescentCare Health
                    </li>
                  </ul>
                )}
              </li>
            </ul>
          )}
        </li>

        <li>
          <button className='font-semibold w-full text-left flex items-center gap-2' onClick={() => toggleSection('myEngagements')}>
            <Briefcase size={16} /> My Engagements
          </button>
          {openSections.myEngagements && (
            <ul className='ml-4 mt-1 space-y-1'> {/* Reverted to space-y-1 */}
              <li>
                <button className='text-sm text-blue-300 flex items-center gap-2 px-2 py-1 rounded hover:bg-gray-700 whitespace-nowrap' onClick={() => toggleSubSection('interactions')}>
                  <ChevronRight size={16} /> Interactions (3)
                </button>
                {openSubSections.interactions && (
                  <ul className='ml-4 mt-1 space-y-1 text-xs'>
                    <li className='cursor-pointer hover:underline' onClick={() => handlePopup("Shared internal forecast, awaiting follow-up")}>
                      ## Altura Finance
                    </li>
                    <li className='cursor-pointer hover:underline' onClick={() => handlePopup("Replied with interest in loan restructuring")}>
                      ## Coral Technologies
                    </li>
                    <li className='cursor-pointer hover:underline' onClick={() => handlePopup("Downloaded whitepaper on FX strategies")}>
                      ## Trinity BioMed
                    </li>
                  </ul>
                )}
              </li>
              <li>
                <button className='text-sm text-blue-300 flex items-center gap-2 px-2 py-1 rounded hover:bg-gray-700 whitespace-nowrap' onClick={() => toggleSubSection('meetings')}>
                  <ChevronRight size={16} /> Meetings (2)
                </button>
                {openSubSections.meetings && (
                  <ul className='ml-4 mt-1 space-y-1 text-xs'>
                    <li className='cursor-pointer hover:underline' onClick={() => handlePopup("QBR scheduled next Tuesday at 10:00 AM")}>
                      ## EastPoint Energy
                    </li>
                    <li className='cursor-pointer hover:underline' onClick={() => handlePopup("Missed previous call, reschedule recommended")}>
                      ## SilverTree Group
                    </li>
                  </ul>
                )}
              </li>
              <li>
                <button className='text-sm text-blue-300 flex items-center gap-2 px-2 py-1 rounded hover:bg-gray-700 whitespace-nowrap' onClick={() => toggleSubSection('email')}>
                  <ChevronRight size={16} /> Email (2)
                </button>
                {openSubSections.email && (
                  <ul className='ml-4 mt-1 space-y-1 text-xs'>
                    <li className='cursor-pointer hover:underline' onClick={() => handlePopup("Asked for updated term sheet by Friday")}>
                      ## Summit Lending
                    </li>
                    <li className='cursor-pointer hover:underline' onClick={() => handlePopup("Forwarded internal compliance questions, marked urgent")}>
                      ## NovaCraft Systems
                    </li>
                  </ul>
                )}
              </li>
              <li>
                <button className='text-sm text-blue-300 flex items-center gap-2 px-2 py-1 rounded hover:bg-gray-700 whitespace-nowrap' onClick={() => toggleSubSection('campaigns')}>
                  <ChevronRight size={16} /> Campaigns (1)
                </button>
                {openSubSections.campaigns && (
                  <ul className='ml-4 mt-1 space-y-1 text-xs'>
                    <li className='cursor-pointer hover:underline' onClick={() => handlePopup("Clicked ESG fund offering in last email campaign")}>
                      ## BlueCanyon Group
                    </li>
                  </ul>
                )}
              </li>
              <li>
                <button className='text-sm text-blue-300 flex items-center gap-2 px-2 py-1 rounded hover:bg-gray-700 whitespace-nowrap' onClick={() => toggleSubSection('engagementsRecommendations')}>
                  <ChevronRight size={16} /> Recommendations (3)
                </button>
                {openSubSections.engagementsRecommendations && (
                  <ul className='ml-4 mt-1 space-y-1 text-xs'>
                    <li className='cursor-pointer hover:underline' onClick={() => handlePopup("Send follow-up email regarding treasury demo")}>
                      ## Nexora Inc.
                    </li>
                    <li className='cursor-pointer hover:underline' onClick={() => handlePopup("Schedule QBR before renewal window")}>
                      ## Aegis Industrial
                    </li>
                    <li className='cursor-pointer hover:underline' onClick={() => handlePopup("Share new sector insights tailored to healthcare outlook")}>
                      ## Pinnacle Pharma
                    </li>
                  </ul>
                )}
              </li>
            </ul>
          )}
        </li>

        <li>
          <button className='font-semibold w-full text-left flex items-center gap-2' onClick={() => toggleSection('myClients')}>
            <Users size={16} /> My Clients
          </button>
          {openSections.myClients && (
            <ul className='ml-4 mt-1 space-y-1'> {/* Reverted to space-y-1 */}
              <li>
                <button className='text-sm text-blue-300 flex items-center gap-2 px-2 py-1 rounded hover:bg-gray-700 whitespace-nowrap' onClick={() => toggleSubSection('accountSummary')}>
                  <ChevronRight size={16} /> Account Summary (2)
                </button>
                {openSubSections.accountSummary && (
                  <ul className='ml-4 mt-1 space-y-1 text-xs'>
                    <li className='cursor-pointer hover:underline' onClick={() => handlePopup("Key Account, updated Q2 financials available")}>
                      ## Lakeside Holdings
                    </li>
                    <li className='cursor-pointer hover:underline' onClick={() => handlePopup("Net income declined 12%, monitor account health")}>
                      ## Evergreen Inc.
                    </li>
                  </ul>
                )}
              </li>
              <li>
                <button className='text-sm text-blue-300 flex items-center gap-2 px-2 py-1 rounded hover:bg-gray-700 whitespace-nowrap' onClick={() => toggleSubSection('capitalUsage')}>
                  <ChevronRight size={16} /> Capital Usage (1)
                </button>
                {openSubSections.capitalUsage && (
                  <ul className='ml-4 mt-1 space-y-1 text-xs'>
                    <li className='cursor-pointer hover:underline' onClick={() => handlePopup("78% of credit line utilized, review lending strategy")}>
                      ## Riverview Partners
                    </li>
                  </ul>
                )}
              </li>
              <li>
                <button className='text-sm text-blue-300 flex items-center gap-2 px-2 py-1 rounded hover:bg-gray-700 whitespace-nowrap' onClick={() => toggleSubSection('creditExposure')}>
                  <ChevronRight size={16} /> Credit Exposure (1)
                </button>
                {openSubSections.creditExposure && (
                  <ul className='ml-4 mt-1 space-y-1 text-xs'>
                    <li className='cursor-pointer hover:underline' onClick={() => handlePopup("High credit exposure flagged, consider collateral review")}>
                      ## Horizon Logistics
                    </li>
                  </ul>
                )}
              </li>
              <li>
                <button className='text-sm text-blue-300 flex items-center gap-2 px-2 py-1 rounded hover:bg-gray-700 whitespace-nowrap' onClick={() => toggleSubSection('connections')}>
                  <ChevronRight size={16} /> Connections (2)
                </button>
                {openSubSections.connections && (
                  <ul className='ml-4 mt-1 space-y-1 text-xs'>
                    <li className='cursor-pointer hover:underline' onClick={() => handlePopup("No contact in 45 days, re-engage relationship manager")}>
                      ## Orion Energy
                    </li>
                    <li className='cursor-pointer hover:underline' onClick={() => handlePopup("New CFO added to relationship, introduce key contacts")}>
                      ## Maple Group
                    </li>
                  </ul>
                )}
              </li>
              <li>
                <button className='text-sm text-blue-300 flex items-center gap-2 px-2 py-1 rounded hover:bg-gray-700 whitespace-nowrap' onClick={() => toggleSubSection('clientsRecommendations')}>
                  <ChevronRight size={16} /> Recommendations (3)
                </button>
                {openSubSections.clientsRecommendations && (
                  <ul className='ml-4 mt-1 space-y-1 text-xs'>
                    <li className='cursor-pointer hover:underline' onClick={() => handlePopup("Recommend line-of-credit upsell, good fit based on cash flow")}>
                      ## Zenith Corp
                    </li>
                    <li className='cursor-pointer hover:underline' onClick={() => handlePopup("Share commercial card product comparison")}>
                      ## Apex Foods
                    </li>
                    <li className='cursor-pointer hover:underline' onClick={() => handlePopup("Schedule strategic planning session this quarter")}>
                      ## BrightStar Tech
                    </li>
                  </ul>
                )}
              </li>
            </ul>
          )}
        </li>

        <li>
          <button className='font-semibold w-full text-left flex items-center gap-2' onClick={() => toggleSection('myProspects')}>
            <Target size={16} /> My Prospects
          </button>
          {openSections.myProspects && (
            <ul className='ml-4 mt-1 space-y-1'> {/* Reverted to space-y-1 */}
              <li>
                <button className='text-sm text-blue-300 flex items-center gap-2 px-2 py-1 rounded hover:bg-gray-700 whitespace-nowrap' onClick={() => toggleSubSection('prospectInteractions')}>
                  <ChevronRight size={16} /> Interactions (3)
                </button>
                {openSubSections.prospectInteractions && (
                  <ul className='ml-4 mt-1 space-y-1 text-xs'>
                    <li className='cursor-pointer hover:underline' onClick={() => handlePopup("Opened pitch deck 3 times, no follow-up call scheduled")}>
                      ## Stonebridge Capital
                    </li>
                    <li className='cursor-pointer hover:underline' onClick={() => handlePopup("Attended treasury webinar, rated 4.8/5 — high interest")}>
                      ## Nimbus Solutions
                    </li>
                    <li className='cursor-pointer hover:underline' onClick={() => handlePopup("Replied to intro email, asked for ESG case study")}>
                      ## Pacific Horizons
                    </li>
                  </ul>
                )}
              </li>
              <li>
                <button className='text-sm text-blue-300 flex items-center gap-2 px-2 py-1 rounded hover:bg-gray-700 whitespace-nowrap' onClick={() => toggleSubSection('prospectRecommendations')}>
                  <ChevronRight size={16} /> Recommendations (3)
                </button>
                {openSubSections.prospectRecommendations && (
                  <ul className='ml-4 mt-1 space-y-1 text-xs'>
                    <li className='cursor-pointer hover:underline' onClick={() => handlePopup("Send comparison of LOC vs. term loan")}>
                      ## Vertex Dynamics
                    </li>
                    <li className='cursor-pointer hover:underline' onClick={() => handlePopup("Recommend business card with cash-back program")}>
                      ## Echo Retail
                    </li>
                    <li className='cursor-pointer hover:underline' onClick={() => handlePopup("Invite to upcoming commercial strategy roundtable")}>
                      ## Summit Analytics
                    </li>
                  </ul>
                )}
              </li>
            </ul>
          )}
        </li>
      </ul>
    </aside>
  );
};

export default Sidebar;