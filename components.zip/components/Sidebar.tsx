import React, { useState } from 'react';
import {
  Layers,
  Briefcase,
  Users,
  Target,
  ChevronRight, // Common icon for all layer 2 items
  Info, // Icon for Layer 3 items in the modal
} from 'lucide-react';

const Sidebar = () => {
  const [openSections, setOpenSections] = useState<{ [key: string]: boolean }>({
    portfolioPrioritization: true, // Set to true to expand on start
    myEngagements: true,           // Set to true to expand on start
    myClients: true,               // Set to true to expand on start
    myProspects: true,             // Set to true to expand on start
  });

  // State to manage the visibility of the Layer 3 modal
  const [showLayer3Modal, setShowLayer3Modal] = useState(false);
  // State to hold the content (Layer 3 items) for the modal
  const [layer3ModalContent, setLayer3ModalContent] = useState<{ text: string; message: string; }[]>([]);
  const [modalTitle, setModalTitle] = useState(''); // To set the title of the modal based on Layer 2 item

  const toggleSection = (section: string) => {
    setOpenSections((prev) => ({ ...prev, [section]: !prev[section] }));
  };

  // Function to show the Layer 3 modal with specific content
  const showLayer3Details = (title: string, items: { text: string; message: string; }[]) => {
    setModalTitle(title);
    setLayer3ModalContent(items);
    setShowLayer3Modal(true);
  };

  const closeLayer3Modal = () => {
    setShowLayer3Modal(false);
    setLayer3ModalContent([]);
    setModalTitle('');
  };

  // Define Layer 3 content for each Layer 2 category
  const portfolioPrioritizationDetails = {
    contactOverdue: [
      { text: "Stratus Capital Partners", message: "⏱️ No contact in 3 months — re-engage to maintain relationship tier" },
      { text: "Redwood Energy Group", message: "Last meeting was 90 days ago — schedule QBR or health check-in" },
    ],
    decliningEngagement: [
      { text: "Veridian Technologies", message: "40% drop in email opens, no recent file activity — investigate" },
      { text: "Mosaic Manufacturing", message: "No responses to last 2 follow-ups — check for product or service issues" },
    ],
    highPotentialLowTouch: [
      { text: "Clearview Logistics", message: "High product usage, but no recent strategic interaction — suggest planning session" },
      { text: "HarborPoint Software", message: "Revenue grew 18% YoY — explore cross-sell opportunity" },
    ],
    nearTermRisk: [
      { text: "UnionBridge Holdings", message: "Loan renewal in 2 weeks, no meeting scheduled" },
      { text: "CrescentCare Health", message: "Credit line nearing limit — review structure proactively" },
    ],
  };

  const myEngagementsDetails = {
    interactions: [
      { text: "Altura Finance", message: "Shared internal forecast, awaiting follow-up" },
      { text: "Coral Technologies", message: "Replied with interest in loan restructuring" },
      { text: "Trinity BioMed", message: "Downloaded whitepaper on FX strategies" },
    ],
    meetings: [
      { text: "EastPoint Energy", message: "QBR scheduled next Tuesday at 10:00 AM" },
      { text: "SilverTree Group", message: "Missed previous call, reschedule recommended" },
    ],
    email: [
      { text: "Summit Lending", message: "Asked for updated term sheet by Friday" },
      { text: "NovaCraft Systems", message: "Forwarded internal compliance questions, marked urgent" },
    ],
    campaigns: [
      { text: "BlueCanyon Group", message: "Clicked ESG fund offering in last email campaign" },
    ],
    engagementsRecommendations: [
      { text: "Nexora Inc.", message: "Send follow-up email regarding treasury demo" },
      { text: "Aegis Industrial", message: "Schedule QBR before renewal window" },
      { text: "Pinnacle Pharma", message: "Share new sector insights tailored to healthcare outlook" },
    ],
  };

  const myClientsDetails = {
    accountSummary: [
      { text: "Lakeside Holdings", message: "Key Account, updated Q2 financials available" },
      { text: "Evergreen Inc.", message: "Net income declined 12%, monitor account health" },
    ],
    capitalUsage: [
      { text: "Riverview Partners", message: "78% of credit line utilized, review lending strategy" },
    ],
    creditExposure: [
      { text: "Horizon Logistics", message: "High credit exposure flagged, consider collateral review" },
    ],
    connections: [
      { text: "Orion Energy", message: "No contact in 45 days, re-engage relationship manager" },
      { text: "Maple Group", message: "New CFO added to relationship, introduce key contacts" },
    ],
    clientsRecommendations: [
      { text: "Zenith Corp", message: "Recommend line-of-credit upsell, good fit based on cash flow" },
      { text: "Apex Foods", message: "Share commercial card product comparison" },
      { text: "BrightStar Tech", message: "Schedule strategic planning session this quarter" },
    ],
  };

  const myProspectsDetails = {
    prospectInteractions: [
      { text: "Stonebridge Capital", message: "Opened pitch deck 3 times, no follow-up call scheduled" },
      { text: "Nimbus Solutions", message: "Attended treasury webinar, rated 4.8/5 — high interest" },
      { text: "Pacific Horizons", message: "Replied to intro email, asked for ESG case study" },
    ],
    prospectRecommendations: [
      { text: "Vertex Dynamics", message: "Send comparison of LOC vs. term loan" },
      { text: "Echo Retail", message: "Recommend business card with cash-back program" },
      { text: "Summit Analytics", message: "Invite to upcoming commercial strategy roundtable" },
    ],
  };

  return (
    <aside className='w-72 bg-[#112B45] p-6 text-white h-full overflow-y-auto'>
      <h1 className='text-2xl font-bold mb-6'>AI Insights</h1> {/* Changed "AI Assistant" to "AI Insights" */}

      <ul className='space-y-2'>
        <li>
          <button className='font-semibold w-full text-left flex items-center gap-2' onClick={() => toggleSection('portfolioPrioritization')}>
            <Layers size={16} /> Portfolio Prioritization
          </button>
          {openSections.portfolioPrioritization && (
            <ul className='ml-4 mt-1 space-y-1'>
              <li>
                <button
                  className='text-sm text-blue-300 flex items-center gap-2 px-2 py-1 rounded hover:bg-gray-700 whitespace-nowrap'
                  onClick={() => showLayer3Details('Contact Overdue (2)', portfolioPrioritizationDetails.contactOverdue)}
                >
                  <ChevronRight size={16} /> Contact Overdue (2)
                </button>
              </li>
              <li>
                <button
                  className='text-sm text-blue-300 flex items-center gap-2 px-2 py-1 rounded hover:bg-gray-700 whitespace-nowrap'
                  onClick={() => showLayer3Details('Declining Engagement (2)', portfolioPrioritizationDetails.decliningEngagement)}
                >
                  <ChevronRight size={16} /> Declining Engagement (2)
                </button>
              </li>
              <li>
                <button
                  className='text-sm text-blue-300 flex items-center gap-2 px-2 py-1 rounded hover:bg-gray-700 whitespace-nowrap'
                  onClick={() => showLayer3Details('High-Potential, Low-Touch (2)', portfolioPrioritizationDetails.highPotentialLowTouch)}
                >
                  <ChevronRight size={16} /> High-Potential, Low-Touch (2)
                </button>
              </li>
              <li>
                <button
                  className='text-sm text-blue-300 flex items-center gap-2 px-2 py-1 rounded hover:bg-gray-700 whitespace-nowrap'
                  onClick={() => showLayer3Details('Near-Term Risk (2)', portfolioPrioritizationDetails.nearTermRisk)}
                >
                  <ChevronRight size={16} /> Near-Term Risk (2)
                </button>
              </li>
            </ul>
          )}
        </li>

        <li>
          <button className='font-semibold w-full text-left flex items-center gap-2' onClick={() => toggleSection('myEngagements')}>
            <Briefcase size={16} /> My Engagements
          </button>
          {openSections.myEngagements && (
            <ul className='ml-4 mt-1 space-y-1'>
              <li>
                <button
                  className='text-sm text-blue-300 flex items-center gap-2 px-2 py-1 rounded hover:bg-gray-700 whitespace-nowrap'
                  onClick={() => showLayer3Details('Interactions (3)', myEngagementsDetails.interactions)}
                >
                  <ChevronRight size={16} /> Interactions (3)
                </button>
              </li>
              <li>
                <button
                  className='text-sm text-blue-300 flex items-center gap-2 px-2 py-1 rounded hover:bg-gray-700 whitespace-nowrap'
                  onClick={() => showLayer3Details('Meetings (2)', myEngagementsDetails.meetings)}
                >
                  <ChevronRight size={16} /> Meetings (2)
                </button>
              </li>
              <li>
                <button
                  className='text-sm text-blue-300 flex items-center gap-2 px-2 py-1 rounded hover:bg-gray-700 whitespace-nowrap'
                  onClick={() => showLayer3Details('Email (2)', myEngagementsDetails.email)}
                >
                  <ChevronRight size={16} /> Email (2)
                </button>
              </li>
              <li>
                <button
                  className='text-sm text-blue-300 flex items-center gap-2 px-2 py-1 rounded hover:bg-gray-700 whitespace-nowrap'
                  onClick={() => showLayer3Details('Campaigns (1)', myEngagementsDetails.campaigns)}
                >
                  <ChevronRight size={16} /> Campaigns (1)
                </button>
              </li>
              <li>
                <button
                  className='text-sm text-blue-300 flex items-center gap-2 px-2 py-1 rounded hover:bg-gray-700 whitespace-nowrap'
                  onClick={() => showLayer3Details('Recommendations (3)', myEngagementsDetails.engagementsRecommendations)}
                >
                  <ChevronRight size={16} /> Recommendations (3)
                </button>
              </li>
            </ul>
          )}
        </li>

        <li>
          <button className='font-semibold w-full text-left flex items-center gap-2' onClick={() => toggleSection('myClients')}>
            <Users size={16} /> My Clients
          </button>
          {openSections.myClients && (
            <ul className='ml-4 mt-1 space-y-1'>
              <li>
                <button
                  className='text-sm text-blue-300 flex items-center gap-2 px-2 py-1 rounded hover:bg-gray-700 whitespace-nowrap'
                  onClick={() => showLayer3Details('Account Summary (2)', myClientsDetails.accountSummary)}
                >
                  <ChevronRight size={16} /> Account Summary (2)
                </button>
              </li>
              <li>
                <button
                  className='text-sm text-blue-300 flex items-center gap-2 px-2 py-1 rounded hover:bg-gray-700 whitespace-nowrap'
                  onClick={() => showLayer3Details('Capital Usage (1)', myClientsDetails.capitalUsage)}
                >
                  <ChevronRight size={16} /> Capital Usage (1)
                </button>
              </li>
              <li>
                <button
                  className='text-sm text-blue-300 flex items-center gap-2 px-2 py-1 rounded hover:bg-gray-700 whitespace-nowrap'
                  onClick={() => showLayer3Details('Credit Exposure (1)', myClientsDetails.creditExposure)}
                >
                  <ChevronRight size={16} /> Credit Exposure (1)
                </button>
              </li>
              <li>
                <button
                  className='text-sm text-blue-300 flex items-center gap-2 px-2 py-1 rounded hover:bg-gray-700 whitespace-nowrap'
                  onClick={() => showLayer3Details('Connections (2)', myClientsDetails.connections)}
                >
                  <ChevronRight size={16} /> Connections (2)
                </button>
              </li>
              <li>
                <button
                  className='text-sm text-blue-300 flex items-center gap-2 px-2 py-1 rounded hover:bg-gray-700 whitespace-nowrap'
                  onClick={() => showLayer3Details('Recommendations (3)', myClientsDetails.clientsRecommendations)}
                >
                  <ChevronRight size={16} /> Recommendations (3)
                </button>
              </li>
            </ul>
          )}
        </li>

        <li>
          <button className='font-semibold w-full text-left flex items-center gap-2' onClick={() => toggleSection('myProspects')}>
            <Target size={16} /> My Prospects
          </button>
          {openSections.myProspects && (
            <ul className='ml-4 mt-1 space-y-1'>
              <li>
                <button
                  className='text-sm text-blue-300 flex items-center gap-2 px-2 py-1 rounded hover:bg-gray-700 whitespace-nowrap'
                  onClick={() => showLayer3Details('Interactions (3)', myProspectsDetails.prospectInteractions)}
                >
                  <ChevronRight size={16} /> Interactions (3)
                </button>
              </li>
              <li>
                <button
                  className='text-sm text-blue-300 flex items-center gap-2 px-2 py-1 rounded hover:bg-gray-700 whitespace-nowrap'
                  onClick={() => showLayer3Details('Recommendations (3)', myProspectsDetails.prospectRecommendations)}
                >
                  <ChevronRight size={16} /> Recommendations (3)
                </button>
              </li>
            </ul>
          )}
        </li>
      </ul>

      {/* Layer 3 Pop-up Modal */}
      {showLayer3Modal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 backdrop-blur-sm flex justify-center items-center z-50">
          <div className="bg-[#1f2937] rounded-2xl shadow-xl p-6 max-w-[600px] w-full animate-slide-in text-white border border-blue-600">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-lg font-semibold">{modalTitle}</h2>
              <button onClick={closeLayer3Modal} className="text-gray-300 hover:text-white text-xl">×</button>
            </div>
            <ul className="list-none space-y-2 text-xs">
              {layer3ModalContent.map((item, idx) => (
                <li key={idx} className="flex items-start gap-2">
                  <Info size={16} className="mt-1 flex-shrink-0" />
                  <span className="flex-1">
                    <span className="font-semibold">{item.text}</span> → {item.message}
                  </span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      )}
    </aside>
  );
};

export default Sidebar;