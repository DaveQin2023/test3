# agent_framework/config_validator.py

import yaml
from typing import Dict, List, Set, Tuple, Optional
from pathlib import Path
import inspect

from agent_framework.conditions import CONDITIONS, get_available_conditions
from api_library.tool_registry import TOOL_CATEGORIES, get_available_categories

class ValidationError(Exception):
    """Custom exception for validation errors."""
    pass

class ConfigValidator:
    """
    Validates agent and workflow configurations to catch errors early.
    """
    
    def __init__(self, 
                 agents_config_path: str = "config/agents.yaml",
                 workflows_config_path: str = "config/workflows.yaml"):
        self.agents_config_path = Path(agents_config_path)
        self.workflows_config_path = Path(workflows_config_path)
        self.errors: List[str] = []
        self.warnings: List[str] = []
        
    def validate_all(self) -> bool:
        """
        Validate all configurations and return True if valid.
        """
        print("🔍 Starting configuration validation...")
        self.errors.clear()
        self.warnings.clear()
        
        try:
            # 1. Validate file existence
            self._validate_files_exist()
            
            # 2. Load and validate YAML syntax
            agents_config = self._load_and_validate_yaml(self.agents_config_path)
            workflows_config = self._load_and_validate_yaml(self.workflows_config_path)
            
            # 3. Validate structure and content
            self._validate_agents_config(agents_config)
            self._validate_workflows_config(workflows_config)
            
            # 4. Cross-validate dependencies
            self._validate_cross_references(agents_config, workflows_config)
            
            # 5. Validate tool registry
            self._validate_tool_registry()
            
            # 6. Validate conditions
            self._validate_conditions()
            
            # Report results
            self._report_results()
            
            return len(self.errors) == 0
            
        except Exception as e:
            self.errors.append(f"Validation failed with exception: {e}")
            self._report_results()
            return False
    
    def _validate_files_exist(self):
        """Check if configuration files exist."""
        if not self.agents_config_path.exists():
            self.errors.append(f"Agents config file not found: {self.agents_config_path}")
        
        if not self.workflows_config_path.exists():
            self.errors.append(f"Workflows config file not found: {self.workflows_config_path}")
    
    def _load_and_validate_yaml(self, file_path: Path) -> Dict:
        """Load YAML file and validate syntax."""
        try:
            with open(file_path, 'r') as f:
                config = yaml.safe_load(f)
            
            if config is None:
                self.errors.append(f"Empty or invalid YAML file: {file_path}")
                return {}
            
            print(f"✅ Loaded {file_path}")
            return config
            
        except yaml.YAMLError as e:
            self.errors.append(f"YAML syntax error in {file_path}: {e}")
            return {}
        except Exception as e:
            self.errors.append(f"Error reading {file_path}: {e}")
            return {}
    
    def _validate_agents_config(self, config: Dict):
        """Validate agents configuration structure and content."""
        if "agents" not in config:
            self.errors.append("Agents config missing 'agents' section")
            return
        
        agents = config["agents"]
        if not isinstance(agents, dict):
            self.errors.append("'agents' section must be a dictionary")
            return
        
        if not agents:
            self.warnings.append("No agents defined in agents config")
            return
        
        # Validate each agent
        for agent_name, agent_config in agents.items():
            self._validate_single_agent(agent_name, agent_config)
    
    def _validate_single_agent(self, agent_name: str, agent_config: Dict):
        """Validate a single agent configuration."""
        context = f"Agent '{agent_name}'"
        
        # Required fields
        if "description" not in agent_config:
            self.warnings.append(f"{context}: Missing description")
        
        # Validate tools
        if "tools" in agent_config:
            tools = agent_config["tools"]
            if isinstance(tools, list):
                self._validate_agent_tools(agent_name, tools)
            else:
                self.errors.append(f"{context}: 'tools' must be a list")
        else:
            self.warnings.append(f"{context}: No tools specified, will use default")
        
        # Validate workflow reference
        if "workflow" in agent_config:
            workflow = agent_config["workflow"]
            if not isinstance(workflow, str):
                self.errors.append(f"{context}: 'workflow' must be a string")
        
        # Validate LLM model
        if "llm_model" in agent_config:
            model = agent_config["llm_model"]
            if not isinstance(model, str):
                self.errors.append(f"{context}: 'llm_model' must be a string")
            elif not model.strip():
                self.errors.append(f"{context}: 'llm_model' cannot be empty")
    
    def _validate_agent_tools(self, agent_name: str, tools: List):
        """Validate agent tool references."""
        context = f"Agent '{agent_name}'"
        available_categories = get_available_categories()
        
        for tool in tools:
            if not isinstance(tool, str):
                self.errors.append(f"{context}: Tool reference must be string, got {type(tool)}")
                continue
            
            if tool == "all":
                continue  # "all" is valid
            
            if tool not in available_categories:
                self.errors.append(f"{context}: Unknown tool category '{tool}'. Available: {available_categories}")
    
    def _validate_workflows_config(self, config: Dict):
        """Validate workflows configuration structure and content."""
        if "workflows" not in config:
            self.errors.append("Workflows config missing 'workflows' section")
            return
        
        workflows = config["workflows"]
        if not isinstance(workflows, dict):
            self.errors.append("'workflows' section must be a dictionary")
            return
        
        if not workflows:
            self.warnings.append("No workflows defined in workflows config")
            return
        
        # Validate each workflow
        for workflow_name, workflow_config in workflows.items():
            self._validate_single_workflow(workflow_name, workflow_config)
    
    def _validate_single_workflow(self, workflow_name: str, workflow_config: Dict):
        """Validate a single workflow configuration."""
        context = f"Workflow '{workflow_name}'"
        
        # Required fields
        if "nodes" not in workflow_config:
            self.errors.append(f"{context}: Missing 'nodes' section")
            return
        
        if "flow" not in workflow_config:
            self.errors.append(f"{context}: Missing 'flow' section")
            return
        
        # Validate nodes
        nodes = workflow_config["nodes"]
        if not isinstance(nodes, list):
            self.errors.append(f"{context}: 'nodes' must be a list")
            return
        
        node_names = self._validate_workflow_nodes(workflow_name, nodes)
        
        # Validate flow
        flow = workflow_config["flow"]
        if not isinstance(flow, list):
            self.errors.append(f"{context}: 'flow' must be a list")
            return
        
        self._validate_workflow_flow(workflow_name, flow, node_names)
        
        # Validate entry point
        self._validate_workflow_entry_point(workflow_name, workflow_config, node_names)
    
    def _validate_workflow_nodes(self, workflow_name: str, nodes: List) -> Set[str]:
        """Validate workflow nodes and return set of node names."""
        context = f"Workflow '{workflow_name}'"
        node_names = set()
        
        valid_node_types = ["agent_node", "tool_node", "human_review_node", "validation_node"]
        
        for i, node in enumerate(nodes):
            if not isinstance(node, dict):
                self.errors.append(f"{context}: Node {i} must be a dictionary")
                continue
            
            # Validate name
            if "name" not in node:
                self.errors.append(f"{context}: Node {i} missing 'name'")
                continue
            
            node_name = node["name"]
            if not isinstance(node_name, str) or not node_name.strip():
                self.errors.append(f"{context}: Node {i} 'name' must be non-empty string")
                continue
            
            if node_name in node_names:
                self.errors.append(f"{context}: Duplicate node name '{node_name}'")
            else:
                node_names.add(node_name)
            
            # Validate type
            if "type" not in node:
                self.errors.append(f"{context}: Node '{node_name}' missing 'type'")
                continue
            
            node_type = node["type"]
            if node_type not in valid_node_types:
                self.errors.append(f"{context}: Node '{node_name}' invalid type '{node_type}'. Valid: {valid_node_types}")
            
            # Validate type-specific fields
            if node_type == "agent_node" and "system_message" in node:
                if not isinstance(node["system_message"], str):
                    self.errors.append(f"{context}: Node '{node_name}' system_message must be string")
        
        return node_names
    
    def _validate_workflow_flow(self, workflow_name: str, flow: List, node_names: Set[str]):
        """Validate workflow flow edges."""
        context = f"Workflow '{workflow_name}'"
        available_conditions = get_available_conditions()
        
        for i, edge in enumerate(flow):
            if not isinstance(edge, dict):
                self.errors.append(f"{context}: Flow edge {i} must be a dictionary")
                continue
            
            # Validate from/to
            if "from" not in edge:
                self.errors.append(f"{context}: Flow edge {i} missing 'from'")
                continue
            
            if "to" not in edge:
                self.errors.append(f"{context}: Flow edge {i} missing 'to'")
                continue
            
            from_node = edge["from"]
            to_node = edge["to"]
            
            # Validate node references
            self._validate_node_reference(context, f"edge {i}", from_node, node_names, "from")
            self._validate_node_reference(context, f"edge {i}", to_node, node_names, "to")
            
            # Validate conditions
            if "condition" in edge:
                condition = edge["condition"]
                if not isinstance(condition, str):
                    self.errors.append(f"{context}: Edge {i} condition must be string")
                elif condition not in available_conditions:
                    self.errors.append(f"{context}: Edge {i} unknown condition '{condition}'. Available: {available_conditions}")
            
            # Validate edge types
            if "type" in edge:
                edge_type = edge["type"]
                valid_types = ["simple", "parallel", "join"]
                if edge_type not in valid_types:
                    self.errors.append(f"{context}: Edge {i} invalid type '{edge_type}'. Valid: {valid_types}")
                
                # Validate parallel/join specific fields
                if edge_type in ["parallel", "join"]:
                    if not isinstance(from_node, list) and not isinstance(to_node, list):
                        self.warnings.append(f"{context}: Edge {i} type '{edge_type}' but from/to are not lists")
    
    def _validate_node_reference(self, context: str, edge_desc: str, node_ref, node_names: Set[str], direction: str):
        """Validate a node reference in flow."""
        if isinstance(node_ref, list):
            # List of nodes (for parallel/join)
            for node in node_ref:
                if not isinstance(node, str):
                    self.errors.append(f"{context}: {edge_desc} {direction} list contains non-string: {node}")
                elif node != "END" and node not in node_names:
                    self.errors.append(f"{context}: {edge_desc} {direction} references unknown node '{node}'")
        elif isinstance(node_ref, str):
            # Single node
            if node_ref != "END" and node_ref not in node_names:
                self.errors.append(f"{context}: {edge_desc} {direction} references unknown node '{node_ref}'")
        else:
            self.errors.append(f"{context}: {edge_desc} {direction} must be string or list, got {type(node_ref)}")
    
    def _validate_workflow_entry_point(self, workflow_name: str, workflow_config: Dict, node_names: Set[str]):
        """Validate workflow entry point."""
        context = f"Workflow '{workflow_name}'"
        
        if "entry_point" in workflow_config:
            entry_point = workflow_config["entry_point"]
            if not isinstance(entry_point, str):
                self.errors.append(f"{context}: entry_point must be string")
            elif entry_point not in node_names:
                self.errors.append(f"{context}: entry_point '{entry_point}' not found in nodes")
        else:
            # Default to first node
            if node_names:
                self.warnings.append(f"{context}: No entry_point specified, will use first node")
    
    def _validate_cross_references(self, agents_config: Dict, workflows_config: Dict):
        """Validate cross-references between agents and workflows."""
        if "agents" not in agents_config or "workflows" not in workflows_config:
            return
        
        available_workflows = set(workflows_config["workflows"].keys())
        
        for agent_name, agent_config in agents_config["agents"].items():
            if "workflow" in agent_config:
                workflow = agent_config["workflow"]
                if workflow not in available_workflows:
                    self.errors.append(f"Agent '{agent_name}' references unknown workflow '{workflow}'. Available: {available_workflows}")
    
    def _validate_tool_registry(self):
        """Validate tool registry consistency."""
        try:
            from api_library.tool_registry import TOOL_CATEGORIES
            
            if not TOOL_CATEGORIES:
                self.warnings.append("No tool categories defined in tool registry")
                return
            
            # Check if all tools are properly imported
            for category, tools in TOOL_CATEGORIES.items():
                if not tools:
                    self.warnings.append(f"Tool category '{category}' is empty")
                    continue
                
                for tool in tools:
                    if not hasattr(tool, 'name'):
                        self.errors.append(f"Tool in category '{category}' missing 'name' attribute: {tool}")
                    if not hasattr(tool, 'description'):
                        self.warnings.append(f"Tool '{getattr(tool, 'name', 'unknown')}' missing description")
                    if not callable(tool):
                        self.errors.append(f"Tool '{getattr(tool, 'name', 'unknown')}' is not callable")
            
            print(f"✅ Validated {len(TOOL_CATEGORIES)} tool categories")
            
        except ImportError as e:
            self.errors.append(f"Could not import tool registry: {e}")
        except Exception as e:
            self.errors.append(f"Error validating tool registry: {e}")
    
    def _validate_conditions(self):
        """Validate condition functions."""
        try:
            from agent_framework.conditions import CONDITIONS
            
            if not CONDITIONS:
                self.errors.append("No conditions defined in conditions registry")
                return
            
            # Check each condition function
            for condition_name, condition_func in CONDITIONS.items():
                if not callable(condition_func):
                    self.errors.append(f"Condition '{condition_name}' is not callable")
                    continue
                
                # Check function signature
                sig = inspect.signature(condition_func)
                params = list(sig.parameters.keys())
                
                if len(params) != 1:
                    self.errors.append(f"Condition '{condition_name}' must take exactly 1 parameter (state), got {len(params)}")
                elif params[0] != 'state':
                    self.warnings.append(f"Condition '{condition_name}' parameter should be named 'state', got '{params[0]}'")
                
                # Check return type annotation
                if sig.return_annotation != bool and sig.return_annotation != inspect.Signature.empty:
                    self.warnings.append(f"Condition '{condition_name}' should return bool")
            
            print(f"✅ Validated {len(CONDITIONS)} condition functions")
            
        except ImportError as e:
            self.errors.append(f"Could not import conditions: {e}")
        except Exception as e:
            self.errors.append(f"Error validating conditions: {e}")
    
    def _report_results(self):
        """Report validation results."""
        print("\n" + "="*60)
        print("🔍 CONFIGURATION VALIDATION RESULTS")
        print("="*60)
        
        if not self.errors and not self.warnings:
            print("✅ All validations passed! Configuration is valid.")
            return
        
        if self.warnings:
            print(f"\n⚠️  WARNINGS ({len(self.warnings)}):")
            for i, warning in enumerate(self.warnings, 1):
                print(f"   {i}. {warning}")
        
        if self.errors:
            print(f"\n❌ ERRORS ({len(self.errors)}):")
            for i, error in enumerate(self.errors, 1):
                print(f"   {i}. {error}")
            print("\n💡 Please fix these errors before running the system.")
        else:
            print("\n✅ No critical errors found.")
        
        print("="*60)

def validate_configuration() -> bool:
    """
    Convenience function to validate all configuration.
    Returns True if configuration is valid.
    """
    validator = ConfigValidator()
    return validator.validate_all()

# CLI usage
if __name__ == "__main__":
    import sys
    
    print("🔧 Configuration Validator")
    print("-" * 30)
    
    is_valid = validate_configuration()
    
    if is_valid:
        print("\n🎉 Configuration is ready to use!")
        sys.exit(0)
    else:
        print("\n❌ Configuration has errors. Please fix them.")
        sys.exit(1)