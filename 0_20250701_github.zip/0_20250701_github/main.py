# main.py

import os
from pathlib import Path

# Set up environment
os.environ["OPENAI_API_KEY"] = "your-actual-api-key-here"

from agent_framework.workflow_builder import WorkflowBuilder, create_agent

def demo_simple_usage():
    """Demo the simplest possible usage."""
    print("⚡ SIMPLE USAGE DEMO")
    print("=" * 30)
    
    # One-liner agent creation and usage
    print("Creating customer support agent...")
    agent = create_agent("customer_support")
    
    response = agent.chat("What's the weather like today?")
    print(f"Response: {response}")
    
    print("\nCreating sales assistant...")
    sales_agent = create_agent("sales_assistant")
    response = sales_agent.chat("Tell me about current opportunities")
    print(f"Response: {response}")

def demo_different_agents():
    """Demo different agent personalities and capabilities."""
    print("\n🤖 DIFFERENT AGENTS DEMO")
    print("=" * 35)
    
    builder = WorkflowBuilder()
    
    # Show available agents
    agents = builder.list_agents()
    print("\n📋 Available Agents:")
    for agent_id, description in agents.items():
        print(f"  🔹 {agent_id}: {description}")
    
    # Test different agents with same query
    test_query = "I need help with a technical issue"
    
    test_agents = ["customer_support", "it_helpdesk", "general_assistant"]
    
    for agent_name in test_agents:
        print(f"\n🎯 Testing {agent_name}:")
        try:
            agent = create_agent(agent_name)
            response = agent.chat(test_query)
            print(f"   Response: {response}")
        except Exception as e:
            print(f"   ❌ Error: {e}")

def demo_different_workflows():
    """Demo different workflow patterns."""
    print("\n🏗️ DIFFERENT WORKFLOWS DEMO")
    print("=" * 40)
    
    builder = WorkflowBuilder()
    
    # Show available workflows
    workflows = builder.list_workflows()
    print("\n📋 Available Workflows:")
    for workflow_id, description in workflows.items():
        print(f"  🔹 {workflow_id}: {description}")
    
    # Demo escalation workflow
    print(f"\n🚨 Testing Escalation Workflow (IT Helpdesk):")
    try:
        it_agent = create_agent("it_helpdesk")
        response = it_agent.chat("URGENT: Server is down, all users affected!")
        print(f"   Response: {response}")
    except Exception as e:
        print(f"   ❌ Error: {e}")

def demo_conversation_memory():
    """Demo conversation with memory."""
    print("\n💬 CONVERSATION MEMORY DEMO")
    print("=" * 40)
    
    agent = create_agent("customer_support")
    
    conversation = [
        "Hi, I'm having trouble with my account",
        "What's your return policy?",
        "Can you help me with that issue I mentioned?"
    ]
    
    chat_history = []
    
    for user_message in conversation:
        print(f"\n👤 User: {user_message}")
        
        response = agent.chat(user_message, chat_history)
        print(f"🤖 Agent: {response}")
        
        # Add to history
        chat_history.append(("user", user_message))
        chat_history.append(("assistant", response))

def demo_tool_filtering():
    """Demo how different agents get different tools."""
    print("\n🔧 TOOL FILTERING DEMO")
    print("=" * 30)
    
    from api_library.tool_registry import get_tools_by_categories, get_available_categories
    
    print("📦 Available Tool Categories:")
    categories = get_available_categories()
    for category in categories:
        tools = get_tools_by_categories([category])
        print(f"  🔹 {category}: {len(tools)} tools")
        for tool in tools:
            print(f"     - {tool.name}")
    
    print(f"\n🎯 Agent Tool Access:")
    builder = WorkflowBuilder()
    builder.load_configs()
    
    for agent_name, agent_config in builder.agents_config["agents"].items():
        tool_categories = agent_config.get("tools", [])
        if tool_categories == ["all"]:
            tool_count = len(get_tools_by_categories(categories))
        else:
            tool_count = len(get_tools_by_categories(tool_categories))
        print(f"  🤖 {agent_name}: {tool_categories} ({tool_count} tools)")

def create_required_directories():
    """Create required directories and files."""
    directories = [
        "config",
        "agent_framework", 
        "api_library"
    ]
    
    for directory in directories:
        Path(directory).mkdir(exist_ok=True)
        init_file = Path(directory) / "__init__.py"
        init_file.touch()

def main():
    """Main demonstration function."""
    print("🎯 CONFIGURABLE AI AGENT FRAMEWORK DEMO")
    print("=" * 50)
    print("This framework supports:")
    print("✅ Configurable agents via YAML")
    print("✅ Configurable workflows via YAML") 
    print("✅ Tool filtering by agent type")
    print("✅ Multiple workflow patterns")
    print("✅ Conditional branching, loops, parallel execution")
    print("✅ One-liner agent creation")
    
    try:
        # Setup
        create_required_directories()
        
        # Run demos
        demo_simple_usage()
        demo_different_agents()
        demo_different_workflows()
        demo_conversation_memory()
        demo_tool_filtering()
        
        print("\n🎉 DEMO COMPLETED SUCCESSFULLY!")
        print("=" * 35)
        
        print(f"\n🚀 Your configurable AI agent framework includes:")
        print(f"✅ Agent definitions in config/agents.yaml")
        print(f"✅ Workflow patterns in config/workflows.yaml")
        print(f"✅ Explicit tool registry in api_library/tool_registry.py")
        print(f"✅ Workflow conditions in agent_framework/conditions.py")
        print(f"✅ Enhanced workflow builder in agent_framework/workflow_builder.py")
        
        print(f"\n📝 Usage Examples:")
        print(f"  🔸 agent = create_agent('customer_support')")
        print(f"  🔸 response = agent.chat('How can I help?')")
        print(f"  🔸 sales_agent = create_agent('sales_assistant')")
        
        print(f"\n🛠️ To customize:")
        print(f"  1. Add new agents in config/agents.yaml")
        print(f"  2. Create new workflows in config/workflows.yaml")
        print(f"  3. Add tools to api_library/tool_registry.py")
        print(f"  4. Add conditions to agent_framework/conditions.py")
        
    except Exception as e:
        print(f"\n❌ Demo failed: {e}")
        print("Make sure:")
        print("1. All required packages are installed (langchain, langgraph, openai, pyyaml)")
        print("2. OPENAI_API_KEY environment variable is set")
        print("3. All configuration files are in place")

if __name__ == "__main__":
    main()