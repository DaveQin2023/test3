# agent_framework/conditions.py

from agent_framework.agent_nodes import AgentState
from langchain_core.agents import ToolInvocation

# Core workflow conditions
def needs_tool(state: AgentState) -> bool:
    """Check if the agent wants to call a tool."""
    return isinstance(state.get("agent_outcome"), ToolInvocation)

def always_true(state: AgentState) -> bool:
    """Always returns True - for unconditional edges."""
    return True

def always_false(state: AgentState) -> bool:
    """Always returns False."""
    return False

def has_errors(state: AgentState) -> bool:
    """Check if there are errors in the tool output."""
    tool_output = str(state.get("tool_output", ""))
    return "error" in tool_output.lower() or "failed" in tool_output.lower()

def validation_passed(state: AgentState) -> bool:
    """Check if validation was successful."""
    return state.get("validation_result") == "passed"

def validation_failed(state: AgentState) -> bool:
    """Check if validation failed."""
    return state.get("validation_result") == "failed"

# Priority-based conditions
def is_low_priority(state: AgentState) -> bool:
    """Check if the request is low priority."""
    priority = state.get("priority", "").lower()
    return priority in ["low", "routine", "normal"]

def is_medium_priority(state: AgentState) -> bool:
    """Check if the request is medium priority."""
    priority = state.get("priority", "").lower()
    return priority in ["medium", "standard"]

def is_high_priority(state: AgentState) -> bool:
    """Check if the request is high priority."""
    priority = state.get("priority", "").lower()
    return priority in ["high", "urgent", "critical", "emergency"]

# Business logic conditions
def needs_approval(state: AgentState) -> bool:
    """Check if the request needs approval."""
    amount = state.get("amount", 0)
    return amount > 1000  # Requests over $1000 need approval

def budget_approved(state: AgentState) -> bool:
    """Check if budget is approved."""
    return state.get("budget_approved", False)

def budget_insufficient(state: AgentState) -> bool:
    """Check if budget is insufficient."""
    return not state.get("budget_approved", False)

def amount_under_10k(state: AgentState) -> bool:
    """Check if amount is under $10,000."""
    return state.get("amount", 0) < 10000

def amount_over_10k(state: AgentState) -> bool:
    """Check if amount is $10,000 or more."""
    return state.get("amount", 0) >= 10000

def approved(state: AgentState) -> bool:
    """Check if request was approved."""
    return state.get("approval_status") == "approved"

def rejected(state: AgentState) -> bool:
    """Check if request was rejected."""
    return state.get("approval_status") == "rejected"

# Content-based conditions
def contains_urgent(state: AgentState) -> bool:
    """Check if input contains urgent keywords."""
    input_text = state.get("input", "").lower()
    urgent_keywords = ["urgent", "emergency", "critical", "asap", "immediate"]
    return any(keyword in input_text for keyword in urgent_keywords)

def contains_support_keywords(state: AgentState) -> bool:
    """Check if input contains support-related keywords."""
    input_text = state.get("input", "").lower()
    support_keywords = ["help", "support", "issue", "problem", "ticket", "bug"]
    return any(keyword in input_text for keyword in support_keywords)

def contains_sales_keywords(state: AgentState) -> bool:
    """Check if input contains sales-related keywords."""
    input_text = state.get("input", "").lower()
    sales_keywords = ["opportunity", "deal", "lead", "prospect", "sales", "revenue"]
    return any(keyword in input_text for keyword in sales_keywords)

# Registry of all available conditions
CONDITIONS = {
    "needs_tool": needs_tool,
    "always_true": always_true,
    "always_false": always_false,
    "has_errors": has_errors,
    "validation_passed": validation_passed,
    "validation_failed": validation_failed,
    "is_low_priority": is_low_priority,
    "is_medium_priority": is_medium_priority,
    "is_high_priority": is_high_priority,
    "needs_approval": needs_approval,
    "budget_approved": budget_approved,
    "budget_insufficient": budget_insufficient,
    "amount_under_10k": amount_under_10k,
    "amount_over_10k": amount_over_10k,
    "approved": approved,
    "rejected": rejected,
    "contains_urgent": contains_urgent,
    "contains_support_keywords": contains_support_keywords,
    "contains_sales_keywords": contains_sales_keywords,
}

def get_condition_function(condition_name: str):
    """Get a condition function by name."""
    return CONDITIONS.get(condition_name)

def get_available_conditions():
    """Get list of available condition names."""
    return list(CONDITIONS.keys())