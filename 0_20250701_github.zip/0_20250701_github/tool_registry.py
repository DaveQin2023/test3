# api_library/tool_registry.py

# Explicit tool imports - you control what's available
from api_library.tools_general import get_current_weather, get_current_time
from api_library.tools_knowledge_base import query_main_knowledge_base

# Import other tools as needed (currently commented out in your existing code)
# from api_library.tools_jira import create_jira_issue, get_jira_issue_details
# from api_library.tools_salesforce import get_salesforce_opportunity_details
# from api_library.tools_confluence import create_confluence_page
# from api_library.tools_figma import get_figma_file_info
# from api_library.tools_database import get_db_account_summary

# Tool categories for filtering
TOOL_CATEGORIES = {
    "general": [
        get_current_weather,
        get_current_time
    ],
    "knowledge_base": [
        query_main_knowledge_base
    ],
    # Add more categories as you enable tools
    # "jira": [
    #     create_jira_issue,
    #     get_jira_issue_details
    # ],
    # "salesforce": [
    #     get_salesforce_opportunity_details
    # ],
    # "confluence": [
    #     create_confluence_page
    # ],
    # "figma": [
    #     get_figma_file_info
    # ],
    # "database": [
    #     get_db_account_summary
    # ]
}

def get_all_tools():
    """Get all available tools across all categories."""
    all_tools = []
    for tools in TOOL_CATEGORIES.values():
        all_tools.extend(tools)
    return all_tools

def get_tools_by_categories(categories):
    """Get tools filtered by categories."""
    if categories == ["all"] or categories == "all":
        return get_all_tools()
    
    filtered_tools = []
    for category in categories:
        if category in TOOL_CATEGORIES:
            filtered_tools.extend(TOOL_CATEGORIES[category])
    return filtered_tools

def get_available_categories():
    """Get list of available tool categories."""
    return list(TOOL_CATEGORIES.keys())