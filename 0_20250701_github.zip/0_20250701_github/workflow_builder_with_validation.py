# agent_framework/workflow_builder.py (Enhanced with Validation)

import yaml
from typing import List, Dict, Any, Union
from langgraph.graph import StateGraph, END
from pathlib import Path

from agent_framework.agent_nodes import AgentState, agent_node, tool_node, AgentFinish
from agent_framework.conditions import get_condition_function
from agent_framework.config_validator import ConfigValidator, ValidationError
from api_library.tool_registry import get_tools_by_categories

class WorkflowBuilder:
    """
    Enhanced workflow builder with automatic validation.
    """
    
    def __init__(self, 
                 agents_config_path: str = "config/agents.yaml",
                 workflows_config_path: str = "config/workflows.yaml",
                 validate_on_load: bool = True):
        self.agents_config_path = agents_config_path
        self.workflows_config_path = workflows_config_path
        self.validate_on_load = validate_on_load
        self.agents_config = {}
        self.workflows_config = {}
        self.current_agent = None
        self.current_workflow = None
        self.app = None
        self._validated = False
        
    def load_configs(self):
        """Load both agent and workflow configurations with validation."""
        if self.validate_on_load and not self._validated:
            print("🔍 Validating configuration before loading...")
            validator = ConfigValidator(self.agents_config_path, self.workflows_config_path)
            
            if not validator.validate_all():
                raise ValidationError("Configuration validation failed. Please fix errors before proceeding.")
            
            self._validated = True
            print("✅ Configuration validation passed!")
        
        self.load_agents_config()
        self.load_workflows_config()
    
    def load_agents_config(self):
        """Load agent configurations from YAML."""
        try:
            with open(self.agents_config_path, 'r') as f:
                self.agents_config = yaml.safe_load(f)
            print(f"✅ Loaded agents config from: {self.agents_config_path}")
        except FileNotFoundError:
            raise ValidationError(f"Agents config file not found: {self.agents_config_path}")
        except yaml.YAMLError as e:
            raise ValidationError(f"Error parsing agents YAML: {e}")
    
    def load_workflows_config(self):
        """Load workflow configurations from YAML."""
        try:
            with open(self.workflows_config_path, 'r') as f:
                self.workflows_config = yaml.safe_load(f)
            print(f"✅ Loaded workflows config from: {self.workflows_config_path}")
        except FileNotFoundError:
            raise ValidationError(f"Workflows config file not found: {self.workflows_config_path}")
        except yaml.YAMLError as e:
            raise ValidationError(f"Error parsing workflows YAML: {e}")
    
    def set_agent(self, agent_name: str):
        """Set which agent configuration to use."""
        if not self.agents_config:
            self.load_configs()
            
        if agent_name not in self.agents_config.get("agents", {}):
            available = list(self.agents_config.get("agents", {}).keys())
            raise ValidationError(f"Agent '{agent_name}' not found. Available: {available}")
        
        self.current_agent = agent_name
        agent_config = self.agents_config["agents"][agent_name]
        
        # Set workflow if specified in agent config
        if "workflow" in agent_config:
            self.current_workflow = agent_config["workflow"]
        else:
            self.current_workflow = "simple_chat"  # Default workflow
            
        # Validate workflow exists
        if not self.workflows_config:
            self.load_workflows_config()
            
        if self.current_workflow not in self.workflows_config.get("workflows", {}):
            available = list(self.workflows_config.get("workflows", {}).keys())
            raise ValidationError(f"Workflow '{self.current_workflow}' not found. Available: {available}")
            
        print(f"🤖 Selected agent: {agent_name}")
        print(f"🔄 Using workflow: {self.current_workflow}")
        
    def build_graph(self):
        """Build the workflow graph for current agent and workflow."""
        if not self.current_agent:
            raise ValidationError("No agent selected. Call set_agent() first.")
        
        if not self.workflows_config:
            self.load_configs()
        
        agent_config = self.agents_config["agents"][self.current_agent]
        workflow_config = self.workflows_config["workflows"][self.current_workflow]
        
        # Validate agent tools are available
        tool_categories = agent_config.get("tools", ["general"])
        try:
            tools = get_tools_by_categories(tool_categories)
            print(f"🔧 Agent will have access to {len(tools)} tools from categories: {tool_categories}")
        except Exception as e:
            raise ValidationError(f"Error getting tools for agent '{self.current_agent}': {e}")
        
        # Create the graph
        graph = StateGraph(AgentState)
        
        # Track created nodes for validation
        created_nodes = set()
        
        # Add nodes based on workflow configuration
        for node in workflow_config["nodes"]:
            node_name = node["name"]
            node_type = node["type"]
            
            if node_type == "agent_node":
                # Create agent node with configuration
                def create_agent_node(node_config=node, agent_cfg=agent_config):
                    def configured_agent_node(state: AgentState):
                        # Get system message from node or use default
                        system_message = node_config.get("system_message", "You are a helpful AI assistant.")
                        
                        # Get tools for this agent
                        tool_categories = agent_cfg.get("tools", ["general"])
                        tools = get_tools_by_categories(tool_categories)
                        
                        return agent_node(
                            state,
                            llm_model=agent_cfg.get("llm_model", "gpt-4o"),
                            system_message=system_message,
                            available_tools=tools
                        )
                    return configured_agent_node
                
                graph.add_node(node_name, create_agent_node())
                
            elif node_type == "tool_node":
                graph.add_node(node_name, tool_node)
                
            elif node_type == "human_review_node":
                # Human review node with validation
                def create_human_review_node(instructions=node.get("instructions", "Please review and approve.")):
                    def human_review_node(state: AgentState):
                        print(f"🔍 Human Review Required: {instructions}")
                        print(f"Current state: {state.get('input', 'No input')}")
                        # In real implementation, this would pause and wait for human input
                        # For demo, we'll auto-approve
                        state["approval_status"] = "approved"
                        return {"approval_status": "approved"}
                    return human_review_node
                
                graph.add_node(node_name, create_human_review_node())
                
            elif node_type == "validation_node":
                # Validation node with rules
                def create_validation_node(validation_rules=node.get("rules", [])):
                    def validation_node(state: AgentState):
                        print(f"✅ Validating with rules: {validation_rules}")
                        # Mock validation logic - in real implementation, apply actual rules
                        validation_result = "passed"  # or "failed" based on rules
                        return {"validation_result": validation_result}
                    return validation_node
                
                graph.add_node(node_name, create_validation_node())
                
            else:
                raise ValidationError(f"Unknown node type: {node_type}")
                
            created_nodes.add(node_name)
            print(f"  ✅ Added {node_type}: {node_name}")
        
        # Set entry point with validation
        entry_point = workflow_config.get("entry_point")
        if entry_point:
            if entry_point not in created_nodes:
                raise ValidationError(f"Entry point '{entry_point}' not found in workflow nodes")
        else:
            # Use first node as entry point
            entry_point = workflow_config["nodes"][0]["name"]
            print(f"  ℹ️  Using first node as entry point: {entry_point}")
        
        graph.set_entry_point(entry_point)
        
        # Add edges based on workflow configuration with validation
        for edge in workflow_config["flow"]:
            source = edge["from"]
            target = edge["to"]
            condition_name = edge.get("condition")
            edge_type = edge.get("type", "simple")
            
            # Validate source and target nodes
            self._validate_edge_nodes(source, target, created_nodes)
            
            # Handle special target
            if target == "END":
                target_node = END
            else:
                target_node = target
            
            try:
                # Handle different edge types
                if edge_type == "parallel":
                    # Parallel execution (simplified for demo)
                    if isinstance(target, list):
                        for t in target:
                            if t not in created_nodes:
                                raise ValidationError(f"Parallel target node '{t}' not found")
                            graph.add_edge(source, t)
                            print(f"  ✅ Added parallel edge: {source} -> {t}")
                    else:
                        graph.add_edge(source, target_node)
                        print(f"  ✅ Added edge: {source} -> {target}")
                        
                elif edge_type == "join":
                    # Join multiple sources (simplified)
                    if isinstance(source, list):
                        for s in source:
                            if s not in created_nodes:
                                raise ValidationError(f"Join source node '{s}' not found")
                            graph.add_edge(s, target_node)
                            print(f"  ✅ Added join edge: {s} -> {target}")
                    else:
                        graph.add_edge(source, target_node)
                        print(f"  ✅ Added edge: {source} -> {target}")
                        
                elif condition_name:
                    # Conditional edge with validation
                    condition_func = get_condition_function(condition_name)
                    if not condition_func:
                        raise ValidationError(f"Unknown condition function: {condition_name}")
                    
                    # Handle conditional mapping
                    if target_node != END:
                        # Simple true/false mapping
                        graph.add_conditional_edges(
                            source,
                            condition_func,
                            {True: target_node, False: END}
                        )
                    else:
                        # Use condition map if provided
                        condition_map = edge.get("condition_map", {"continue": target_node, "end": END})
                        graph.add_conditional_edges(source, condition_func, condition_map)
                    
                    print(f"  ✅ Added conditional edge: {source} -> {target} (condition: {condition_name})")
                    
                else:
                    # Simple unconditional edge
                    graph.add_edge(source, target_node)
                    print(f"  ✅ Added edge: {source} -> {target}")
                    
            except Exception as e:
                raise ValidationError(f"Error creating edge {source} -> {target}: {e}")
        
        # Compile the graph with error handling
        try:
            self.app = graph.compile()
            print(f"✅ Built workflow '{self.current_workflow}' for agent '{self.current_agent}'")
        except Exception as e:
            raise ValidationError(f"Error compiling workflow graph: {e}")
        
    def _validate_edge_nodes(self, source, target, created_nodes: set):
        """Validate that edge source and target nodes exist."""
        # Handle list of nodes (for parallel/join)
        sources = source if isinstance(source, list) else [source]
        targets = target if isinstance(target, list) else [target]
        
        for s in sources:
            if s not in created_nodes:
                raise ValidationError(f"Source node '{s}' not found in workflow")
        
        for t in targets:
            if t != "END" and t not in created_nodes:
                raise ValidationError(f"Target node '{t}' not found in workflow")
    
    def chat(self, message: str, chat_history: List = None) -> str:
        """Simple chat interface with error handling."""
        if not self.app:
            raise ValidationError("No workflow built. Call build_graph() first.")
        
        # Convert chat history
        messages = []
        if chat_history:
            for role, content in chat_history:
                if role == "user":
                    messages.append(("human", content))
                elif role == "assistant":
                    messages.append(("ai", content))
        
        # Initial state
        initial_state = {
            "input": message,
            "chat_history": messages,
            "agent_outcome": None,
            "tool_input": None,
            "tool_output": ""
        }
        
        try:
            # Run the workflow
            final_state = self.app.invoke(initial_state)
            
            # Extract response
            if isinstance(final_state.get("agent_outcome"), AgentFinish):
                response = final_state["agent_outcome"].return_values["output"]
            elif final_state.get("tool_output"):
                response = f"Task completed. Result: {final_state['tool_output']}"
            else:
                response = "I'm not sure how to help with that."
                
            return response
            
        except Exception as e:
            return f"Sorry, I encountered an error during workflow execution: {e}"
    
    def list_agents(self) -> Dict[str, str]:
        """List all available agents."""
        if not self.agents_config:
            self.load_configs()
            
        agents = {}
        for agent_id, agent_config in self.agents_config.get("agents", {}).items():
            agents[agent_id] = agent_config.get("description", agent_id)
        
        return agents
    
    def list_workflows(self) -> Dict[str, str]:
        """List all available workflows."""
        if not self.workflows_config:
            self.load_configs()
            
        workflows = {}
        for workflow_id, workflow_config in self.workflows_config.get("workflows", {}).items():
            workflows[workflow_id] = workflow_config.get("description", workflow_id)
        
        return workflows
    
    def validate_current_config(self) -> bool:
        """Validate the current configuration."""
        try:
            validator = ConfigValidator(self.agents_config_path, self.workflows_config_path)
            return validator.validate_all()
        except Exception as e:
            print(f"❌ Validation error: {e}")
            return False

# Enhanced helper function with validation
def create_agent(agent_name: str, validate: bool = True) -> WorkflowBuilder:
    """
    Create and configure an agent in one step with optional validation.
    """
    try:
        builder = WorkflowBuilder(validate_on_load=validate)
        builder.set_agent(agent_name)
        builder.build_graph()
        return builder
    except ValidationError as e:
        print(f"❌ Agent creation failed: {e}")
        raise
    except Exception as e:
        print(f"❌ Unexpected error creating agent: {e}")
        raise ValidationError(f"Failed to create agent '{agent_name}': {e}")

# Safe agent creation that handles errors gracefully
def create_agent_safe(agent_name: str, validate: bool = True) -> tuple[WorkflowBuilder, bool]:
    """
    Create agent and return (agent, success) tuple.
    Returns (None, False) if creation fails.
    """
    try:
        agent = create_agent(agent_name, validate)
        return agent, True
    except Exception as e:
        print(f"❌ Failed to create agent '{agent_name}': {e}")
        return None, False