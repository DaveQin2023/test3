"""
Clean LangGraph Orchestrator - No External Dependencies
"""

import json
import asyncio
import os
from datetime import datetime
from typing import Dict, List, Any, Optional
from dataclasses import dataclass
from enum import Enum

# LangGraph imports
from langgraph.graph import StateGraph, END
from langchain_core.messages import HumanMessage
from langchain_openai import ChatOpenAI

# =====================================================
# AGENT STATE MANAGEMENT
# =====================================================

@dataclass
class OrchestratorState:
    """State object that flows through the LangGraph workflow"""
    user_query: str
    available_data_summary: str
    identified_intent: str
    confidence_score: float
    decomposed_tasks: List[Dict[str, Any]]
    execution_plan: List[str]
    current_step: str
    step_count: int = 0
    errors: List[str] = None
    
    def __post_init__(self):
        if self.errors is None:
            self.errors = []

class BankingIntent(Enum):
    """Banking-specific user intents"""
    CLIENT_OVERVIEW = "client_overview"
    OPPORTUNITY_ANALYSIS = "opportunity_analysis" 
    RISK_ASSESSMENT = "risk_assessment"
    PRODUCT_RECOMMENDATION = "product_recommendation"
    MEETING_PLANNING = "meeting_planning"
    PORTFOLIO_REVIEW = "portfolio_review"
    CREDIT_ANALYSIS = "credit_analysis"
    GENERAL_INQUIRY = "general_inquiry"

# =====================================================
# DATA MANAGER (Simple Version)
# =====================================================

class SimpleBankingDataManager:
    """Simple data manager without external dependencies"""
    
    def __init__(self):
        self.data_path = "data"
    
    def get_data_summary(self) -> str:
        """Get a summary of available data"""
        try:
            import os
            if not os.path.exists(self.data_path):
                return "No data directory found. Mock data summary:\n- accounts: 4 records\n- opportunities: 4 records\n- interactions: 4 records"
            
            # Try to read actual data files
            data_files = [f for f in os.listdir(self.data_path) if f.endswith('.json')]
            summary = "Available Banking Data Sources:\n"
            
            for file in data_files:
                try:
                    with open(os.path.join(self.data_path, file), 'r') as f:
                        data = json.load(f)
                        summary += f"- {file.replace('.json', '')}: {len(data)} records\n"
                except:
                    summary += f"- {file.replace('.json', '')}: Error reading file\n"
            
            return summary if data_files else "No JSON data files found in data directory"
            
        except Exception as e:
            return f"Error accessing data: {str(e)}\nUsing mock summary:\n- TechFlow accounts: 4 entities\n- Opportunities: 4 records\n- Recent interactions: 4 records"

# =====================================================
# INTENT IDENTIFICATION AGENT
# =====================================================

class IntentIdentificationAgent:
    """Agent responsible for identifying user intent with confidence scoring"""
    
    def __init__(self, llm):
        self.llm = llm
    
    async def identify_intent(self, user_query: str, available_data: str) -> tuple[str, float]:
        """Identify user intent and return confidence score"""
        
        prompt = f"""
        You are a banking AI assistant specialized in understanding relationship manager queries.
        
        USER QUERY: "{user_query}"
        
        AVAILABLE DATA SOURCES:
        {available_data}
        
        AVAILABLE INTENTS:
        1. CLIENT_OVERVIEW - Comprehensive information about specific clients/accounts
        2. OPPORTUNITY_ANALYSIS - Analyzing sales opportunities and pipeline management
        3. RISK_ASSESSMENT - Credit risk analysis and exposure evaluation
        4. PRODUCT_RECOMMENDATION - Suggesting banking products for clients
        5. MEETING_PLANNING - Scheduling and preparing for client meetings
        6. PORTFOLIO_REVIEW - Overall portfolio performance and analysis
        7. CREDIT_ANALYSIS - Detailed credit facility and usage analysis
        8. GENERAL_INQUIRY - General banking questions or simple requests
        
        TASK:
        1. Analyze the user query carefully
        2. Determine the most appropriate intent
        3. Provide a confidence score (0-100)
        4. Consider the available data when making your decision
        
        RESPONSE FORMAT:
        Intent: [INTENT_NAME]
        Confidence: [0-100]
        Reasoning: [Brief explanation of why this intent was chosen]
        """
        
        response = await self.llm.ainvoke([HumanMessage(content=prompt)])
        content = response.content
        
        # Parse response
        intent = "GENERAL_INQUIRY"  # Default
        confidence = 50.0  # Default
        
        lines = content.split('\n')
        for line in lines:
            if line.startswith('Intent:'):
                intent = line.replace('Intent:', '').strip()
            elif line.startswith('Confidence:'):
                try:
                    confidence = float(line.replace('Confidence:', '').strip())
                except ValueError:
                    confidence = 50.0
        
        return intent.upper(), confidence

# =====================================================
# TASK DECOMPOSITION AGENT
# =====================================================

class TaskDecompositionAgent:
    """Agent responsible for breaking down complex queries into executable tasks"""
    
    def __init__(self, llm):
        self.llm = llm
    
    async def decompose_tasks(self, user_query: str, intent: str, available_data: str) -> List[Dict[str, Any]]:
        """Decompose user query into specific executable tasks"""
        
        prompt = f"""
        You are a banking task decomposition specialist. Break down the user's request into specific, actionable tasks.
        
        USER QUERY: "{user_query}"
        IDENTIFIED INTENT: {intent}
        
        AVAILABLE DATA SOURCES:
        {available_data}
        
        TASK DECOMPOSITION GUIDELINES:
        
        For CLIENT_OVERVIEW:
        - Gather account summaries and basic info
        - Collect recent interactions and emails
        - Review current products and services
        - Check outstanding tasks and opportunities
        - Analyze credit exposure and utilization
        
        For OPPORTUNITY_ANALYSIS:
        - Review current opportunities and pipeline
        - Analyze opportunity stages and probabilities
        - Identify potential cross-sell opportunities
        - Check recent client interactions
        - Review meeting schedules and follow-ups
        
        For RISK_ASSESSMENT:
        - Analyze credit exposure data
        - Review utilization rates and limits
        - Check risk ratings and probability of default
        - Examine recent financial performance
        - Identify potential risk factors
        
        OUTPUT FORMAT (JSON):
        [
            {{
                "task_id": "T001",
                "task_name": "Descriptive task name",
                "task_type": "data_gathering|analysis|recommendation|synthesis",
                "priority": "high|medium|low",
                "data_sources": ["list", "of", "required", "data", "sources"],
                "expected_output": "Description of expected output",
                "estimated_time": "estimated time in seconds"
            }}
        ]
        
        Generate 3-7 specific tasks that will fully address the user's query.
        """
        
        response = await self.llm.ainvoke([HumanMessage(content=prompt)])
        content = response.content
        
        # Extract JSON from response
        try:
            # Find JSON content between ```json and ``` or just look for array
            if '```json' in content:
                json_start = content.find('```json') + 7
                json_end = content.find('```', json_start)
                json_content = content[json_start:json_end]
            else:
                # Look for array pattern
                start = content.find('[')
                end = content.rfind(']') + 1
                json_content = content[start:end] if start != -1 and end != 0 else '[]'
            
            tasks = json.loads(json_content)
            
            # Validate and ensure proper structure
            validated_tasks = []
            for i, task in enumerate(tasks):
                validated_task = {
                    "task_id": task.get("task_id", f"T{i+1:03d}"),
                    "task_name": task.get("task_name", f"Task {i+1}"),
                    "task_type": task.get("task_type", "analysis"),
                    "priority": task.get("priority", "medium"),
                    "data_sources": task.get("data_sources", []),
                    "expected_output": task.get("expected_output", "Analysis results"),
                    "estimated_time": task.get("estimated_time", "30")
                }
                validated_tasks.append(validated_task)
            
            return validated_tasks
            
        except json.JSONDecodeError as e:
            print(f"Error parsing JSON: {e}")
            # Return a default task structure
            return [{
                "task_id": "T001",
                "task_name": "Analyze user query",
                "task_type": "analysis",
                "priority": "high",
                "data_sources": ["accounts", "opportunities"],
                "expected_output": "Query analysis results",
                "estimated_time": "60"
            }]

# =====================================================
# EXECUTION PLANNING AGENT
# =====================================================

class ExecutionPlanningAgent:
    """Agent responsible for creating execution plan from decomposed tasks"""
    
    def __init__(self, llm):
        self.llm = llm
    
    async def create_execution_plan(self, tasks: List[Dict[str, Any]], intent: str) -> List[str]:
        """Create step-by-step execution plan"""
        
        # Sort tasks by priority
        priority_order = {"high": 1, "medium": 2, "low": 3}
        sorted_tasks = sorted(tasks, key=lambda x: priority_order.get(x["priority"], 2))
        
        plan_steps = []
        plan_steps.append(f"🎯 Executing plan for: {intent}")
        plan_steps.append(f"📋 Total tasks identified: {len(tasks)}")
        plan_steps.append("")
        
        for i, task in enumerate(sorted_tasks, 1):
            step = f"Step {i}: {task['task_name']}"
            step += f" (Priority: {task['priority']}, Type: {task['task_type']})"
            plan_steps.append(step)
            
            if task['data_sources']:
                plan_steps.append(f"   📊 Data sources: {', '.join(task['data_sources'])}")
            
            plan_steps.append(f"   🎯 Expected output: {task['expected_output']}")
            plan_steps.append("")
        
        return plan_steps

# =====================================================
# LANGGRAPH WORKFLOW NODES
# =====================================================

async def data_summary_node(state: OrchestratorState) -> OrchestratorState:
    """Node to gather available data summary"""
    try:
        data_manager = SimpleBankingDataManager()
        summary = data_manager.get_data_summary()
        
        state.available_data_summary = summary
        state.current_step = "Data summary completed"
        state.step_count += 1
        
    except Exception as e:
        state.errors.append(f"Data summary error: {str(e)}")
        state.available_data_summary = "Error loading data summary"
    
    return state

async def intent_identification_node(state: OrchestratorState) -> OrchestratorState:
    """Node to identify user intent"""
    try:
        # Get OpenAI API key from environment
        api_key = os.getenv("OPENAI_API_KEY")
        if not api_key:
            raise ValueError("OPENAI_API_KEY not found in environment variables")
        
        # Initialize LLM
        llm = ChatOpenAI(
            model="gpt-4o", 
            temperature=0.3, 
            max_tokens=1500,
            api_key=api_key
        )
        
        intent_agent = IntentIdentificationAgent(llm)
        intent, confidence = await intent_agent.identify_intent(
            state.user_query, 
            state.available_data_summary
        )
        
        state.identified_intent = intent
        state.confidence_score = confidence
        state.current_step = f"Intent identified: {intent} (confidence: {confidence}%)"
        state.step_count += 1
        
    except Exception as e:
        state.errors.append(f"Intent identification error: {str(e)}")
        state.identified_intent = "GENERAL_INQUIRY"
        state.confidence_score = 0.0
    
    return state

async def task_decomposition_node(state: OrchestratorState) -> OrchestratorState:
    """Node to decompose tasks"""
    try:
        # Get OpenAI API key from environment
        api_key = os.getenv("OPENAI_API_KEY")
        if not api_key:
            raise ValueError("OPENAI_API_KEY not found in environment variables")
        
        # Initialize LLM  
        llm = ChatOpenAI(
            model="gpt-4o", 
            temperature=0.3, 
            max_tokens=2000,
            api_key=api_key
        )
        
        decomposition_agent = TaskDecompositionAgent(llm)
        tasks = await decomposition_agent.decompose_tasks(
            state.user_query,
            state.identified_intent,
            state.available_data_summary
        )
        
        state.decomposed_tasks = tasks
        state.current_step = f"Tasks decomposed: {len(tasks)} tasks identified"
        state.step_count += 1
        
    except Exception as e:
        state.errors.append(f"Task decomposition error: {str(e)}")
        state.decomposed_tasks = []
    
    return state

async def execution_planning_node(state: OrchestratorState) -> OrchestratorState:
    """Node to create execution plan"""
    try:
        # Get OpenAI API key from environment
        api_key = os.getenv("OPENAI_API_KEY")
        if not api_key:
            raise ValueError("OPENAI_API_KEY not found in environment variables")
        
        # Initialize LLM
        llm = ChatOpenAI(
            model="gpt-4o", 
            temperature=0.3, 
            max_tokens=1500,
            api_key=api_key
        )
        
        planning_agent = ExecutionPlanningAgent(llm)
        execution_plan = await planning_agent.create_execution_plan(
            state.decomposed_tasks,
            state.identified_intent
        )
        
        state.execution_plan = execution_plan
        state.current_step = "Execution plan created"
        state.step_count += 1
        
    except Exception as e:
        state.errors.append(f"Execution planning error: {str(e)}")
        state.execution_plan = ["Error creating execution plan"]
    
    return state

# =====================================================
# LANGGRAPH WORKFLOW SETUP
# =====================================================

def create_orchestrator_workflow():
    """Create the LangGraph workflow for orchestration"""
    
    workflow = StateGraph(OrchestratorState)
    
    # Add nodes
    workflow.add_node("data_summary", data_summary_node)
    workflow.add_node("intent_identification", intent_identification_node)
    workflow.add_node("task_decomposition", task_decomposition_node)
    workflow.add_node("execution_planning", execution_planning_node)
    
    # Define workflow edges
    workflow.set_entry_point("data_summary")
    workflow.add_edge("data_summary", "intent_identification")
    workflow.add_edge("intent_identification", "task_decomposition")
    workflow.add_edge("task_decomposition", "execution_planning")
    workflow.add_edge("execution_planning", END)
    
    return workflow.compile()

# =====================================================
# STREAMING EXECUTION FUNCTION
# =====================================================

async def run_orchestrator_streaming(user_query: str):
    """Run the orchestrator workflow with streaming updates"""
    
    # Create initial state
    initial_state = OrchestratorState(
        user_query=user_query,
        available_data_summary="",
        identified_intent="",
        confidence_score=0.0,
        decomposed_tasks=[],
        execution_plan=[],
        current_step="Starting orchestration"
    )
    
    # Create workflow
    workflow = create_orchestrator_workflow()
    
    try:
        # Stream initial message
        yield {
            "type": "step",
            "step": "initialization", 
            "message": f"🎯 Initializing orchestrator for: {user_query}",
            "progress": 0
        }
        
        # Execute workflow with streaming
        result = initial_state
        step_count = 0
        total_steps = 4  # data_summary, intent_identification, task_decomposition, execution_planning
        
        # Step 1: Data Summary
        step_count += 1
        yield {
            "type": "step",
            "step": "data_summary",
            "message": "📊 Gathering available data sources...",
            "progress": (step_count / total_steps) * 100
        }
        result = await data_summary_node(result)
        yield {
            "type": "step_complete",
            "step": "data_summary", 
            "message": f"✅ Data summary completed - Found {len(result.available_data_summary.split('\\n'))} data sources",
            "progress": (step_count / total_steps) * 100
        }
        
        # Step 2: Intent Identification
        step_count += 1
        yield {
            "type": "step",
            "step": "intent_identification",
            "message": "🎯 Analyzing user intent with AI...",
            "progress": (step_count / total_steps) * 100
        }
        result = await intent_identification_node(result)
        yield {
            "type": "step_complete",
            "step": "intent_identification",
            "message": f"✅ Intent identified: {result.identified_intent} (confidence: {result.confidence_score}%)",
            "progress": (step_count / total_steps) * 100
        }
        
        # Step 3: Task Decomposition
        step_count += 1
        yield {
            "type": "step",
            "step": "task_decomposition",
            "message": "⚡ Breaking down query into executable tasks...",
            "progress": (step_count / total_steps) * 100
        }
        result = await task_decomposition_node(result)
        yield {
            "type": "step_complete",
            "step": "task_decomposition",
            "message": f"✅ Task decomposition completed - {len(result.decomposed_tasks)} tasks identified",
            "progress": (step_count / total_steps) * 100
        }
        
        # Step 4: Execution Planning
        step_count += 1
        yield {
            "type": "step",
            "step": "execution_planning",
            "message": "🗺️ Creating execution plan...",
            "progress": (step_count / total_steps) * 100
        }
        result = await execution_planning_node(result)
        yield {
            "type": "step_complete",
            "step": "execution_planning",
            "message": f"✅ Execution plan created with {len(result.execution_plan)} steps",
            "progress": 100
        }
        
        # Stream the final result
        yield {
            "type": "result",
            "data": {
                "user_query": result.user_query,
                "identified_intent": result.identified_intent,
                "confidence_score": result.confidence_score,
                "decomposed_tasks": result.decomposed_tasks,
                "execution_plan": result.execution_plan,
                "step_count": result.step_count,
                "errors": result.errors
            }
        }
        
    except Exception as e:
        yield {
            "type": "error",
            "message": f"❌ Error in orchestrator workflow: {str(e)}"
        }

async def run_orchestrator(user_query: str) -> OrchestratorState:
    """Run the orchestrator workflow"""
    
    # Create initial state
    initial_state = OrchestratorState(
        user_query=user_query,
        available_data_summary="",
        identified_intent="",
        confidence_score=0.0,
        decomposed_tasks=[],
        execution_plan=[],
        current_step="Starting orchestration"
    )
    
    # Create and run workflow
    workflow = create_orchestrator_workflow()
    
    print(f"🚀 Starting clean orchestrator for query: {user_query}")
    print("=" * 80)
    
    try:
        # Execute workflow
        result = await workflow.ainvoke(initial_state)
        print(f"✅ Orchestrator completed successfully!")
        print(f"Result type: {type(result)}")
        
        # Always convert to OrchestratorState for consistent interface
        final_state = OrchestratorState(
            user_query=result.get('user_query', user_query),
            available_data_summary=result.get('available_data_summary', ''),
            identified_intent=result.get('identified_intent', 'GENERAL_INQUIRY'),
            confidence_score=result.get('confidence_score', 0.0),
            decomposed_tasks=result.get('decomposed_tasks', []),
            execution_plan=result.get('execution_plan', []),
            current_step=result.get('current_step', 'Completed'),
            step_count=result.get('step_count', 0),
            errors=result.get('errors', [])
        )
        
        print(f"✅ Converted to OrchestratorState with {final_state.step_count} steps")
        return final_state
        
    except Exception as e:
        print(f"❌ Error in orchestrator workflow: {e}")
        import traceback
        traceback.print_exc()
        
        final_state = initial_state
        final_state.errors.append(f"Workflow error: {str(e)}")
        return final_state

def print_orchestrator_results(state: OrchestratorState):
    """Print detailed results from orchestrator"""
    
    print("\n" + "="*80)
    print("🎯 CLEAN ORCHESTRATOR RESULTS")
    print("="*80)
    
    print(f"\n📝 USER QUERY:")
    print(f"   {state.user_query}")
    
    print(f"\n🎯 IDENTIFIED INTENT:")
    print(f"   Intent: {state.identified_intent}")
    print(f"   Confidence: {state.confidence_score}%")
    
    print(f"\n📋 DECOMPOSED TASKS ({len(state.decomposed_tasks)} tasks):")
    for i, task in enumerate(state.decomposed_tasks, 1):
        print(f"\n   Task {i}: {task['task_name']}")
        print(f"      ID: {task['task_id']}")
        print(f"      Type: {task['task_type']}")
        print(f"      Priority: {task['priority']}")
        print(f"      Data Sources: {', '.join(task['data_sources'])}")
        print(f"      Expected Output: {task['expected_output']}")
        print(f"      Estimated Time: {task['estimated_time']}s")
    
    print(f"\n🗺️  EXECUTION PLAN:")
    for step in state.execution_plan:
        print(f"   {step}")
    
    if state.errors:
        print(f"\n❌ ERRORS:")
        for error in state.errors:
            print(f"   {error}")
    
    print(f"\n✅ COMPLETED IN {state.step_count} STEPS")
    print("="*80)

# =====================================================
# EXAMPLE USAGE
# =====================================================

async def main():
    """Test the clean orchestrator"""
    
    # Set OpenAI API key
    api_key = "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"
    os.environ["OPENAI_API_KEY"] = api_key
    
    # Test query
    query = "Give me a comprehensive overview of TechFlow Industries"
    
    print(f"Testing clean orchestrator with: {query}")
    
    try:
        # Run orchestrator
        result = await run_orchestrator(query)
        
        # Print results
        print_orchestrator_results(result)
        
    except Exception as e:
        print(f"❌ Error testing query: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    asyncio.run(main())