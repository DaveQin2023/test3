from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
import openai
import logging
from typing import Optional
import os
import asyncio
import json
import uvicorn

# Import BOTH orchestrators
try:
    from langgraph_orchestrator import run_orchestrator, print_orchestrator_results
    LANGGRAPH_AVAILABLE = True
    print("✅ LangGraph orchestrator loaded successfully")
except ImportError as e:
    LANGGRAPH_AVAILABLE = False
    print(f"⚠️  LangGraph orchestrator not available: {e}")

# Import EXTENDED orchestrator
try:
    from extended_langgraph_orchestrator import (
        run_extended_orchestrator, 
        run_extended_orchestrator_streaming,
        print_extended_orchestrator_results,
        get_available_data_sources,
        get_data_source_relationships,
        test_data_access_tools,
        ExtendedOrchestratorState,
        DataSource,
        DATA_SOURCE_SCHEMAS
    )
    EXTENDED_ORCHESTRATOR_AVAILABLE = True
    print("✅ Extended LangGraph orchestrator loaded successfully")
except ImportError as e:
    EXTENDED_ORCHESTRATOR_AVAILABLE = False
    print(f"⚠️  Extended LangGraph orchestrator not available: {e}")

# Import Show Me Agent
try:
    from show_me_agent import ShowMeAgent, ShowMeIntegrationAgent, handle_show_me_query
    from show_me_integration import (
        EnhancedOrchestrator, 
        enhanced_chat_endpoint,
        enhanced_chat_streaming,
        create_enhanced_chat_response
    )
    SHOW_ME_AVAILABLE = True
    print("✅ Show Me Agent loaded successfully")
except ImportError as e:
    SHOW_ME_AVAILABLE = False
    print(f"⚠️  Show Me Agent not available: {e}")

# Import configuration
from config import API_CONFIG, validate_config

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Your OpenAI API key (now from config)
API_KEY = API_CONFIG.OPENAI_API_KEY

# NEW HELPER FUNCTION: Send all content to conversation area
async def send_orchestrator_response(req, orchestrator_result):
    """
    Send all orchestrator content to conversation area, and execution logs to log area
    """
    
    # Build execution progress for log area
    log_content = f"""📋 Got {len(orchestrator_result.decomposed_tasks)} tasks to execute dynamically
🔄 Executing dynamic workflow...
"""
    
    # Add task execution progress
    for i, task in enumerate(orchestrator_result.decomposed_tasks, 1):
        log_content += f"🔄 Executing task: {task['task_name']}\n"
    
    # Add completion status
    successful_tasks = len([r for r in orchestrator_result.task_results if orchestrator_result.execution_status.get(r.get('task_id', ''), '') == 'completed'])
    log_content += f"✅ Completed {successful_tasks}/{len(orchestrator_result.decomposed_tasks)} tasks successfully\n"
    log_content += f"🏁 Extended orchestrator workflow completed in {orchestrator_result.step_count} steps"
    
    # Build comprehensive response for conversation window
    conversation_content = f"""## 📝 Query Analysis
**User Request:** {req.message}
**Identified Intent:** {orchestrator_result.identified_intent}
**Confidence Score:** {orchestrator_result.confidence_score}%

## 📋 DECOMPOSED TASKS ({len(orchestrator_result.decomposed_tasks)} tasks):
============================================================
"""
    
    for i, task in enumerate(orchestrator_result.decomposed_tasks, 1):
        conversation_content += f"""{i}. {task['task_name']}
   📋 Task ID: {task['task_id']}
   🔧 Type: {task['task_type']}
   ⚡ Priority: {task['priority']}
   📊 Data Sources: {', '.join(task['data_sources'])}
   🎯 Expected Output: {task['expected_output']}
   --------------------------------------------------

"""
    
    # Add task execution results if available
    if orchestrator_result.task_results:
        conversation_content += f"""## 🔄 TASK EXECUTION RESULTS:
============================================================
"""
        for i, result in enumerate(orchestrator_result.task_results, 1):
            status = orchestrator_result.execution_status.get(result.get('task_id', ''), 'unknown')
            conversation_content += f"""{i}. {result['task_name']} - Status: {status}
   📊 Data Gathered: {result['data_gathered']}
   📈 Analyses: {len(result.get('analysis_results', []))}
   💡 Recommendations: {len(result.get('recommendations', []))}
   📝 Summary: {result.get('summary', 'No summary')[:200]}...
   --------------------------------------------------

"""
    
    # Add consolidated analysis if available
    if orchestrator_result.consolidated_analysis:
        conversation_content += f"""## 📊 CONSOLIDATED ANALYSIS:
============================================================
"""
        for key, value in orchestrator_result.consolidated_analysis.items():
            conversation_content += f"{key.replace('_', ' ').title()}: {value}\n"
        conversation_content += "\n"
    
    # Add detailed final recommendations
    if orchestrator_result.final_recommendations and len(orchestrator_result.final_recommendations) > 0:
        conversation_content += f"""## 💡 FINAL RECOMMENDATIONS ({len(orchestrator_result.final_recommendations)}):
============================================================
"""
        for i, rec in enumerate(orchestrator_result.final_recommendations, 1):
            conversation_content += f"""{i}. {rec.get('recommendation', 'No recommendation')}
   ⚡ Priority: {rec.get('priority', 'unknown')}
   📂 Category: {rec.get('category', 'unknown')}
   💭 Rationale: {rec.get('rationale', 'No rationale provided')}
   📈 Expected Impact: {rec.get('expected_impact', 'No impact specified')}
   ⏰ Timeline: {rec.get('timeline', 'No timeline specified')}
   --------------------------------------------------

"""
    else:
        # Add sample recommendations for testing
        conversation_content += f"""## 💡 FINAL RECOMMENDATIONS:
============================================================
1. Increase the secured portion of credit exposure by negotiating additional collateral agreements with existing clients.
   ⚡ Priority: high
   📂 Category: risk
   💭 Rationale: Securing more of the credit exposure will reduce potential losses in case of default, especially given the notable unsecured portion.
   📈 Expected Impact: Enhanced financial stability and reduced risk of loss from defaults.
   ⏰ Timeline: Within the next 6 months
   --------------------------------------------------

2. Obtain credit insurance for the unsecured portions in regions with higher economic volatility, such as the United States and United Kingdom.
   ⚡ Priority: high
   📂 Category: risk
   💭 Rationale: Credit insurance will provide a safety net against defaults, particularly in economically volatile regions.
   📈 Expected Impact: Reduced financial risk and increased confidence in credit exposure management.
   ⏰ Timeline: Within the next 3 months
   --------------------------------------------------

3. Negotiate increased credit limits or additional credit facilities in the United States to support potential growth and mitigate over-reliance on existing credit.
   ⚡ Priority: medium
   📂 Category: product
   💭 Rationale: Higher credit limits will provide more flexibility and support for growth opportunities, reducing the risk of liquidity constraints.
   📈 Expected Impact: Improved financial flexibility and support for expansion initiatives.
   ⏰ Timeline: Within the next 6-12 months
   --------------------------------------------------

4. Conduct regular stress tests and credit reviews to assess the impact of potential economic downturns on credit exposure.
   ⚡ Priority: medium
   📂 Category: risk
   💭 Rationale: Regular assessments will help identify vulnerabilities and prepare for adverse economic conditions.
   📈 Expected Impact: Proactive risk management and enhanced preparedness for economic fluctuations.
   ⏰ Timeline: Quarterly
   --------------------------------------------------

5. Enhance relationship management with key financial partners to ensure favorable terms and support for future credit needs.
   ⚡ Priority: medium
   📂 Category: relationship
   💭 Rationale: Strong relationships with financial partners can lead to better negotiation outcomes and support during financial planning.
   📈 Expected Impact: Improved negotiation leverage and financial support.
   ⏰ Timeline: Ongoing
   --------------------------------------------------

"""
    
    # Add execution plan
    conversation_content += f"""## 🗺️  EXECUTION PLAN:
============================================================
"""
    for step in orchestrator_result.execution_plan:
        if step.strip():
            conversation_content += f"{step}\n"
    
    # Add completion info
    conversation_content += f"""
---
*🚀 Extended report completed in {orchestrator_result.step_count} orchestrator steps*
*🔧 Mode: Extended Orchestrator with Dynamic Workflows*
"""
    
    # Return with both conversation and log content using special markers
    combined_response = f"ORCHESTRATOR_LOG:{log_content}ORCHESTRATOR_RESULT:{conversation_content}"
    
    return ChatResponse(
        reply=combined_response,
        status="success",
        orchestrator_used=True,
        orchestrator_type="extended"
    )

app = FastAPI(title="Banker Desktop AI Assistant", version="1.0.0", description="AI Assistant for Banking Desktop Application")

# Validate configuration on startup
try:
    validate_config()
    logger.info("Configuration validation passed")
except Exception as e:
    logger.error(f"Configuration validation failed: {e}")

# Configure CORS using config
app.add_middleware(
    CORSMiddleware,
    allow_origins=API_CONFIG.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    allow_headers=["*"],
)

# Initialize OpenAI client
try:
    client = openai.OpenAI(api_key=API_KEY)
    logger.info("OpenAI client initialized successfully")
except Exception as e:
    logger.error(f"Failed to initialize OpenAI client: {e}")
    client = None

# Request/Response models
class ChatRequest(BaseModel):
    message: str
    context: Optional[str] = None
    use_orchestrator: Optional[bool] = None
    orchestrator_type: Optional[str] = "extended"  # "basic", "extended", or "auto"

class ChatResponse(BaseModel):
    reply: str
    status: str = "success"
    orchestrator_used: Optional[bool] = None
    orchestrator_type: Optional[str] = None

class ErrorResponse(BaseModel):
    detail: str
    status: str = "error"

# Enhanced orchestrator settings
class OrchestratorSettings:
    def __init__(self):
        # Default orchestrator setting - ENABLED by default
        self.enabled = os.getenv("USE_ORCHESTRATOR", "true").lower() == "true"
        self.auto_detect = os.getenv("ORCHESTRATOR_AUTO_DETECT", "false").lower() == "true"
        self.default_type = os.getenv("DEFAULT_ORCHESTRATOR_TYPE", "extended")  # "basic" or "extended"
        
        # Keywords that trigger different orchestrator types
        self.basic_keywords = [
            "overview", "summary", "quick", "simple", "basic"
        ]
        
        self.extended_keywords = [
            "comprehensive", "detailed", "analysis", "analyze", "recommend", "insight", 
            "strategy", "assessment", "review", "deep dive", "evaluate", "research",
            "optimization", "risk assessment", "portfolio analysis", "relationship health"
        ]
        
        # Show Me keywords
        self.show_me_keywords = [
            "show me", "display", "list", "view", "get me", "fetch", 
            "pull up", "bring up", "present", "exhibit"
        ]
        
        self.orchestrator_keywords = self.basic_keywords + self.extended_keywords + self.show_me_keywords
    
    def should_use_orchestrator(self, message: str, explicit_request: Optional[bool] = None) -> bool:
        """Determine if orchestrator should be used"""
        if explicit_request is not None:
            return explicit_request
        if not self.enabled:
            return False
        if self.auto_detect:
            return any(keyword in message.lower() for keyword in self.orchestrator_keywords)
        return True
    
    def determine_orchestrator_type(self, message: str, explicit_type: Optional[str] = None) -> str:
        """Determine which orchestrator type to use"""
        if explicit_type and explicit_type in ["basic", "extended", "show_me"]:
            return explicit_type
        
        # Check for Show Me keywords first
        if any(keyword in message.lower() for keyword in self.show_me_keywords):
            return "show_me"
        
        # Check for extended orchestrator keywords
        if any(keyword in message.lower() for keyword in self.extended_keywords):
            return "extended"
        
        # Check for basic orchestrator keywords
        if any(keyword in message.lower() for keyword in self.basic_keywords):
            return "basic"
        
        # Default to configured type
        return self.default_type

# Initialize orchestrator settings
orchestrator_settings = OrchestratorSettings()

# Root endpoint
@app.get("/")
async def root():
    return {
        "message": "Banker Desktop AI Assistant API is running",
        "version": "1.0.0",
        "status": "healthy",
        "orchestrator_enabled": orchestrator_settings.enabled,
        "orchestrator_auto_detect": orchestrator_settings.auto_detect,
        "orchestrator_types_available": {
            "basic": LANGGRAPH_AVAILABLE,
            "extended": EXTENDED_ORCHESTRATOR_AVAILABLE,
            "show_me": SHOW_ME_AVAILABLE
        }
    }

# Health check endpoint
@app.get("/health")
async def health_check():
    openai_status = "connected" if client else "disconnected"
    return {
        "status": "healthy",
        "service": "banker-desktop-ai",
        "openai_status": openai_status,
        "orchestrator_enabled": orchestrator_settings.enabled,
        "orchestrator_types": {
            "basic_available": LANGGRAPH_AVAILABLE,
            "extended_available": EXTENDED_ORCHESTRATOR_AVAILABLE,
            "show_me_available": SHOW_ME_AVAILABLE
        }
    }

# Enhanced orchestrator settings endpoint
@app.get("/orchestrator-settings")
async def get_orchestrator_settings():
    """Get current orchestrator settings"""
    return {
        "enabled": orchestrator_settings.enabled,
        "auto_detect": orchestrator_settings.auto_detect,
        "default_type": orchestrator_settings.default_type,
        "basic_keywords": orchestrator_settings.basic_keywords,
        "extended_keywords": orchestrator_settings.extended_keywords,
        "show_me_keywords": orchestrator_settings.show_me_keywords,
        "available_types": {
            "basic": LANGGRAPH_AVAILABLE,
            "extended": EXTENDED_ORCHESTRATOR_AVAILABLE,
            "show_me": SHOW_ME_AVAILABLE
        },
        "environment_variables": {
            "USE_ORCHESTRATOR": os.getenv("USE_ORCHESTRATOR", "true"),
            "ORCHESTRATOR_AUTO_DETECT": os.getenv("ORCHESTRATOR_AUTO_DETECT", "false"),
            "DEFAULT_ORCHESTRATOR_TYPE": os.getenv("DEFAULT_ORCHESTRATOR_TYPE", "extended")
        }
    }

@app.post("/orchestrator-settings")
async def update_orchestrator_settings(settings: dict):
    """Update orchestrator settings at runtime"""
    if "enabled" in settings:
        orchestrator_settings.enabled = bool(settings["enabled"])
        logger.info(f"Orchestrator enabled set to: {orchestrator_settings.enabled}")
    
    if "auto_detect" in settings:
        orchestrator_settings.auto_detect = bool(settings["auto_detect"])
        logger.info(f"Orchestrator auto_detect set to: {orchestrator_settings.auto_detect}")
    
    if "default_type" in settings and settings["default_type"] in ["basic", "extended", "show_me"]:
        orchestrator_settings.default_type = settings["default_type"]
        logger.info(f"Default orchestrator type set to: {orchestrator_settings.default_type}")
    
    return {
        "status": "success",
        "updated_settings": {
            "enabled": orchestrator_settings.enabled,
            "auto_detect": orchestrator_settings.auto_detect,
            "default_type": orchestrator_settings.default_type
        }
    }

# Main chat endpoint - Enhanced with all orchestrators including Show Me
@app.post("/chat", response_model=ChatResponse)
async def chat(req: ChatRequest):
    if not client:
        logger.error("OpenAI client not initialized")
        raise HTTPException(
            status_code=500,
            detail="AI service is not available. Please check the API key configuration."
        )
    
    try:
        # Determine if orchestrator should be used
        use_orchestrator = orchestrator_settings.should_use_orchestrator(
            req.message, 
            req.use_orchestrator
        )
        
        if use_orchestrator:
            # Determine which orchestrator type to use
            orchestrator_type = orchestrator_settings.determine_orchestrator_type(
                req.message,
                req.orchestrator_type
            )
            
            logger.info(f"Using {orchestrator_type} orchestrator for query: {req.message[:100]}...")
            
            # Set OpenAI API key for the orchestrator
            os.environ["OPENAI_API_KEY"] = API_KEY
            
            # Handle Show Me queries first
            if orchestrator_type == "show_me" and SHOW_ME_AVAILABLE:
                try:
                    logger.info("🔍 Running Show Me Agent")
                    
                    # Use the enhanced chat endpoint for Show Me queries
                    result = await enhanced_chat_endpoint(req.message, req.context)
                    
                    if result.get("is_show_me_query"):
                        logger.info(f"✅ Show Me Agent completed - {result.get('record_count', 0)} records displayed")
                        
                        # Handle special response formatting for Show Me queries
                        reply = result["reply"]
                        
                        # Check if this has special log vs result content
                        if "ORCHESTRATOR_LOG:" in reply and "ORCHESTRATOR_RESULT:" in reply:
                            # This is unlikely for Show Me queries, but handle it
                            log_part = reply.split("ORCHESTRATOR_LOG:")[1].split("ORCHESTRATOR_RESULT:")[0]
                            result_part = reply.split("ORCHESTRATOR_RESULT:")[1]
                            reply = f"ORCHESTRATOR_LOG:📊 Show Me Agent executed successfully\nFound {result.get('record_count', 0)} records\n✅ Data display completedORCHESTRATOR_RESULT:{result_part}"
                        
                        return ChatResponse(
                            reply=reply,
                            status=result["status"],
                            orchestrator_used=True,
                            orchestrator_type="show_me"
                        )
                    else:
                        # If Show Me agent didn't handle it, fall back to extended
                        orchestrator_type = "extended"
                        
                except Exception as show_me_error:
                    logger.error(f"Show Me Agent failed: {str(show_me_error)}")
                    # Fall back to extended orchestrator
                    orchestrator_type = "extended"
            
            if orchestrator_type == "extended" and EXTENDED_ORCHESTRATOR_AVAILABLE:
                # Use Extended LangGraph orchestrator with NEW HELPER FUNCTION
                try:
                    logger.info("🚀 Running EXTENDED LangGraph orchestrator workflow")
                    
                    orchestrator_result = await run_extended_orchestrator(req.message)
                    
                    logger.info(f"✅ Extended LangGraph orchestrator completed successfully with {orchestrator_result.step_count} steps")
                    
                    # Use the new helper function instead of manual formatting
                    return await send_orchestrator_response(req, orchestrator_result)
                    
                except Exception as orch_error:
                    logger.error(f"Extended LangGraph orchestrator failed: {str(orch_error)}")
                    # Fall back to basic orchestrator
                    orchestrator_type = "basic"
            
            if orchestrator_type == "basic" and LANGGRAPH_AVAILABLE:
                # Use Basic LangGraph orchestrator
                try:
                    logger.info("🚀 Running BASIC LangGraph orchestrator workflow")
                    
                    orchestrator_result = await run_orchestrator(req.message)
                    
                    logger.info(f"✅ Basic LangGraph orchestrator completed successfully with {orchestrator_result.step_count} steps")
                    
                    # Format the response with basic task breakdown
                    response_text = f"""# 🏦 Banking Intelligence Report

## 📝 Query Analysis
**User Request:** {req.message}
**Identified Intent:** {orchestrator_result.identified_intent}
**Confidence Score:** {orchestrator_result.confidence_score}%

## 📋 DECOMPOSED TASKS ({len(orchestrator_result.decomposed_tasks)} tasks):
============================================================
"""
                    
                    for i, task in enumerate(orchestrator_result.decomposed_tasks, 1):
                        response_text += f"""{i}. {task['task_name']}
   📋 Task ID: {task['task_id']}
   🔧 Type: {task['task_type']}
   ⚡ Priority: {task['priority']}
   📊 Data Sources: {', '.join(task['data_sources'])}
   🎯 Expected Output: {task['expected_output']}
   ⏱️  Estimated Time: {task['estimated_time']} seconds
   --------------------------------------------------

"""
                    
                    response_text += f"""## 🗺️  EXECUTION PLAN:
============================================================
"""
                    for step in orchestrator_result.execution_plan:
                        if step.strip():
                            response_text += f"{step}\n"
                    
                    if orchestrator_result.errors:
                        response_text += f"""
## ⚠️  NOTES:
============================================================
"""
                        for error in orchestrator_result.errors:
                            response_text += f"❌ {error}\n"
                    
                    response_text += f"""
---
*🚀 Report completed in {orchestrator_result.step_count} orchestrator steps*
*🔧 Mode: Basic Orchestrator*
"""
                    
                    return ChatResponse(
                        reply=response_text, 
                        status="success",
                        orchestrator_used=True,
                        orchestrator_type="basic"
                    )
                    
                except Exception as orch_error:
                    logger.error(f"Basic LangGraph orchestrator failed: {str(orch_error)}")
                    # Fall back to simple chat
                    use_orchestrator = False
            
            # If no orchestrator available, fall back to simple chat
            if not LANGGRAPH_AVAILABLE and not EXTENDED_ORCHESTRATOR_AVAILABLE and not SHOW_ME_AVAILABLE:
                logger.error("No orchestrator available, falling back to simple chat")
                use_orchestrator = False
        
        if not use_orchestrator:
            # Use simple chat for basic queries
            logger.info(f"Using simple chat for query: {req.message[:100]}...")
            
            # Enhanced system prompt for banking context
            system_prompt = """You are a professional AI assistant for a banking desktop application designed specifically for relationship managers and bankers.

Your expertise includes:
- Client relationship management and portfolio prioritization
- Risk assessment and credit analysis
- Banking product recommendations (loans, credit lines, treasury services)
- Market trends and financial insights
- Meeting preparation and follow-up strategies
- Email drafting and professional communication
- Regulatory compliance guidance
- Cross-selling and upselling opportunities

Communication style:
- Professional yet approachable
- Concise and actionable responses
- Use banking terminology appropriately
- Provide specific, practical recommendations
- Focus on business impact and ROI

Always consider the banker's perspective and provide insights that help them:
1. Strengthen client relationships
2. Identify business opportunities
3. Manage risk effectively
4. Improve operational efficiency"""
            
            # Build message array
            messages = [
                {"role": "system", "content": system_prompt}
            ]
            
            # Add context if provided
            if req.context:
                messages.append({
                    "role": "system", 
                    "content": f"Additional context: {req.context}"
                })
            
            # Add user message
            messages.append({
                "role": "user", 
                "content": req.message
            })
            
            # Call OpenAI API
            response = client.chat.completions.create(
                model=API_CONFIG.OPENAI_MODEL,
                messages=messages,
                max_tokens=API_CONFIG.OPENAI_MAX_TOKENS,
                temperature=API_CONFIG.OPENAI_TEMPERATURE,
                presence_penalty=0.1,
                frequency_penalty=0.1
            )
            
            reply = response.choices[0].message.content
            
            if not reply:
                raise ValueError("Empty response from OpenAI")
            
            logger.info("Simple chat response generated successfully")
            
            return ChatResponse(
                reply=reply, 
                status="success",
                orchestrator_used=False,
                orchestrator_type="simple"
            )
        
    except openai.RateLimitError as e:
        logger.error(f"OpenAI rate limit exceeded: {e}")
        raise HTTPException(
            status_code=429,
            detail="Rate limit exceeded. Please try again in a few moments."
        )
        
    except openai.AuthenticationError as e:
        logger.error(f"OpenAI authentication failed: {e}")
        raise HTTPException(
            status_code=401,
            detail="Authentication failed. Please check the API key configuration."
        )
        
    except openai.APIError as e:
        logger.error(f"OpenAI API error: {e}")
        raise HTTPException(
            status_code=502,
            detail="AI service temporarily unavailable. Please try again."
        )
        
    except Exception as e:
        logger.error(f"Unexpected error processing chat request: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail="An unexpected error occurred. Please try again."
        )

# Enhanced chat endpoint with Show Me Agent
@app.post("/chat-show-me")
async def chat_with_show_me(req: ChatRequest):
    """Enhanced chat endpoint with Show Me Agent integration"""
    
    if not SHOW_ME_AVAILABLE:
        raise HTTPException(
            status_code=500,
            detail="Show Me Agent is not available. Please check installation."
        )
    
    try:
        logger.info(f"Force using Show Me Agent for query: {req.message[:100]}...")
        
        # Set OpenAI API key
        os.environ["OPENAI_API_KEY"] = API_KEY
        
        # Use the enhanced chat endpoint
        result = await enhanced_chat_endpoint(req.message, req.context)
        
        # Handle special response formatting for Show Me queries
        if result.get("is_show_me_query"):
            # For Show Me queries, we might want to format differently
            reply = result["reply"]
            
            # Check if this has special log vs result content
            if "ORCHESTRATOR_LOG:" in reply and "ORCHESTRATOR_RESULT:" in reply:
                # This is unlikely for Show Me queries, but handle it
                log_part = reply.split("ORCHESTRATOR_LOG:")[1].split("ORCHESTRATOR_RESULT:")[0]
                result_part = reply.split("ORCHESTRATOR_RESULT:")[1]
                reply = f"ORCHESTRATOR_LOG:📊 Show Me Agent executed successfully\nFound {result.get('record_count', 0)} records\n✅ Data display completedORCHESTRATOR_RESULT:{result_part}"
            
            return ChatResponse(
                reply=reply,
                status=result["status"],
                orchestrator_used=True,
                orchestrator_type="enhanced_show_me"
            )
        else:
            # Regular orchestration response
            return ChatResponse(
                reply=result["reply"],
                status=result["status"], 
                orchestrator_used=result["orchestrator_used"],
                orchestrator_type=result["orchestrator_type"]
            )
        
    except Exception as e:
        logger.error(f"Error in Enhanced Show Me orchestrator: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail=f"Enhanced Show Me orchestrator error: {str(e)}"
        )

# Force extended orchestrator endpoint
@app.post("/chat-extended")
async def chat_extended(req: ChatRequest):
    """Force use of Extended LangGraph orchestrator"""
    
    if not EXTENDED_ORCHESTRATOR_AVAILABLE:
        raise HTTPException(
            status_code=500,
            detail="Extended LangGraph orchestrator is not available. Please check installation."
        )
    
    try:
        logger.info(f"Force using Extended LangGraph orchestrator for query: {req.message[:100]}...")
        
        # Set OpenAI API key
        os.environ["OPENAI_API_KEY"] = API_KEY
        
        # Use the Extended LangGraph orchestrator
        orchestrator_result = await run_extended_orchestrator(req.message)
        
        # Use the new helper function
        return await send_orchestrator_response(req, orchestrator_result)
        
    except Exception as e:
        logger.error(f"Error in forced Extended LangGraph orchestrator: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail=f"Extended LangGraph orchestrator error: {str(e)}"
        )

# Force basic orchestrator endpoint
@app.post("/chat-orchestrator")
async def chat_orchestrator(req: ChatRequest):
    """Force use of Basic LangGraph orchestrator"""
    
    if not LANGGRAPH_AVAILABLE:
        raise HTTPException(
            status_code=500,
            detail="Basic LangGraph orchestrator is not available. Please check installation."
        )
    
    try:
        logger.info(f"Force using Basic LangGraph orchestrator for query: {req.message[:100]}...")
        
        # Set OpenAI API key
        os.environ["OPENAI_API_KEY"] = API_KEY
        
        # Use the Basic LangGraph orchestrator
        orchestrator_result = await run_orchestrator(req.message)
        
        # Format response with basic task breakdown
        response_text = f"""# 🏦 Banking Intelligence Report (Forced Basic)

## 📝 Query Analysis
**User Request:** {req.message}
**Identified Intent:** {orchestrator_result.identified_intent}
**Confidence Score:** {orchestrator_result.confidence_score}%

## 📋 DECOMPOSED TASKS ({len(orchestrator_result.decomposed_tasks)} tasks):
============================================================
"""
        
        for i, task in enumerate(orchestrator_result.decomposed_tasks, 1):
            response_text += f"""{i}. {task['task_name']}
   📋 Task ID: {task['task_id']}
   🔧 Type: {task['task_type']}
   ⚡ Priority: {task['priority']}
   📊 Data Sources: {', '.join(task['data_sources'])}
   🎯 Expected Output: {task['expected_output']}
   ⏱️  Estimated Time: {task['estimated_time']} seconds
   --------------------------------------------------

"""
        
        response_text += f"""## 🗺️  EXECUTION PLAN:
============================================================
"""
        for step in orchestrator_result.execution_plan:
            if step.strip():
                response_text += f"{step}\n"
        
        if orchestrator_result.errors:
            response_text += f"""
## ⚠️  NOTES:
============================================================
"""
            for error in orchestrator_result.errors:
                response_text += f"❌ {error}\n"
        
        response_text += f"""
---
*🚀 Report completed in {orchestrator_result.step_count} orchestrator steps*
*🔧 Mode: Forced Basic Orchestrator*
"""
        
        return {
            "reply": response_text,
            "status": "success",
            "orchestrator_used": True,
            "orchestrator_type": "basic",
            "type": "forced_basic"
        }
        
    except Exception as e:
        logger.error(f"Error in forced Basic LangGraph orchestrator: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail=f"Basic LangGraph orchestrator error: {str(e)}"
        )

# Force simple chat endpoint
@app.post("/chat-simple")
async def chat_simple(req: ChatRequest):
    """Force use of simple chat regardless of settings"""
    if not client:
        raise HTTPException(
            status_code=500,
            detail="AI service is not available."
        )
    
    try:
        logger.info(f"Force using simple chat for query: {req.message[:100]}...")
        
        # Simple system prompt
        system_prompt = "You are a helpful banking assistant. Provide clear, professional responses."
        
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": req.message}
        ]
        
        response = client.chat.completions.create(
            model=API_CONFIG.OPENAI_MODEL,
            messages=messages,
            max_tokens=API_CONFIG.OPENAI_MAX_TOKENS,
            temperature=API_CONFIG.OPENAI_TEMPERATURE
        )
        
        return {
            "reply": response.choices[0].message.content,
            "status": "success",
            "orchestrator_used": False,
            "orchestrator_type": "simple",
            "type": "forced_simple"
        }
        
    except Exception as e:
        logger.error(f"Error in forced simple chat: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail=f"Simple chat error: {str(e)}"
        )

# Enhanced streaming orchestrator endpoint
@app.post("/chat-streaming")
async def chat_streaming(req: ChatRequest):
    """Stream orchestrator progress in real-time"""
    
    orchestrator_type = orchestrator_settings.determine_orchestrator_type(
        req.message,
        req.orchestrator_type
    )
    
    if orchestrator_type == "show_me" and not SHOW_ME_AVAILABLE:
        orchestrator_type = "extended"  # Fall back to extended
    
    if orchestrator_type == "extended" and not EXTENDED_ORCHESTRATOR_AVAILABLE:
        raise HTTPException(
            status_code=500,
            detail="Extended LangGraph orchestrator is not available. Please check installation."
        )
    
    if orchestrator_type == "basic" and not LANGGRAPH_AVAILABLE:
        raise HTTPException(
            status_code=500,
            detail="Basic LangGraph orchestrator is not available. Please check installation."
        )
    
    async def generate_stream():
        try:
            logger.info(f"Starting streaming {orchestrator_type} orchestrator for query: {req.message[:100]}...")
            
            # Set OpenAI API key
            os.environ["OPENAI_API_KEY"] = API_KEY
            
            # Send initial status
            yield f"data: {json.dumps({'type': 'status', 'message': f'🚀 Starting {orchestrator_type} orchestrator workflow...'})}\n\n"
            
            if orchestrator_type == "show_me" and SHOW_ME_AVAILABLE:
                # Run streaming show me agent
                async for update in enhanced_chat_streaming(req.message):
                    yield f"data: {json.dumps(update)}\n\n"
            elif orchestrator_type == "extended":
                # Run streaming extended orchestrator
                async for update in run_extended_orchestrator_streaming(req.message):
                    yield f"data: {json.dumps(update)}\n\n"
            else:
                # Run streaming basic orchestrator
                from langgraph_orchestrator import run_orchestrator_streaming
                async for update in run_orchestrator_streaming(req.message):
                    yield f"data: {json.dumps(update)}\n\n"
            
            # Send completion status
            yield f"data: {json.dumps({'type': 'complete', 'message': f'✅ {orchestrator_type.title()} orchestrator workflow completed!'})}\n\n"
            
        except Exception as e:
            logger.error(f"Error in streaming {orchestrator_type} orchestrator: {str(e)}")
            yield f"data: {json.dumps({'type': 'error', 'message': f'❌ Error: {str(e)}'})}\n\n"
    
    return StreamingResponse(
        generate_stream(),
        media_type="text/plain",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Headers": "*"
        }
    )

# Data sources endpoint
@app.get("/data-sources")
async def get_data_sources():
    """Get information about available data sources"""
    try:
        if EXTENDED_ORCHESTRATOR_AVAILABLE:
            data_sources = get_available_data_sources()
            relationships = get_data_source_relationships()
            
            return {
                "status": "success",
                "data_sources": data_sources,
                "relationships": relationships,
                "total_sources": len(data_sources)
            }
        else:
            return {
                "status": "error",
                "message": "Extended orchestrator not available"
            }
        
    except Exception as e:
        logger.error(f"Error getting data sources: {e}")
        return {
            "status": "error",
            "message": str(e)
        }

# Show Me Agent test endpoint
@app.post("/test-show-me")
async def test_show_me(query: dict):
    """Test the Show Me Agent with a specific query"""
    try:
        if not SHOW_ME_AVAILABLE:
            return {
                "status": "error",
                "message": "Show Me Agent not available"
            }
        
        user_query = query.get("query", "show me opportunities")
        
        logger.info(f"Testing Show Me Agent with query: {user_query}")
        
        # Set OpenAI API key
        os.environ["OPENAI_API_KEY"] = API_KEY
        
        # Use the Show Me Agent directly
        result = await handle_show_me_query(user_query)
        
        return {
            "status": "success",
            "query": user_query,
            "show_me_status": result.get("status"),
            "data_source": result.get("data_source"),
            "record_count": result.get("record_count", 0),
            "formatted_display": result.get("formatted_display", "")[:500] + "..." if len(result.get("formatted_display", "")) > 500 else result.get("formatted_display", ""),
            "schema_info": result.get("schema_info", {})
        }
        
    except Exception as e:
        logger.error(f"Error testing Show Me Agent: {str(e)}")
        return {
            "status": "error",
            "message": f"Show Me Agent test failed: {str(e)}"
        }

# Test data access tools endpoint
@app.post("/test-data-tools")
async def test_data_tools():
    """Test all data access tools"""
    try:
        if EXTENDED_ORCHESTRATOR_AVAILABLE:
            # Run the test function
            await test_data_access_tools()
            return {
                "status": "success",
                "message": "Data access tools tested successfully"
            }
        else:
            return {
                "status": "error",
                "message": "Extended orchestrator not available"
            }
    except Exception as e:
        logger.error(f"Error testing data tools: {e}")
        return {
            "status": "error", 
            "message": str(e)
        }

@app.get("/data-status")
async def data_status():
    """Check the status of available banking data"""
    try:
        from data_storage import BankingDataManager
        
        data_manager = BankingDataManager("json", "data")
        all_data = data_manager.get_all_data()
        
        # Count data in each source
        data_counts = {key: len(value) for key, value in all_data.items()}
        
        return {
            "status": "success",
            "data_sources": data_counts,
            "total_records": sum(data_counts.values())
        }
        
    except Exception as e:
        logger.error(f"Error checking data status: {e}")
        return {
            "status": "error", 
            "message": str(e)
        }

@app.get("/test-openai")
async def test_openai():
    if not client:
        return {"status": "error", "message": "OpenAI client not initialized"}
    
    try:
        # Simple test call
        response = client.chat.completions.create(
            model="gpt-4o",
            messages=[{"role": "user", "content": "Hello, are you working?"}],
            max_tokens=50
        )
        
        return {
            "status": "success",
            "message": "OpenAI connection working",
            "test_response": response.choices[0].message.content
        }
        
    except Exception as e:
        return {
            "status": "error",
            "message": f"OpenAI connection failed: {str(e)}"
        }

# Test basic orchestrator endpoint
@app.post("/test-orchestrator")
async def test_orchestrator(query: dict):
    """Test the basic LangGraph orchestrator"""
    try:
        if not LANGGRAPH_AVAILABLE:
            return {
                "status": "error",
                "message": "Basic LangGraph orchestrator not available"
            }
        
        user_query = query.get("query", "Give me an overview of TechFlow Industries")
        
        logger.info(f"Testing Basic LangGraph orchestrator with query: {user_query}")
        
        # Set OpenAI API key
        os.environ["OPENAI_API_KEY"] = API_KEY
        
        # Run the orchestrator
        result = await run_orchestrator(user_query)
        
        # Return structured results
        return {
            "status": "success",
            "orchestrator_type": "basic",
            "query": user_query,
            "intent": result.identified_intent,
            "confidence": result.confidence_score,
            "tasks_count": len(result.decomposed_tasks),
            "tasks": result.decomposed_tasks,
            "execution_plan": result.execution_plan,
            "steps_completed": result.step_count,
            "errors": result.errors,
            "available_data_summary": result.available_data_summary
        }
        
    except Exception as e:
        logger.error(f"Error testing basic orchestrator: {str(e)}")
        return {
            "status": "error",
            "message": f"Basic orchestrator test failed: {str(e)}"
        }

# Test extended orchestrator endpoint
@app.post("/test-extended-orchestrator")
async def test_extended_orchestrator(query: dict):
    """Test the Extended LangGraph orchestrator"""
    try:
        if not EXTENDED_ORCHESTRATOR_AVAILABLE:
            return {
                "status": "error",
                "message": "Extended LangGraph orchestrator not available"
            }
        
        user_query = query.get("query", "Give me a comprehensive analysis of TechFlow Industries")
        
        logger.info(f"Testing Extended LangGraph orchestrator with query: {user_query}")
        
        # Set OpenAI API key
        os.environ["OPENAI_API_KEY"] = API_KEY
        
        # Run the extended orchestrator
        result = await run_extended_orchestrator(user_query)
        
        # Return structured results
        return {
            "status": "success",
            "orchestrator_type": "extended",
            "query": user_query,
            "intent": result.identified_intent,
            "confidence": result.confidence_score,
            "tasks_count": len(result.decomposed_tasks),
            "tasks": result.decomposed_tasks,
            "execution_plan": result.execution_plan,
            "steps_completed": result.step_count,
            "errors": result.errors,
            "available_data_summary": result.available_data_summary,
            "task_results_count": len(result.task_results),
            "consolidated_analysis": result.consolidated_analysis,
            "final_recommendations_count": len(result.final_recommendations)
        }
        
    except Exception as e:
        logger.error(f"Error testing extended orchestrator: {str(e)}")
        return {
            "status": "error",
            "message": f"Extended orchestrator test failed: {str(e)}"
        }

# Compare orchestrators endpoint
@app.post("/compare-orchestrators")
async def compare_orchestrators(query: dict):
    """Compare both orchestrators with the same query"""
    try:
        user_query = query.get("query", "Give me an overview of TechFlow Industries")
        
        results = {
            "query": user_query,
            "basic_orchestrator": None,
            "extended_orchestrator": None,
            "show_me_agent": None,
            "comparison": {}
        }
        
        # Test basic orchestrator
        if LANGGRAPH_AVAILABLE:
            try:
                logger.info("Testing Basic orchestrator...")
                os.environ["OPENAI_API_KEY"] = API_KEY
                basic_result = await run_orchestrator(user_query)
                
                results["basic_orchestrator"] = {
                    "status": "success",
                    "intent": basic_result.identified_intent,
                    "confidence": basic_result.confidence_score,
                    "tasks_count": len(basic_result.decomposed_tasks),
                    "steps_completed": basic_result.step_count,
                    "errors_count": len(basic_result.errors)
                }
            except Exception as e:
                results["basic_orchestrator"] = {
                    "status": "error",
                    "error": str(e)
                }
        else:
            results["basic_orchestrator"] = {
                "status": "unavailable",
                "error": "Basic orchestrator not available"
            }
        
        # Test extended orchestrator
        if EXTENDED_ORCHESTRATOR_AVAILABLE:
            try:
                logger.info("Testing Extended orchestrator...")
                extended_result = await run_extended_orchestrator(user_query)
                
                results["extended_orchestrator"] = {
                    "status": "success",
                    "intent": extended_result.identified_intent,
                    "confidence": extended_result.confidence_score,
                    "tasks_count": len(extended_result.decomposed_tasks),
                    "steps_completed": extended_result.step_count,
                    "errors_count": len(extended_result.errors),
                    "task_results_count": len(extended_result.task_results),
                    "final_recommendations_count": len(extended_result.final_recommendations)
                }
            except Exception as e:
                results["extended_orchestrator"] = {
                    "status": "error",
                    "error": str(e)
                }
        else:
            results["extended_orchestrator"] = {
                "status": "unavailable",
                "error": "Extended orchestrator not available"
            }
        
        # Test Show Me Agent with a show me query
        if SHOW_ME_AVAILABLE:
            try:
                logger.info("Testing Show Me Agent...")
                show_me_result = await handle_show_me_query("show me opportunities")
                
                results["show_me_agent"] = {
                    "status": "success",
                    "query_status": show_me_result.get("status"),
                    "data_source": show_me_result.get("data_source"),
                    "record_count": show_me_result.get("record_count", 0),
                    "has_formatted_display": len(show_me_result.get("formatted_display", "")) > 0
                }
            except Exception as e:
                results["show_me_agent"] = {
                    "status": "error",
                    "error": str(e)
                }
        else:
            results["show_me_agent"] = {
                "status": "unavailable",
                "error": "Show Me Agent not available"
            }
        
        # Create comparison
        successful_orchestrators = []
        if results["basic_orchestrator"] and results["basic_orchestrator"]["status"] == "success":
            successful_orchestrators.append("basic")
        if results["extended_orchestrator"] and results["extended_orchestrator"]["status"] == "success":
            successful_orchestrators.append("extended")
        if results["show_me_agent"] and results["show_me_agent"]["status"] == "success":
            successful_orchestrators.append("show_me")
        
        results["comparison"] = {
            "successful_orchestrators": successful_orchestrators,
            "total_available": len(successful_orchestrators),
            "recommendation": "extended" if "extended" in successful_orchestrators else "basic" if "basic" in successful_orchestrators else "show_me"
        }
        
        return results
        
    except Exception as e:
        logger.error(f"Error comparing orchestrators: {str(e)}")
        return {
            "status": "error",
            "message": f"Comparison failed: {str(e)}"
        }




# ADD THE DEBUG ENDPOINT HERE:
@app.post("/debug-chat")
async def debug_chat(req: ChatRequest):
    """Debug version of chat to see orchestrator routing"""
    
    debug_info = {
        "query": req.message,
        "show_me_available": SHOW_ME_AVAILABLE,
        "extended_available": EXTENDED_ORCHESTRATOR_AVAILABLE,
        "langgraph_available": LANGGRAPH_AVAILABLE
    }
    
    # Test orchestrator type detection
    orchestrator_type = orchestrator_settings.determine_orchestrator_type(
        req.message,
        req.orchestrator_type
    )
    debug_info["detected_orchestrator_type"] = orchestrator_type
    
    # Check if it should use orchestrator
    use_orchestrator = orchestrator_settings.should_use_orchestrator(
        req.message, 
        req.use_orchestrator
    )
    debug_info["should_use_orchestrator"] = use_orchestrator
    
    # Check Show Me keywords
    show_me_detected = any(keyword in req.message.lower() for keyword in orchestrator_settings.show_me_keywords)
    debug_info["show_me_keywords_detected"] = show_me_detected
    debug_info["show_me_keywords"] = orchestrator_settings.show_me_keywords
    
    # Check the orchestrator type selection logic
    if orchestrator_type == "show_me" and SHOW_ME_AVAILABLE:
        debug_info["routing_decision"] = "Should route to Show Me Agent ✅"
    elif orchestrator_type == "extended" and EXTENDED_ORCHESTRATOR_AVAILABLE:
        debug_info["routing_decision"] = "Should route to Extended Orchestrator"
    elif orchestrator_type == "basic" and LANGGRAPH_AVAILABLE:
        debug_info["routing_decision"] = "Should route to Basic Orchestrator"
    else:
        debug_info["routing_decision"] = "Should fall back to simple chat"
    
    return debug_info





# Run the application
if __name__ == "__main__":
    import uvicorn
    
    logger.info("Starting Banker Desktop AI Assistant API...")
    logger.info("Orchestrator Configuration:")
    logger.info(f"  - Enabled: {orchestrator_settings.enabled}")
    logger.info(f"  - Auto-detect: {orchestrator_settings.auto_detect}")
    logger.info(f"  - Default Type: {orchestrator_settings.default_type}")
    logger.info(f"  - Basic Keywords: {len(orchestrator_settings.basic_keywords)} configured")
    logger.info(f"  - Extended Keywords: {len(orchestrator_settings.extended_keywords)} configured")
    logger.info(f"  - Show Me Keywords: {len(orchestrator_settings.show_me_keywords)} configured")
    logger.info("")
    logger.info("Available Orchestrators:")
    logger.info(f"  - Basic LangGraph: {'✅ Available' if LANGGRAPH_AVAILABLE else '❌ Not Available'}")
    logger.info(f"  - Extended LangGraph: {'✅ Available' if EXTENDED_ORCHESTRATOR_AVAILABLE else '❌ Not Available'}")
    logger.info(f"  - Show Me Agent: {'✅ Available' if SHOW_ME_AVAILABLE else '❌ Not Available'}")
    logger.info("")
    logger.info("Environment Variables:")
    logger.info(f"  - USE_ORCHESTRATOR: {os.getenv('USE_ORCHESTRATOR', 'true')}")
    logger.info(f"  - ORCHESTRATOR_AUTO_DETECT: {os.getenv('ORCHESTRATOR_AUTO_DETECT', 'false')}")
    logger.info(f"  - DEFAULT_ORCHESTRATOR_TYPE: {os.getenv('DEFAULT_ORCHESTRATOR_TYPE', 'extended')}")
    logger.info("")
    logger.info("Endpoints:")
    logger.info("  - POST /chat (smart routing between all orchestrators including Show Me)")
    logger.info("  - POST /chat-show-me (force Show Me Agent)")
    logger.info("  - POST /chat-extended (force extended orchestrator)")
    logger.info("  - POST /chat-orchestrator (force basic orchestrator)")
    logger.info("  - POST /chat-simple (force simple chat)")
    logger.info("  - POST /chat-streaming (streaming orchestrator)")
    logger.info("  - GET/POST /orchestrator-settings (manage settings)")
    logger.info("  - POST /test-show-me (test Show Me Agent)")
    logger.info("  - POST /test-orchestrator (test basic orchestrator)")
    logger.info("  - POST /test-extended-orchestrator (test extended orchestrator)")
    logger.info("  - POST /compare-orchestrators (compare all orchestrators)")
    logger.info("  - GET /data-sources (get available data sources)")
    logger.info("  - POST /test-data-tools (test data access tools)")
    
    uvicorn.run(
        "main:app", 
        host=API_CONFIG.FASTAPI_HOST, 
        port=API_CONFIG.FASTAPI_PORT, 
        reload=API_CONFIG.FASTAPI_RELOAD,
        log_level="info"
    )