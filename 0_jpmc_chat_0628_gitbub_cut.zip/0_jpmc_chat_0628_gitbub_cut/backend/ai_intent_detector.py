"""
AI-Powered Intent Detection System for Banking Orchestrator
Uses OpenAI to intelligently determine which agent should handle the query
"""

import openai
import json
import logging
from typing import Dict, Optional, Tuple
from enum import Enum
import asyncio

logger = logging.getLogger(__name__)

class IntentType(Enum):
    """Available intent types for banking queries"""
    SHOW_DATA = "show_data"          # Simple data display requests
    ANALYSIS = "analysis"            # Complex analysis and insights  
    BASIC_INQUIRY = "basic_inquiry"  # Simple questions and overviews
    SIMPLE_CHAT = "simple_chat"      # General banking assistance

class AIIntentDetector:
    """AI-powered intent detection using OpenAI"""
    
    def __init__(self, openai_client):
        self.client = openai_client
        
        # Intent definitions with examples
        self.intent_definitions = {
            IntentType.SHOW_DATA: {
                "description": "User wants to VIEW, DISPLAY, or SEE existing data without analysis",
                "examples": [
                    "show me opportunities",
                    "display interactions", 
                    "list accounts",
                    "view meetings",
                    "get me tasks",
                    "fetch credit exposure",
                    "pull up emails",
                    "bring up capital usage",
                    "show me products",
                    "display facilities",
                    "list all data",
                    "show me everything",
                    "display all records",
                    "view all available data"
                ],
                "keywords": ["show", "display", "list", "view", "see", "get", "fetch", "pull up", "bring up", "all", "everything"],
                "agent": "Show Me Agent"
            },
            IntentType.ANALYSIS: {
                "description": "User wants ANALYSIS, INSIGHTS, RECOMMENDATIONS, or complex processing",
                "examples": [
                    "analyze TechFlow's performance",
                    "give me insights on portfolio",
                    "recommend strategies for risk",
                    "comprehensive assessment",
                    "evaluate opportunities",
                    "deep dive into client data",
                    "research market trends"
                ],
                "keywords": ["analyze", "insights", "recommend", "assess", "evaluate", "comprehensive", "strategy", "research"],
                "agent": "Extended Orchestrator"
            },
            IntentType.BASIC_INQUIRY: {
                "description": "User wants OVERVIEW, SUMMARY, or simple information without deep analysis",
                "examples": [
                    "overview of TechFlow",
                    "summary of accounts",
                    "quick update on portfolio",
                    "basic information about client",
                    "simple report on status"
                ],
                "keywords": ["overview", "summary", "quick", "simple", "basic", "update", "status"],
                "agent": "Basic Orchestrator"
            },
            IntentType.SIMPLE_CHAT: {
                "description": "General banking questions, advice, or conversational queries",
                "examples": [
                    "what is a credit facility?",
                    "how to improve client relationships?",
                    "banking best practices",
                    "help with email drafting",
                    "explain treasury services"
                ],
                "keywords": ["what", "how", "help", "explain", "advice", "best practices"],
                "agent": "Simple Chat"
            }
        }
    
    async def detect_intent(self, user_query: str) -> Tuple[IntentType, float, str]:
        """
        Detect intent using OpenAI
        Returns: (intent_type, confidence_score, reasoning)
        """
        
        try:
            # Create the system prompt with intent definitions
            system_prompt = self._create_intent_detection_prompt()
            
            # Create the user prompt
            user_prompt = f"""
            Analyze this banking query and determine the intent:
            
            QUERY: "{user_query}"
            
            Respond in JSON format with:
            {{
                "intent": "show_data|analysis|basic_inquiry|simple_chat",
                "confidence": 0.95,
                "reasoning": "Brief explanation of why this intent was chosen",
                "detected_keywords": ["list", "of", "relevant", "keywords"],
                "recommended_agent": "Show Me Agent|Extended Orchestrator|Basic Orchestrator|Simple Chat"
            }}
            """
            
            # Call OpenAI
            response = await self._call_openai(system_prompt, user_prompt)
            
            # Parse response
            intent_data = self._parse_intent_response(response)
            
            # Convert string to enum
            intent_type = IntentType(intent_data["intent"])
            confidence = intent_data["confidence"]
            reasoning = intent_data["reasoning"]
            
            logger.info(f"🤖 AI Intent Detection: '{user_query}' → {intent_type.value} (confidence: {confidence})")
            logger.info(f"🧠 Reasoning: {reasoning}")
            
            return intent_type, confidence, reasoning
            
        except Exception as e:
            logger.error(f"Error in AI intent detection: {str(e)}")
            # Fallback to keyword-based detection
            return self._fallback_intent_detection(user_query)
    
    def _create_intent_detection_prompt(self) -> str:
        """Create the system prompt for intent detection"""
        
        prompt = """You are an expert banking AI intent classifier. Your job is to analyze banking queries and determine the user's intent with high accuracy.

AVAILABLE INTENTS:

1. SHOW_DATA - User wants to VIEW/DISPLAY existing data (NO ANALYSIS)
   - Purpose: Simple data retrieval and display ONLY
   - Examples: "show me opportunities", "display interactions", "list accounts", "view meetings", "show me everything"
   - Agent: Show Me Agent
   - Key indicators: show, display, list, view, see, get, fetch, pull up, bring up
   - CRITICAL: If query contains "show me" + any data type → ALWAYS use SHOW_DATA intent

2. ANALYSIS - User wants ANALYSIS/INSIGHTS/RECOMMENDATIONS  
   - Purpose: Complex processing, insights, recommendations, strategies
   - Examples: "analyze performance", "give insights", "recommend strategies", "comprehensive assessment"
   - Agent: Extended Orchestrator
   - Key indicators: analyze, insights, recommend, assess, evaluate, comprehensive, strategy, research

3. BASIC_INQUIRY - User wants OVERVIEW/SUMMARY without deep analysis
   - Purpose: Simple information gathering, basic reports
   - Examples: "overview of TechFlow", "summary of accounts", "quick update", "basic information"
   - Agent: Basic Orchestrator  
   - Key indicators: overview, summary, quick, simple, basic, update, status

4. SIMPLE_CHAT - General banking questions/advice
   - Purpose: General assistance, explanations, advice
   - Examples: "what is a credit facility?", "how to improve relationships?", "explain treasury services"
   - Agent: Simple Chat
   - Key indicators: what, how, help, explain, advice, best practices

CLASSIFICATION RULES:
- **HIGHEST PRIORITY**: "show me" queries are ALWAYS SHOW_DATA intent, never analysis
- **RULE**: If query starts with "show me", "display", "list", "view" → use SHOW_DATA
- Focus on the PRIMARY intent of the query
- Analysis/recommendation requests are ANALYSIS intent
- Overview/summary requests are BASIC_INQUIRY intent  
- Question words (what/how/why) often indicate SIMPLE_CHAT intent
- Consider context and nuance, not just keywords
- Confidence should be 0.9+ for "show me" queries, 0.8+ for other clear intents

**CRITICAL**: "show me [anything]" = SHOW_DATA intent with 95%+ confidence

Respond ONLY in valid JSON format."""
        
        return prompt
    
    async def _call_openai(self, system_prompt: str, user_prompt: str) -> str:
        """Call OpenAI API for intent detection"""
        
        response = await asyncio.to_thread(
            self.client.chat.completions.create,
            model="gpt-4o",
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt}
            ],
            max_tokens=300,
            temperature=0.1,  # Low temperature for consistent classification
            response_format={"type": "json_object"}
        )
        
        return response.choices[0].message.content
    
    def _parse_intent_response(self, response: str) -> Dict:
        """Parse OpenAI response into intent data"""
        
        try:
            intent_data = json.loads(response)
            
            # Validate required fields
            required_fields = ["intent", "confidence", "reasoning"]
            for field in required_fields:
                if field not in intent_data:
                    raise ValueError(f"Missing required field: {field}")
            
            # Validate intent value
            valid_intents = [intent.value for intent in IntentType]
            if intent_data["intent"] not in valid_intents:
                raise ValueError(f"Invalid intent: {intent_data['intent']}")
            
            # Ensure confidence is a float between 0 and 1
            confidence = float(intent_data["confidence"])
            if not 0 <= confidence <= 1:
                confidence = max(0, min(1, confidence))
            intent_data["confidence"] = confidence
            
            return intent_data
            
        except (json.JSONDecodeError, ValueError, KeyError) as e:
            logger.error(f"Error parsing intent response: {e}")
            logger.error(f"Raw response: {response}")
            raise
    
    def _fallback_intent_detection(self, user_query: str) -> Tuple[IntentType, float, str]:
        """Fallback keyword-based intent detection if OpenAI fails"""
        
        query_lower = user_query.lower()
        
        # Check for show_data keywords first (highest priority)
        show_data_keywords = ["show me", "display", "list", "view", "see", "get me", "fetch", "pull up", "bring up"]
        if any(keyword in query_lower for keyword in show_data_keywords):
            return IntentType.SHOW_DATA, 0.7, "Fallback: Detected show/display keywords"
        
        # Check for analysis keywords
        analysis_keywords = ["analyze", "analysis", "insights", "recommend", "assess", "evaluate", "comprehensive", "strategy", "research"]
        if any(keyword in query_lower for keyword in analysis_keywords):
            return IntentType.ANALYSIS, 0.6, "Fallback: Detected analysis keywords"
        
        # Check for basic inquiry keywords
        basic_keywords = ["overview", "summary", "quick", "simple", "basic", "update", "status"]
        if any(keyword in query_lower for keyword in basic_keywords):
            return IntentType.BASIC_INQUIRY, 0.6, "Fallback: Detected overview/summary keywords"
        
        # Default to simple chat
        return IntentType.SIMPLE_CHAT, 0.5, "Fallback: No specific keywords detected"

# =====================================================
# ENHANCED ORCHESTRATOR SETTINGS WITH AI INTENT
# =====================================================

class AIEnhancedOrchestratorSettings:
    """Enhanced orchestrator settings with AI-powered intent detection"""
    
    def __init__(self, openai_client):
        self.enabled = True
        self.use_ai_intent = True  # New flag for AI intent detection
        self.ai_intent_detector = AIIntentDetector(openai_client)
        
        # Fallback settings (used when AI detection fails)
        self.fallback_enabled = True
        self.default_type = "extended"
        
        # Intent to orchestrator mapping
        self.intent_to_orchestrator = {
            IntentType.SHOW_DATA: "show_me",
            IntentType.ANALYSIS: "extended", 
            IntentType.BASIC_INQUIRY: "basic",
            IntentType.SIMPLE_CHAT: "simple"
        }
    
    async def should_use_orchestrator(self, message: str, explicit_request: Optional[bool] = None) -> bool:
        """Determine if orchestrator should be used"""
        if explicit_request is not None:
            return explicit_request
        return self.enabled
    
    async def determine_orchestrator_type(self, message: str, explicit_type: Optional[str] = None) -> Tuple[str, float, str]:
        """
        Determine orchestrator type using AI intent detection
        Returns: (orchestrator_type, confidence, reasoning)
        """
        
        if explicit_type and explicit_type in ["basic", "extended", "show_me", "simple"]:
            return explicit_type, 1.0, f"Explicitly requested: {explicit_type}"
        
        if self.use_ai_intent:
            try:
                # Use AI to detect intent
                intent_type, confidence, reasoning = await self.ai_intent_detector.detect_intent(message)
                
                # Map intent to orchestrator type
                orchestrator_type = self.intent_to_orchestrator.get(intent_type, self.default_type)
                
                return orchestrator_type, confidence, reasoning
                
            except Exception as e:
                logger.error(f"AI intent detection failed: {e}")
                # Fall back to simple detection
                return self._fallback_detection(message)
        else:
            return self._fallback_detection(message)
    
    def _fallback_detection(self, message: str) -> Tuple[str, float, str]:
        """Fallback to keyword-based detection"""
        
        query_lower = message.lower()
        
        # Simple keyword-based fallback
        if any(keyword in query_lower for keyword in ["show me", "display", "list", "view"]):
            return "show_me", 0.7, "Fallback: Show keywords detected"
        elif any(keyword in query_lower for keyword in ["analyze", "comprehensive", "insights"]):
            return "extended", 0.6, "Fallback: Analysis keywords detected"
        elif any(keyword in query_lower for keyword in ["overview", "summary", "basic"]):
            return "basic", 0.6, "Fallback: Overview keywords detected"
        else:
            return "simple", 0.5, "Fallback: Default to simple chat"

# =====================================================
# TESTING FUNCTIONS
# =====================================================

async def test_ai_intent_detection(openai_client):
    """Test the AI intent detection with various queries"""
    
    detector = AIIntentDetector(openai_client)
    
    test_queries = [
        # Show Data queries
        "show me interactions",
        "display opportunities", 
        "list all accounts",
        "view meetings",
        "get me credit exposure",
        
        # Analysis queries
        "analyze TechFlow's performance",
        "give me insights on portfolio risk", 
        "recommend strategies for growth",
        "comprehensive assessment of client",
        "evaluate investment opportunities",
        
        # Basic Inquiry queries
        "overview of TechFlow Industries",
        "summary of account status",
        "quick update on portfolio",
        "basic information about client",
        
        # Simple Chat queries
        "what is a credit facility?",
        "how to improve client relationships?",
        "explain treasury services",
        "help me draft an email"
    ]
    
    print("🧪 Testing AI Intent Detection")
    print("=" * 80)
    
    for query in test_queries:
        try:
            intent_type, confidence, reasoning = await detector.detect_intent(query)
            
            print(f"\n📝 Query: '{query}'")
            print(f"🎯 Intent: {intent_type.value}")
            print(f"📊 Confidence: {confidence:.2f}")
            print(f"🧠 Reasoning: {reasoning}")
            print(f"🤖 Recommended Agent: {detector.intent_definitions[intent_type]['agent']}")
            print("-" * 60)
            
        except Exception as e:
            print(f"\n❌ Error with query '{query}': {e}")
    
    print("\n" + "=" * 80)

# =====================================================
# EXAMPLE USAGE
# =====================================================

async def example_usage():
    """Example of how to use the AI intent detection"""
    
    # Initialize OpenAI client
    import openai
    import os
    
    client = openai.OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
    
    # Create enhanced orchestrator settings
    orchestrator_settings = AIEnhancedOrchestratorSettings(client)
    
    # Test query
    query = "show me interactions"
    
    # Determine orchestrator type
    orchestrator_type, confidence, reasoning = await orchestrator_settings.determine_orchestrator_type(query)
    
    print(f"Query: '{query}'")
    print(f"Orchestrator Type: {orchestrator_type}")
    print(f"Confidence: {confidence:.2f}")
    print(f"Reasoning: {reasoning}")

if __name__ == "__main__":
    # Test the system
    import os
    import openai
    
    client = openai.OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
    asyncio.run(test_ai_intent_detection(client))