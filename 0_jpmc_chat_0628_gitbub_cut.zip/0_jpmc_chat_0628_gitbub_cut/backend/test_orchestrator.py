# test_orchestrator.py
import asyncio
import os
import json

# Set API key
os.environ["OPENAI_API_KEY"] = "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"

from langgraph_orchestrator import run_orchestrator

async def test():
    result = await run_orchestrator("Give me TechFlow overview")
    print("✅ Success!")
    print(f"Result type: {type(result)}")
    
    # Access the state data correctly
    if hasattr(result, 'identified_intent'):
        # If it's our OrchestratorState object
        print(f"Intent: {result.identified_intent}")
        print(f"Confidence: {result.confidence_score}%")
        tasks = result.decomposed_tasks
        execution_plan = result.execution_plan
    else:
        # If it's AddableValuesDict, access like dictionary
        print(f"Intent: {result.get('identified_intent', 'Unknown')}")
        print(f"Confidence: {result.get('confidence_score', 0)}%")
        tasks = result.get('decomposed_tasks', [])
        execution_plan = result.get('execution_plan', [])
        print(f"Steps completed: {result.get('step_count', 0)}")
        print(f"Available keys: {list(result.keys())}")
    
    # Show all decomposed tasks in detail
    print(f"\n📋 DECOMPOSED TASKS ({len(tasks)} tasks):")
    print("=" * 60)
    
    for i, task in enumerate(tasks, 1):
        print(f"\n{i}. {task.get('task_name', 'Unknown Task')}")
        print(f"   📋 Task ID: {task.get('task_id', 'N/A')}")
        print(f"   🔧 Type: {task.get('task_type', 'N/A')}")
        print(f"   ⚡ Priority: {task.get('priority', 'N/A')}")
        print(f"   📊 Data Sources: {', '.join(task.get('data_sources', []))}")
        print(f"   🎯 Expected Output: {task.get('expected_output', 'N/A')}")
        print(f"   ⏱️  Estimated Time: {task.get('estimated_time', 'N/A')} seconds")
        print("   " + "-" * 50)
    
    # Show execution plan
    print(f"\n🗺️  EXECUTION PLAN:")
    print("=" * 60)
    for step in execution_plan:
        print(f"   {step}")
    
    # Show raw JSON for one task to see full structure
    if tasks:
        print(f"\n🔍 RAW TASK DATA (First Task):")
        print("=" * 60)
        print(json.dumps(tasks[0], indent=2))

if __name__ == "__main__":
    asyncio.run(test())