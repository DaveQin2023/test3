"""
Integration of Show Me Agent with Existing Orchestrators
"""

import json
import asyncio
import os
from typing import Dict, List, Any, Optional
from dataclasses import dataclass

# Import the Show Me Agent
from show_me_agent import ShowMeAgent, ShowMeIntegrationAgent, handle_show_me_query

# Import existing orchestrators
try:
    from extended_langgraph_orchestrator import (
        ExtendedOrchestratorState, 
        run_extended_orchestrator,
        ConsolidationAgent
    )
    EXTENDED_AVAILABLE = True
except ImportError:
    EXTENDED_AVAILABLE = False

try:
    from langgraph_orchestrator import (
        OrchestratorState,
        run_orchestrator
    )
    BASIC_AVAILABLE = True
except ImportError:
    BASIC_AVAILABLE = False

# LangGraph imports
from langchain_core.messages import HumanMessage
from langchain_openai import ChatOpenAI

# =====================================================
# ENHANCED ORCHESTRATOR WITH SHOW ME AGENT
# =====================================================

@dataclass
class EnhancedOrchestratorState:
    """Enhanced state that includes Show Me agent results"""
    # Base orchestrator fields
    user_query: str
    available_data_summary: str
    identified_intent: str
    confidence_score: float
    decomposed_tasks: List[Dict[str, Any]]
    execution_plan: List[str]
    current_step: str
    step_count: int = 0
    errors: List[str] = None
    
    # Show Me agent specific fields
    is_show_me_query: bool = False
    show_me_results: Dict[str, Any] = None
    direct_data_display: str = ""
    
    def __post_init__(self):
        if self.errors is None:
            self.errors = []
        if self.show_me_results is None:
            self.show_me_results = {}

class EnhancedOrchestrator:
    """Enhanced orchestrator that includes Show Me Agent capabilities"""
    
    def __init__(self, llm=None):
        self.llm = llm or self._initialize_llm()
        self.show_me_agent = ShowMeIntegrationAgent(self.llm)
        
    def _initialize_llm(self):
        """Initialize LLM if not provided"""
        api_key = os.getenv("OPENAI_API_KEY")
        if not api_key:
            raise ValueError("OPENAI_API_KEY not found")
        return ChatOpenAI(model="gpt-4o", temperature=0.3, max_tokens=2000, api_key=api_key)
    
    async def process_query(self, user_query: str) -> EnhancedOrchestratorState:
        """Process query with Show Me agent integration"""
        
        # Create initial state
        state = EnhancedOrchestratorState(
            user_query=user_query,
            available_data_summary="",
            identified_intent="",
            confidence_score=0.0,
            decomposed_tasks=[],
            execution_plan=[],
            current_step="Starting enhanced orchestration"
        )
        
        # Check if this is a "show me" query
        if self.show_me_agent.should_handle_query(user_query):
            print(f"🎯 Detected Show Me query: {user_query}")
            
            # Handle with Show Me agent
            state.is_show_me_query = True
            state.current_step = "Processing Show Me query"
            
            try:
                show_me_results = await self.show_me_agent.process_show_me_query(user_query)
                state.show_me_results = show_me_results
                state.direct_data_display = show_me_results.get('formatted_display', '')
                state.step_count += 1
                
                if show_me_results['status'] == 'success':
                    state.current_step = f"Show Me query completed - displayed {show_me_results.get('record_count', 0)} records"
                    state.identified_intent = f"SHOW_DATA_{show_me_results.get('data_source', 'UNKNOWN').upper()}"
                    state.confidence_score = 95.0
                elif show_me_results['status'] == 'help':
                    state.current_step = "Show Me help provided"
                    state.identified_intent = "SHOW_DATA_HELP"
                    state.confidence_score = 100.0
                else:
                    state.current_step = "Show Me query failed"
                    state.errors.append(f"Show Me error: {show_me_results.get('message', 'Unknown error')}")
                
                return state
                
            except Exception as e:
                state.errors.append(f"Show Me agent error: {str(e)}")
                state.current_step = "Show Me query failed, falling back to regular orchestration"
        
        # If not a Show Me query or Show Me failed, use regular orchestration
        print(f"🔄 Using regular orchestration for: {user_query}")
        
        # Try extended orchestrator first
        if EXTENDED_AVAILABLE:
            try:
                extended_result = await run_extended_orchestrator(user_query)
                
                # Map extended result to enhanced state
                state.available_data_summary = extended_result.available_data_summary
                state.identified_intent = extended_result.identified_intent
                state.confidence_score = extended_result.confidence_score
                state.decomposed_tasks = extended_result.decomposed_tasks
                state.execution_plan = extended_result.execution_plan
                state.current_step = extended_result.current_step
                state.step_count = extended_result.step_count
                state.errors.extend(extended_result.errors)
                
                return state
                
            except Exception as e:
                state.errors.append(f"Extended orchestrator failed: {str(e)}")
        
        # Fall back to basic orchestrator
        if BASIC_AVAILABLE:
            try:
                basic_result = await run_orchestrator(user_query)
                
                # Map basic result to enhanced state
                state.available_data_summary = basic_result.available_data_summary
                state.identified_intent = basic_result.identified_intent
                state.confidence_score = basic_result.confidence_score
                state.decomposed_tasks = basic_result.decomposed_tasks
                state.execution_plan = basic_result.execution_plan
                state.current_step = basic_result.current_step
                state.step_count = basic_result.step_count
                state.errors.extend(basic_result.errors)
                
                return state
                
            except Exception as e:
                state.errors.append(f"Basic orchestrator failed: {str(e)}")
        
        # If all else fails
        state.errors.append("No orchestrator available")
        state.current_step = "Failed to process query"
        
        return state

# =====================================================
# MAIN.PY INTEGRATION ENHANCEMENTS
# =====================================================

def create_enhanced_chat_response(state: EnhancedOrchestratorState) -> str:
    """Create enhanced chat response that handles Show Me queries"""
    
    if state.is_show_me_query and state.show_me_results:
        # Handle Show Me responses
        if state.show_me_results['status'] == 'success':
            
            # Check if this is an "ALL_DATA" query
            if state.show_me_results.get('data_source') == 'ALL_DATA':
                response = f"""# 📊 Complete Banking Data Overview

{state.direct_data_display}

---
**Query:** {state.user_query}  
**Data Sources Accessed:** {len(state.show_me_results.get('all_data_sources', []))}  
**Total Records Found:** {state.show_me_results.get('record_count', 0):,}  
**Processing Time:** {state.step_count} steps  
**Mode:** Show Me Agent - Complete Data Overview (Display Only)
"""
            else:
                # Single data source response
                response = f"""# 📊 Data Display Results

{state.direct_data_display}

---
**Query:** {state.user_query}  
**Data Source:** {state.show_me_results.get('data_source', 'Unknown')}  
**Records Found:** {state.show_me_results.get('record_count', 0)}  
**Processing Time:** {state.step_count} steps  
**Mode:** Show Me Agent (Display Only)
"""
            return response
            
        elif state.show_me_results['status'] == 'help':
            return f"""# 🤔 Show Me Help

{state.direct_data_display}

---
**Mode:** Show Me Agent Help
"""
        
        else:
            # Error in Show Me agent
            error_msg = state.show_me_results.get('message', 'Unknown error')
            return f"""# ❌ Show Me Query Failed

I encountered an error while trying to display the requested data:

**Error:** {error_msg}

**Available Options:**
- Try rephrasing your request (e.g., "show me opportunities")
- Use "show me help" to see all available data sources
- Use "show me everything" to see all available data
- Or ask a different type of question for general analysis

---
**Mode:** Show Me Agent (Error Recovery)
"""
    
    # Handle regular orchestration responses
    else:
        # Use existing formatting for regular queries
        response = f"""# 🏦 Banking Intelligence Report

## 📝 Query Analysis
**User Request:** {state.user_query}
**Identified Intent:** {state.identified_intent}
**Confidence Score:** {state.confidence_score}%

## 📋 DECOMPOSED TASKS ({len(state.decomposed_tasks)} tasks):
============================================================
"""
        
        for i, task in enumerate(state.decomposed_tasks, 1):
            response += f"""{i}. {task.get('task_name', 'Unknown Task')}
   📋 Task ID: {task.get('task_id', 'N/A')}
   🔧 Type: {task.get('task_type', 'N/A')}
   ⚡ Priority: {task.get('priority', 'N/A')}
   📊 Data Sources: {', '.join(task.get('data_sources', []))}
   🎯 Expected Output: {task.get('expected_output', 'N/A')}
   --------------------------------------------------

"""
        
        response += f"""## 🗺️  EXECUTION PLAN:
============================================================
"""
        for step in state.execution_plan:
            if step.strip():
                response += f"{step}\n"
        
        if state.errors:
            response += f"""
## ⚠️  NOTES:
============================================================
"""
            for error in state.errors:
                response += f"❌ {error}\n"
        
        response += f"""
---
*🚀 Report completed in {state.step_count} orchestrator steps*
*🔧 Mode: Enhanced Orchestrator with Show Me Agent*
"""
        
        return response

# =====================================================
# UPDATED MAIN.PY CHAT ENDPOINT
# =====================================================

async def enhanced_chat_endpoint(req_message: str, req_context: str = None) -> Dict[str, Any]:
    """Enhanced chat endpoint that includes Show Me agent"""
    
    try:
        # Initialize enhanced orchestrator
        enhanced_orchestrator = EnhancedOrchestrator()
        
        # Process the query
        result_state = await enhanced_orchestrator.process_query(req_message)
        
        # Create response
        formatted_response = create_enhanced_chat_response(result_state)
        
        return {
            "reply": formatted_response,
            "status": "success",
            "orchestrator_used": True,
            "orchestrator_type": "enhanced_with_show_me",
            "is_show_me_query": result_state.is_show_me_query,
            "data_source": result_state.show_me_results.get('data_source') if result_state.show_me_results else None,
            "record_count": result_state.show_me_results.get('record_count') if result_state.show_me_results else None
        }
        
    except Exception as e:
        return {
            "reply": f"❌ Error in enhanced orchestrator: {str(e)}",
            "status": "error",
            "orchestrator_used": False,
            "error_details": str(e)
        }

# =====================================================
# STREAMING VERSION
# =====================================================

async def enhanced_chat_streaming(user_query: str):
    """Streaming version of enhanced chat with Show Me agent"""
    
    try:
        # Initialize
        enhanced_orchestrator = EnhancedOrchestrator()
        
        yield {
            "type": "step",
            "step": "initialization",
            "message": f"🎯 Initializing enhanced orchestrator for: {user_query}",
            "progress": 0
        }
        
        # Check if Show Me query
        if enhanced_orchestrator.show_me_agent.should_handle_query(user_query):
            yield {
                "type": "step",
                "step": "show_me_detection",
                "message": "🔍 Detected Show Me query - preparing data display...",
                "progress": 25
            }
            
            # Process Show Me query
            yield {
                "type": "step", 
                "step": "show_me_processing",
                "message": "📊 Processing Show Me request...",
                "progress": 50
            }
            
            result_state = await enhanced_orchestrator.process_query(user_query)
            
            yield {
                "type": "step_complete",
                "step": "show_me_complete",
                "message": f"✅ Show Me query completed - {result_state.show_me_results.get('record_count', 0)} records found",
                "progress": 100
            }
        else:
            # Regular orchestration with progress updates
            yield {
                "type": "step",
                "step": "regular_orchestration",
                "message": "🔄 Processing with regular orchestration...",
                "progress": 50
            }
            
            result_state = await enhanced_orchestrator.process_query(user_query)
            
            yield {
                "type": "step_complete",
                "step": "orchestration_complete", 
                "message": f"✅ Orchestration completed - {len(result_state.decomposed_tasks)} tasks identified",
                "progress": 100
            }
        
        # Stream final result
        formatted_response = create_enhanced_chat_response(result_state)
        
        yield {
            "type": "result",
            "data": {
                "reply": formatted_response,
                "is_show_me_query": result_state.is_show_me_query,
                "orchestrator_type": "enhanced_with_show_me",
                "step_count": result_state.step_count,
                "errors": result_state.errors
            }
        }
        
    except Exception as e:
        yield {
            "type": "error",
            "message": f"❌ Error in enhanced streaming: {str(e)}"
        }

# =====================================================
# TESTING EXAMPLES
# =====================================================

async def test_enhanced_orchestrator():
    """Test the enhanced orchestrator with various query types"""
    
    test_queries = [
        # Test Show Me queries
        "show me opportunities",
        "show me recent interactions",
        "show me high priority tasks", 
        "display TechFlow accounts",
        "list all meetings",
        "show me credit exposure",
        "show me everything",
        "display all data",
        "show me all records",
        
        # Regular orchestration queries
        "Give me a comprehensive overview of TechFlow Industries",
        "What are the risks associated with our current portfolio?",
        "Analyze TechFlow's credit utilization and recommend strategies",
        
        # Help queries
        "show me something unknown",
        "what can you show me?"
    ]
    
    print("🧪 Testing Enhanced Orchestrator with Show Me Agent")
    print("=" * 80)
    
    for query in test_queries:
        print(f"\n🔍 Testing Query: '{query}'")
        print("-" * 60)
        
        try:
            # Test with enhanced orchestrator
            enhanced_orchestrator = EnhancedOrchestrator()
            result = await enhanced_orchestrator.process_query(query)
            
            print(f"✅ Status: Success")
            print(f"📊 Is Show Me Query: {result.is_show_me_query}")
            print(f"🎯 Intent: {result.identified_intent}")
            print(f"📈 Confidence: {result.confidence_score}%")
            print(f"🔄 Steps: {result.step_count}")
            
            if result.is_show_me_query and result.show_me_results:
                print(f"📊 Data Source: {result.show_me_results.get('data_source', 'N/A')}")
                if result.show_me_results.get('data_source') == 'ALL_DATA':
                    print(f"📋 Total Data Sources: {len(result.show_me_results.get('all_data_sources', []))}")
                    print(f"📊 Total Records: {result.show_me_results.get('record_count', 0):,}")
                else:
                    print(f"📊 Records: {result.show_me_results.get('record_count', 0)}")
            else:
                print(f"📋 Tasks: {len(result.decomposed_tasks)}")
            
            if result.errors:
                print(f"⚠️  Errors: {len(result.errors)}")
                for error in result.errors:
                    print(f"   - {error}")
            
            # Show a snippet of the response
            formatted_response = create_enhanced_chat_response(result)
            print(f"\n📄 Response Preview:")
            print(formatted_response[:300] + "..." if len(formatted_response) > 300 else formatted_response)
            
        except Exception as e:
            print(f"❌ Error: {str(e)}")
        
        print("\n" + "=" * 80)

# =====================================================
# EXPORTS
# =====================================================

__all__ = [
    "EnhancedOrchestrator",
    "EnhancedOrchestratorState", 
    "enhanced_chat_endpoint",
    "enhanced_chat_streaming",
    "create_enhanced_chat_response",
    "test_enhanced_orchestrator"
]

# Example usage
if __name__ == "__main__":
    # Set API key for testing
    os.environ["OPENAI_API_KEY"] = "your-api-key-here"
    
    asyncio.run(test_enhanced_orchestrator())