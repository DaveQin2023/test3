from flask import Flask, request, jsonify, Response
from flask_cors import CORS
import json
import time
import threading
from queue import Queue
import sys
import os

# Add the directory containing BankerResearchTool to the path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Import your BankerResearchTool
from BankerResearchTool import BankerResearchTool

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

# Global variables for progress tracking
progress_queue = Queue()
current_progress = {"status": "idle", "step": "", "progress": 0}

class ProgressTracker:
    def __init__(self):
        self.progress = 0
        self.current_step = ""
        self.status = "idle"
    
    def update_progress(self, step, progress, status="running"):
        self.current_step = step
        self.progress = progress
        self.status = status
        current_progress.update({
            "status": status,
            "step": step,
            "progress": progress
        })
        progress_queue.put({
            "type": "step",
            "message": f"📊 {step}",
            "progress": progress
        })

# Create a custom BankerResearchTool with progress tracking
class TrackedBankerResearchTool(BankerResearchTool):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.tracker = ProgressTracker()
    
    def generate_financial_report(self, ticker_symbol):
        """
        Override the original method to add progress tracking
        """
        self.tracker.update_progress("Initializing research tool...", 5)
        
        # 1. Get company news summary
        self.tracker.update_progress(f"Fetching company news for {ticker_symbol}...", 15)
        company_news_summary = self.google_news_llm_summary(ticker_symbol)
        
        # 2. Get sector/industry news
        self.tracker.update_progress("Analyzing company fundamentals...", 25)
        fundamentals = self.get_company_fundamentals(ticker_symbol)
        
        if isinstance(fundamentals, dict) and fundamentals.get("Industry"):
            self.tracker.update_progress(f"Fetching industry news for {fundamentals['Industry']}...", 35)
            industry_summary = self.google_news_llm_summary(fundamentals["Industry"])
        else:
            industry_summary = "Industry information not available"
        
        # 3. Get financial statements and analyze
        self.tracker.update_progress("Analyzing financial statements...", 50)
        statements = self.get_financial_statements(ticker_symbol)
        
        if isinstance(statements, dict):
            self.tracker.update_progress("Processing quarterly income statement...", 55)
            quarterly_income_summary = self.llm_summarize_finance(statements["quarterly_income"])
            
            self.tracker.update_progress("Processing quarterly balance sheet...", 60)
            quarterly_balance_summary = self.llm_summarize_finance(statements["quarterly_balance"])
            
            self.tracker.update_progress("Processing quarterly cash flow...", 65)
            quarterly_cashflow_summary = self.llm_summarize_finance(statements["quarterly_cashflow"])
        else:
            quarterly_income_summary = "Financial statements not available"
            quarterly_balance_summary = "Balance sheet not available"
            quarterly_cashflow_summary = "Cash flow statement not available"
        
        # 4. Analyze competitors
        self.tracker.update_progress("Identifying and analyzing competitors...", 75)
        competitor_summaries = self.analyze_competitors(ticker_symbol)
        
        # 5. Generate comprehensive report
        self.tracker.update_progress("Generating comprehensive financial report...", 90)
        
        # Prepare competitor summaries for the prompt
        competitor_text = ""
        if isinstance(competitor_summaries, dict):
            for comp, summary in competitor_summaries.items():
                competitor_text += f"{comp} news summary: {summary}\n"
        
        prompt = f"""
        You are a financial research expert. Please create a comprehensive financial report for {ticker_symbol} based on the following information:
        
        Company News Summary: {company_news_summary}
        
        Industry News Summary: {industry_summary}
        
        Quarterly Income Statement Summary: {quarterly_income_summary}
        
        Quarterly Balance Sheet Summary: {quarterly_balance_summary}
        
        Quarterly Cash Flow Summary: {quarterly_cashflow_summary}
        
        Competitor Analysis:
        {competitor_text}
        
        Please structure the report with clear sections and provide actionable insights for investors.
        """
        
        response = self.client.chat.completions.create(
            model="gpt-4o",
            messages=[
                {"role": "system", "content": "You are a financial research expert."},
                {"role": "user", "content": prompt}
            ],
            max_tokens=2000,
            temperature=0.1,
        )
        
        result = response.choices[0].message.content
        formatted_result = self.format_text(result)
        final_report = formatted_result.replace('**', '')
        
        self.tracker.update_progress("Financial analysis complete!", 100, "complete")
        
        return final_report

@app.route('/research-client', methods=['POST'])
def research_client():
    try:
        data = request.get_json()
        ticker_symbol = data.get('ticker_symbol', 'NVDA')
        
        # Initialize the research tool with your API keys
        openai_api_key = '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'
        tavily_api_key = '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'
        anthropic_api_key = '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'
        
        # Clear previous progress
        while not progress_queue.empty():
            progress_queue.get()
        
        def run_research():
            try:
                tool = TrackedBankerResearchTool(
                    openai_api_key=openai_api_key,
                    tavily_api_key=tavily_api_key,
                    anthropic_api_key=anthropic_api_key
                )
                
                report = tool.generate_financial_report(ticker_symbol)
                
                # Add final result to queue
                progress_queue.put({
                    "type": "result",
                    "message": f"## 🏦 Banking Intelligence Report - {ticker_symbol}\n\n{report}",
                    "progress": 100
                })
                
            except Exception as e:
                progress_queue.put({
                    "type": "error",
                    "message": f"❌ Error during research: {str(e)}",
                    "progress": 0
                })
        
        # Start research in background thread
        research_thread = threading.Thread(target=run_research)
        research_thread.daemon = True
        research_thread.start()
        
        return jsonify({
            "status": "started",
            "message": "Research process initiated successfully"
        })
        
    except Exception as e:
        return jsonify({
            "status": "error",
            "message": f"Failed to start research: {str(e)}"
        }), 500

@app.route('/research-progress', methods=['GET'])
def get_research_progress():
    """Get current research progress"""
    return jsonify(current_progress)

@app.route('/research-stream', methods=['GET'])
def research_stream():
    """Server-Sent Events endpoint for real-time progress updates"""
    def generate():
        while True:
            try:
                # Get progress update from queue (with timeout)
                if not progress_queue.empty():
                    progress_data = progress_queue.get_nowait()
                    yield f"data: {json.dumps(progress_data)}\n\n"
                    
                    # If research is complete or error, break the stream
                    if progress_data.get("type") in ["result", "error"]:
                        break
                else:
                    # Send keepalive
                    yield f"data: {json.dumps({'type': 'keepalive'})}\n\n"
                
                time.sleep(1)  # Check every second
                
            except Exception as e:
                yield f"data: {json.dumps({'type': 'error', 'message': str(e)})}\n\n"
                break
    
    return Response(
        generate(), 
        mimetype='text/event-stream',
        headers={
            'Cache-Control': 'no-cache',
            'Connection': 'keep-alive',
            'Access-Control-Allow-Origin': '*'
        }
    )

@app.route('/health', methods=['GET'])
def health_check():
    return jsonify({"status": "healthy", "message": "BankerResearchTool API is running"})

if __name__ == '__main__':
    print("Starting BankerResearchTool API server...")
    print("Available endpoints:")
    print("- POST /research-client: Start research process")
    print("- GET /research-progress: Get current progress")
    print("- GET /research-stream: Real-time progress stream")
    print("- GET /health: Health check")
    
    app.run(debug=True, host='0.0.0.0', port=8000, threaded=True)