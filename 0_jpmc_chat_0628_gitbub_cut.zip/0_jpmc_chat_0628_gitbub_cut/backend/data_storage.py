"""
Data Storage Solutions for Mock Banking Data
Provides multiple options for storing and managing mock data
"""

import json
import sqlite3
import csv
import os
from typing import Dict, List, Any
from datetime import datetime
import pandas as pd

# =====================================================
# OPTION 1: JSON FILES DATA STORAGE
# =====================================================

class JSONDataStorage:
    """Store mock data in JSON files for easy editing and version control"""
    
    def __init__(self, data_directory: str = "data"):
        self.data_dir = data_directory
        self.ensure_data_directory()
        self.initialize_data_files()
    
    def ensure_data_directory(self):
        """Create data directory if it doesn't exist"""
        if not os.path.exists(self.data_dir):
            os.makedirs(self.data_dir)
            print(f"Created data directory: {self.data_dir}")
    
    def initialize_data_files(self):
        """Initialize JSON data files if they don't exist"""
        
        # Salesforce Opportunities - TechFlow Industries only
        opportunities_file = os.path.join(self.data_dir, "salesforce_opportunities.json")
        if not os.path.exists(opportunities_file):
            opportunities_data = [
                {
                    "id": "OPP001",
                    "account_name": "TechFlow Industries",
                    "country": "United States",
                    "opportunity_name": "Global Credit Facility Expansion",
                    "stage": "Negotiation",
                    "amount": 15000000,
                    "probability": 75,
                    "close_date": "2025-08-15",
                    "owner": "John Smith",
                    "description": "Expanding global credit facility to support international expansion"
                },
                {
                    "id": "OPP002", 
                    "account_name": "TechFlow Industries UK Ltd",
                    "country": "United Kingdom",
                    "opportunity_name": "Brexit Resilience Financing",
                    "stage": "Proposal",
                    "amount": 5000000,
                    "probability": 60,
                    "close_date": "2025-09-30",
                    "owner": "John Smith",
                    "description": "Financing package to mitigate Brexit-related supply chain risks"
                },
                {
                    "id": "OPP003",
                    "account_name": "TechFlow Industries Singapore Pte Ltd",
                    "country": "Singapore",
                    "opportunity_name": "APAC Treasury Optimization",
                    "stage": "Qualification",
                    "amount": 2500000,
                    "probability": 50,
                    "close_date": "2025-10-15",
                    "owner": "John Smith",
                    "description": "Comprehensive treasury management for APAC operations"
                },
                {
                    "id": "OPP004",
                    "account_name": "TechFlow Industries Canada Inc",
                    "country": "Canada",
                    "opportunity_name": "New Entity Banking Package",
                    "stage": "Closed Won",
                    "amount": 1200000,
                    "probability": 100,
                    "close_date": "2025-06-01",
                    "owner": "John Smith",
                    "description": "Complete banking services setup for new Canadian entity"
                }
            ]
            self.save_json_data("salesforce_opportunities.json", opportunities_data)
            print("Created salesforce_opportunities.json")
        
        # Salesforce Tasks - TechFlow Industries only
        tasks_file = os.path.join(self.data_dir, "salesforce_tasks.json")
        if not os.path.exists(tasks_file):
            tasks_data = [
                {
                    "id": "TASK001",
                    "account_name": "TechFlow Industries",
                    "country": "United States",
                    "subject": "Review consolidated financial statements",
                    "status": "In Progress",
                    "priority": "High",
                    "due_date": "2025-07-05",
                    "assigned_to": "John Smith",
                    "description": "Analyze Q2 consolidated financials across all entities for credit review"
                },
                {
                    "id": "TASK002",
                    "account_name": "TechFlow Industries UK Ltd",
                    "country": "United Kingdom",
                    "subject": "Brexit impact assessment documentation",
                    "status": "Not Started",
                    "priority": "Medium",
                    "due_date": "2025-07-10",
                    "assigned_to": "John Smith",
                    "description": "Compile Brexit risk mitigation strategies and financial impact analysis"
                },
                {
                    "id": "TASK003",
                    "account_name": "TechFlow Industries Singapore Pte Ltd",
                    "country": "Singapore",
                    "subject": "APAC market expansion analysis",
                    "status": "In Progress",
                    "priority": "Medium",
                    "due_date": "2025-07-15",
                    "assigned_to": "John Smith",
                    "description": "Research additional APAC markets for TechFlow expansion"
                },
                {
                    "id": "TASK004",
                    "account_name": "TechFlow Industries Canada Inc",
                    "country": "Canada",
                    "subject": "Complete onboarding documentation",
                    "status": "Completed",
                    "priority": "High",
                    "due_date": "2025-06-28",
                    "assigned_to": "John Smith",
                    "description": "Finalize all regulatory and compliance documentation for Canadian entity"
                }
            ]
            self.save_json_data("salesforce_tasks.json", tasks_data)
            print("Created salesforce_tasks.json")
        
        # Salesforce Interactions - TechFlow Industries only
        interactions_file = os.path.join(self.data_dir, "salesforce_interactions.json")
        if not os.path.exists(interactions_file):
            interactions_data = [
                {
                    "id": "INT001",
                    "account_name": "TechFlow Industries",
                    "country": "United States",
                    "interaction_type": "Phone Call",
                    "date": "2025-06-25",
                    "duration_minutes": 60,
                    "participant": "CFO Mike Johnson",
                    "summary": "Discussed global expansion financing needs and credit facility consolidation",
                    "next_steps": "Send consolidated term sheet by July 1st"
                },
                {
                    "id": "INT002",
                    "account_name": "TechFlow Industries UK Ltd",
                    "country": "United Kingdom",
                    "interaction_type": "Video Call",
                    "date": "2025-06-20",
                    "duration_minutes": 45,
                    "participant": "UK Managing Director James Wilson",
                    "summary": "Reviewed UK performance and discussed Brexit contingency financing",
                    "next_steps": "Provide Brexit resilience proposal by July 15th"
                },
                {
                    "id": "INT003",
                    "account_name": "TechFlow Industries Singapore Pte Ltd",
                    "country": "Singapore",
                    "interaction_type": "Email",
                    "date": "2025-06-28",
                    "duration_minutes": 0,
                    "participant": "Singapore CFO Li Wei",
                    "summary": "Confirmed Q2 performance metrics and treasury optimization interest",
                    "next_steps": "Schedule APAC strategy meeting"
                },
                {
                    "id": "INT004",
                    "account_name": "TechFlow Industries Canada Inc",
                    "country": "Canada",
                    "interaction_type": "Meeting",
                    "date": "2025-06-22",
                    "duration_minutes": 90,
                    "participant": "Canada GM Robert Chen",
                    "summary": "Onboarding meeting for new Canadian entity setup",
                    "next_steps": "Finalize banking services implementation"
                }
            ]
            self.save_json_data("salesforce_interactions.json", interactions_data)
            print("Created salesforce_interactions.json")
        
        # Customer Emails - TechFlow Industries only
        emails_file = os.path.join(self.data_dir, "customer_emails.json")
        if not os.path.exists(emails_file):
            emails_data = [
                {
                    "id": "EMAIL001",
                    "account_name": "TechFlow Industries",
                    "country": "United States",
                    "from": "mike.johnson@techflow.com",
                    "subject": "Consolidated Q2 Financial Projections",
                    "date": "2025-06-26",
                    "content": "Hi John, attached are our consolidated Q2 projections across all entities. Global revenue growth looks strong at 18% YoY. We're ready to discuss the expanded credit facility.",
                    "sentiment": "Positive",
                    "urgency": "Medium"
                },
                {
                    "id": "EMAIL002",
                    "account_name": "TechFlow Industries UK Ltd",
                    "country": "United Kingdom",
                    "from": "james.wilson@techflow.co.uk", 
                    "subject": "UK Market Performance Update",
                    "date": "2025-06-24",
                    "content": "John, despite Brexit challenges, our UK operations are exceeding targets. Q2 revenue up 12% vs plan. The resilience financing proposal looks attractive for H2 expansion.",
                    "sentiment": "Positive",
                    "urgency": "Low"
                },
                {
                    "id": "EMAIL003",
                    "account_name": "TechFlow Industries Singapore Pte Ltd",
                    "country": "Singapore",
                    "from": "li.wei@techflow.com.sg",
                    "subject": "APAC Treasury Optimization Inquiry",
                    "date": "2025-06-27",
                    "content": "Hi John, we're interested in the treasury optimization proposal. Our current cash management across APAC could be more efficient. Let's discuss timing and implementation.",
                    "sentiment": "Neutral",
                    "urgency": "Medium"
                },
                {
                    "id": "EMAIL004",
                    "account_name": "TechFlow Industries Canada Inc",
                    "country": "Canada",
                    "from": "robert.chen@techflow.ca",
                    "subject": "Canadian Entity Setup Complete",
                    "date": "2025-06-29",
                    "content": "John, thank you for the smooth onboarding process. All banking services are now active and our first transactions went through perfectly. Great partnership!",
                    "sentiment": "Very Positive",
                    "urgency": "Low"
                }
            ]
            self.save_json_data("customer_emails.json", emails_data)
            print("Created customer_emails.json")
        
        # Commercial Products
        products_file = os.path.join(self.data_dir, "commercial_products.json")
        if not os.path.exists(products_file):
            products_data = [
                {
                    "product_id": "PROD001",
                    "name": "Revolving Credit Line",
                    "category": "Lending",
                    "description": "Flexible credit facility for working capital needs",
                    "min_amount": 100000,
                    "max_amount": 10000000,
                    "base_rate": "Prime + 1.5%",
                    "features": ["Draw as needed", "Interest-only payments", "Annual review"]
                },
                {
                    "product_id": "PROD002", 
                    "name": "ESG Bond Financing",
                    "category": "Capital Markets",
                    "description": "Green and sustainability-linked bond underwriting",
                    "min_amount": 1000000,
                    "max_amount": 100000000,
                    "base_rate": "Variable based on ESG rating",
                    "features": ["ESG compliance", "Impact reporting", "Competitive pricing"]
                },
                {
                    "product_id": "PROD003",
                    "name": "Treasury Management Suite",
                    "category": "Treasury Services",
                    "description": "Comprehensive cash management platform",
                    "min_amount": 0,
                    "max_amount": 0,
                    "base_rate": "Monthly fee based on volume",
                    "features": ["Real-time reporting", "Automated sweeps", "Fraud protection"]
                },
                {
                    "product_id": "PROD004",
                    "name": "Trade Finance Solutions",
                    "category": "Trade Services",
                    "description": "Letters of credit and trade financing",
                    "min_amount": 50000,
                    "max_amount": 25000000,
                    "base_rate": "Libor + 2.0%",
                    "features": ["Global network", "Digital processing", "Risk mitigation"]
                }
            ]
            self.save_json_data("commercial_products.json", products_data)
            print("Created commercial_products.json")
        
        # Account Summaries - Single customer with multiple country operations
        accounts_file = os.path.join(self.data_dir, "account_summaries.json")
        if not os.path.exists(accounts_file):
            accounts_data = [
                {
                    "account_name": "TechFlow Industries",
                    "account_id": "ACC001",
                    "country": "United States",
                    "entity_type": "Parent Company",
                    "relationship_tier": "Key Account",
                    "annual_revenue": 12500000,
                    "relationship_length_years": 5,
                    "primary_banker": "John Smith",
                    "total_exposure": 8500000,
                    "products_used": ["Revolving Credit Line", "Treasury Management", "FX Services"],
                    "risk_rating": "Investment Grade",
                    "last_review_date": "2025-03-15"
                },
                {
                    "account_name": "TechFlow Industries UK Ltd",
                    "account_id": "ACC002", 
                    "country": "United Kingdom",
                    "entity_type": "Subsidiary",
                    "relationship_tier": "Key Account",
                    "annual_revenue": 4200000,
                    "relationship_length_years": 3,
                    "primary_banker": "John Smith",
                    "total_exposure": 2800000,
                    "products_used": ["Term Loan", "Trade Finance", "Cash Management"],
                    "risk_rating": "Investment Grade",
                    "last_review_date": "2025-04-20"
                },
                {
                    "account_name": "TechFlow Industries Singapore Pte Ltd",
                    "account_id": "ACC003",
                    "country": "Singapore",
                    "entity_type": "Subsidiary",
                    "relationship_tier": "Key Account",
                    "annual_revenue": 2800000,
                    "relationship_length_years": 2,
                    "primary_banker": "John Smith",
                    "total_exposure": 1900000,
                    "products_used": ["Working Capital Line", "FX Services", "Treasury Management"],
                    "risk_rating": "Investment Grade",
                    "last_review_date": "2025-05-10"
                },
                {
                    "account_name": "TechFlow Industries Canada Inc",
                    "account_id": "ACC004",
                    "country": "Canada",
                    "entity_type": "Subsidiary",
                    "relationship_tier": "Key Account",
                    "annual_revenue": 1800000,
                    "relationship_length_years": 1,
                    "primary_banker": "John Smith",
                    "total_exposure": 1200000,
                    "products_used": ["Credit Line", "Commercial Card", "Cash Management"],
                    "risk_rating": "Investment Grade",
                    "last_review_date": "2025-06-01"
                }
            ]
            self.save_json_data("account_summaries.json", accounts_data)
            print("Created account_summaries.json")
        
        # Capital Usage - Updated for TechFlow entities only
        capital_file = os.path.join(self.data_dir, "capital_usage.json")
        if not os.path.exists(capital_file):
            capital_data = [
                {
                    "account_name": "TechFlow Industries",
                    "country": "United States",
                    "facility_type": "Revolving Credit Line",
                    "total_limit": 10000000,
                    "outstanding_amount": 7200000,
                    "utilization_rate": 72,
                    "available_amount": 2800000,
                    "last_draw_date": "2025-06-15",
                    "maturity_date": "2026-12-31"
                },
                {
                    "account_name": "TechFlow Industries UK Ltd",
                    "country": "United Kingdom",
                    "facility_type": "Term Loan",
                    "total_limit": 3500000,
                    "outstanding_amount": 2240000,
                    "utilization_rate": 64,
                    "available_amount": 1260000,
                    "last_draw_date": "2025-05-10",
                    "maturity_date": "2027-05-10"
                },
                {
                    "account_name": "TechFlow Industries Singapore Pte Ltd",
                    "country": "Singapore",
                    "facility_type": "Working Capital Line",
                    "total_limit": 2200000,
                    "outstanding_amount": 1320000,
                    "utilization_rate": 60,
                    "available_amount": 880000,
                    "last_draw_date": "2025-06-20",
                    "maturity_date": "2026-06-20"
                },
                {
                    "account_name": "TechFlow Industries Canada Inc",
                    "country": "Canada",
                    "facility_type": "Credit Line",
                    "total_limit": 1500000,
                    "outstanding_amount": 840000,
                    "utilization_rate": 56,
                    "available_amount": 660000,
                    "last_draw_date": "2025-06-25",
                    "maturity_date": "2025-12-20"
                }
            ]
            self.save_json_data("capital_usage.json", capital_data)
            print("Created capital_usage.json")
        
        # Credit Exposure - Updated for TechFlow entities only
        exposure_file = os.path.join(self.data_dir, "credit_exposure.json")
        if not os.path.exists(exposure_file):
            exposure_data = [
                {
                    "account_name": "TechFlow Industries",
                    "country": "United States",
                    "total_exposure": 8500000,
                    "secured_portion": 6400000,
                    "unsecured_portion": 2100000,
                    "guarantees": 1500000,
                    "risk_rating": "BBB+",
                    "probability_of_default": 1.8,
                    "loss_given_default": 42,
                    "next_review_date": "2025-09-15"
                },
                {
                    "account_name": "TechFlow Industries UK Ltd",
                    "country": "United Kingdom",
                    "total_exposure": 2800000,
                    "secured_portion": 2240000,
                    "unsecured_portion": 560000,
                    "guarantees": 1000000,
                    "risk_rating": "BBB+",
                    "probability_of_default": 1.8,
                    "loss_given_default": 42,
                    "next_review_date": "2025-10-20"
                },
                {
                    "account_name": "TechFlow Industries Singapore Pte Ltd",
                    "country": "Singapore",
                    "total_exposure": 1900000,
                    "secured_portion": 1520000,
                    "unsecured_portion": 380000,
                    "guarantees": 800000,
                    "risk_rating": "BBB+",
                    "probability_of_default": 1.8,
                    "loss_given_default": 42,
                    "next_review_date": "2025-11-15"
                },
                {
                    "account_name": "TechFlow Industries Canada Inc",
                    "country": "Canada",
                    "total_exposure": 1200000,
                    "secured_portion": 960000,
                    "unsecured_portion": 240000,
                    "guarantees": 500000,
                    "risk_rating": "BBB+",
                    "probability_of_default": 1.8,
                    "loss_given_default": 42,
                    "next_review_date": "2025-08-01"
                }
            ]
            self.save_json_data("credit_exposure.json", exposure_data)
            print("Created credit_exposure.json")
        
        # Meetings - Updated for TechFlow entities only
        meetings_file = os.path.join(self.data_dir, "meetings.json")
        if not os.path.exists(meetings_file):
            meetings_data = [
                {
                    "id": "MEET001",
                    "account_name": "TechFlow Industries",
                    "country": "United States",
                    "meeting_type": "Annual Credit Review",
                    "date": "2025-07-08",
                    "time": "10:00 AM",
                    "duration_minutes": 120,
                    "attendees": ["John Smith", "Credit Manager", "CFO Mike Johnson", "Treasury Director"],
                    "agenda": "Review consolidated Q2 financials and global credit facility expansion",
                    "location": "Client Office - New York",
                    "status": "Scheduled"
                },
                {
                    "id": "MEET002",
                    "account_name": "TechFlow Industries UK Ltd",
                    "country": "United Kingdom",
                    "meeting_type": "Business Review",
                    "date": "2025-07-12",
                    "time": "2:00 PM", 
                    "duration_minutes": 90,
                    "attendees": ["John Smith", "Product Specialist", "UK Managing Director James Wilson"],
                    "agenda": "UK expansion financing and Brexit impact assessment",
                    "location": "Video Call",
                    "status": "Scheduled"
                },
                {
                    "id": "MEET003",
                    "account_name": "TechFlow Industries Singapore Pte Ltd",
                    "country": "Singapore",
                    "meeting_type": "Quarterly Review",
                    "date": "2025-07-15",
                    "time": "11:00 AM",
                    "duration_minutes": 60,
                    "attendees": ["John Smith", "APAC Regional Manager", "Singapore CFO Li Wei"],
                    "agenda": "Q2 APAC performance and working capital optimization",
                    "location": "Video Call",
                    "status": "Confirmed"
                },
                {
                    "id": "MEET004",
                    "account_name": "TechFlow Industries Canada Inc",
                    "country": "Canada",
                    "meeting_type": "Setup Meeting",
                    "date": "2025-07-20",
                    "time": "3:00 PM",
                    "duration_minutes": 45,
                    "attendees": ["John Smith", "Canada Relationship Manager", "Canada GM Robert Chen"],
                    "agenda": "New entity onboarding and banking service setup",
                    "location": "Bank Office - Toronto",
                    "status": "Scheduled"
                }
            ]
            self.save_json_data("meetings.json", meetings_data)
            print("Created meetings.json")
    
    def save_json_data(self, filename: str, data: List[Dict]):
        """Save data to JSON file"""
        filepath = os.path.join(self.data_dir, filename)
        with open(filepath, 'w') as f:
            json.dump(data, f, indent=2, default=str)
    
    def load_json_data(self, filename: str) -> List[Dict]:
        """Load data from JSON file"""
        filepath = os.path.join(self.data_dir, filename)
        if os.path.exists(filepath):
            with open(filepath, 'r') as f:
                return json.load(f)
        return []
    
    def get_salesforce_opportunities(self) -> List[Dict]:
        return self.load_json_data("salesforce_opportunities.json")
    
    def get_salesforce_tasks(self) -> List[Dict]:
        return self.load_json_data("salesforce_tasks.json")
    
    def get_salesforce_interactions(self) -> List[Dict]:
        return self.load_json_data("salesforce_interactions.json")
    
    def get_customer_emails(self) -> List[Dict]:
        return self.load_json_data("customer_emails.json")
    
    def get_commercial_products(self) -> List[Dict]:
        return self.load_json_data("commercial_products.json")
    
    def get_account_summaries(self) -> List[Dict]:
        return self.load_json_data("account_summaries.json")
    
    def get_capital_usage(self) -> List[Dict]:
        return self.load_json_data("capital_usage.json")
    
    def get_credit_exposure(self) -> List[Dict]:
        return self.load_json_data("credit_exposure.json")
    
    def get_meetings(self) -> List[Dict]:
        return self.load_json_data("meetings.json")

# =====================================================
# OPTION 2: UNIFIED DATA MANAGER
# =====================================================

class BankingDataManager:
    """Unified data manager that can use different storage backends"""
    
    def __init__(self, storage_type: str = "json", data_path: str = "data"):
        self.storage_type = storage_type
        
        if storage_type == "json":
            self.storage = JSONDataStorage(data_path)
        else:
            raise ValueError(f"Unsupported storage type: {storage_type}")
    
    def get_all_data(self) -> Dict[str, List[Dict]]:
        """Get all banking data from storage"""
        return {
            "opportunities": self.storage.get_salesforce_opportunities(),
            "tasks": self.storage.get_salesforce_tasks(),
            "interactions": self.storage.get_salesforce_interactions(),
            "emails": self.storage.get_customer_emails(),
            "products": self.storage.get_commercial_products(),
            "accounts": self.storage.get_account_summaries(),
            "capital_usage": self.storage.get_capital_usage(),
            "credit_exposure": self.storage.get_credit_exposure(),
            "meetings": self.storage.get_meetings()
        }
    
    def search_data(self, query: str, entities: List[str]) -> Dict[str, List[Dict]]:
        """Search data based on query and entities"""
        all_data = self.get_all_data()
        
        if not entities:
            return all_data
        
        # Filter data based on entities
        filtered_data = {}
        for key, data_list in all_data.items():
            filtered_data[key] = []
            for item in data_list:
                # Check if any entity matches any field in the item
                for entity in entities:
                    entity_lower = entity.lower()
                    if any(entity_lower in str(value).lower() for value in item.values()):
                        filtered_data[key].append(item)
                        break
        
        return filtered_data

# =====================================================
# EXAMPLE USAGE
# =====================================================

def main():
    """Initialize banking data storage"""
    
    print("🏦 Initializing Banking Data Storage...")
    print("=" * 50)
    
    # Create JSON storage
    print("📁 Creating JSON data storage...")
    json_storage = JSONDataStorage("data")
    
    print("\n🔍 Verifying data creation...")
    data_manager = BankingDataManager("json", "data")
    all_data = data_manager.get_all_data()
    
    print(f"✅ Created {len(all_data)} data sources:")
    for key, data_list in all_data.items():
        print(f"   - {key}: {len(data_list)} records")
    
    print(f"\n📊 Total records: {sum(len(data_list) for data_list in all_data.values())}")
    print("\n🎉 Banking data storage initialized successfully!")
    print("\nYou can now run: python main.py")

if __name__ == "__main__":
    main()