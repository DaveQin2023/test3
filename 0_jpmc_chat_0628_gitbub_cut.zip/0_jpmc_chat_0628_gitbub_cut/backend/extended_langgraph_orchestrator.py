"""
Extended LangGraph Orchestrator with Dynamic Workflow and Data Source Tools
"""

import json
import asyncio
import os
from datetime import datetime
from typing import Dict, List, Any, Optional, Union
from dataclasses import dataclass, field
from enum import Enum

# LangGraph imports
from langgraph.graph import StateGraph, END
from langchain_core.messages import HumanMessage
from langchain_openai import ChatOpenAI

# =====================================================
# DATA SOURCE IDENTIFICATION AND TOOLS
# =====================================================

class DataSource(Enum):
    """Available data sources from your files"""
    SALESFORCE_OPPORTUNITIES = "salesforce_opportunities"
    SALESFORCE_TASKS = "salesforce_tasks" 
    SALESFORCE_INTERACTIONS = "salesforce_interactions"
    CUSTOMER_EMAILS = "customer_emails"
    COMMERCIAL_PRODUCTS = "commercial_products"
    ACCOUNT_SUMMARIES = "account_summaries"
    CAPITAL_USAGE = "capital_usage"
    CREDIT_EXPOSURE = "credit_exposure"
    MEETINGS = "meetings"

@dataclass
class DataSourceSchema:
    """Schema definition for each data source"""
    name: str
    description: str
    fields: List[str]
    sample_query: str
    relationships: List[str]

# Define schemas for all data sources
DATA_SOURCE_SCHEMAS = {
    DataSource.SALESFORCE_OPPORTUNITIES: DataSourceSchema(
        name="Salesforce Opportunities",
        description="Sales opportunities and pipeline data for TechFlow Industries",
        fields=["id", "account_name", "country", "opportunity_name", "stage", "amount", "probability", "close_date", "owner", "description"],
        sample_query="Get all opportunities for TechFlow with probability > 50%",
        relationships=["account_summaries", "salesforce_tasks", "meetings"]
    ),
    DataSource.SALESFORCE_TASKS: DataSourceSchema(
        name="Salesforce Tasks", 
        description="Outstanding tasks and action items related to TechFlow accounts",
        fields=["id", "account_name", "country", "subject", "status", "priority", "due_date", "assigned_to", "description"],
        sample_query="Get high priority tasks due in next 7 days",
        relationships=["salesforce_opportunities", "account_summaries"]
    ),
    DataSource.SALESFORCE_INTERACTIONS: DataSourceSchema(
        name="Salesforce Interactions",
        description="Client interaction history and touchpoints",
        fields=["id", "account_name", "country", "interaction_type", "date", "duration_minutes", "participant", "summary", "next_steps"],
        sample_query="Get recent interactions in last 30 days",
        relationships=["customer_emails", "meetings", "account_summaries"]
    ),
    DataSource.CUSTOMER_EMAILS: DataSourceSchema(
        name="Customer Emails",
        description="Email communications with TechFlow Industries contacts",
        fields=["id", "account_name", "country", "from", "subject", "date", "content", "sentiment", "urgency"],
        sample_query="Get emails with positive sentiment from last quarter",
        relationships=["salesforce_interactions", "account_summaries"]
    ),
    DataSource.COMMERCIAL_PRODUCTS: DataSourceSchema(
        name="Commercial Products",
        description="Available banking products and services",
        fields=["product_id", "name", "category", "description", "min_amount", "max_amount", "base_rate", "features"],
        sample_query="Get lending products suitable for technology companies",
        relationships=["account_summaries", "credit_exposure"]
    ),
    DataSource.ACCOUNT_SUMMARIES: DataSourceSchema(
        name="Account Summaries",
        description="Comprehensive account information for all TechFlow entities",
        fields=["account_name", "account_id", "country", "entity_type", "relationship_tier", "annual_revenue", "relationship_length_years", "primary_banker", "total_exposure", "products_used", "risk_rating", "last_review_date"],
        sample_query="Get all TechFlow entities with their key metrics",
        relationships=["capital_usage", "credit_exposure", "meetings", "salesforce_opportunities"]
    ),
    DataSource.CAPITAL_USAGE: DataSourceSchema(
        name="Capital Usage",
        description="Credit facility utilization and availability data",
        fields=["account_name", "country", "facility_type", "total_limit", "outstanding_amount", "utilization_rate", "available_amount", "last_draw_date", "maturity_date"],
        sample_query="Get facilities with utilization > 70%",
        relationships=["account_summaries", "credit_exposure"]
    ),
    DataSource.CREDIT_EXPOSURE: DataSourceSchema(
        name="Credit Exposure",
        description="Credit risk metrics and exposure analysis",
        fields=["account_name", "country", "total_exposure", "secured_portion", "unsecured_portion", "guarantees", "risk_rating", "probability_of_default", "loss_given_default", "next_review_date"],
        sample_query="Get credit metrics for risk assessment",
        relationships=["account_summaries", "capital_usage"]
    ),
    DataSource.MEETINGS: DataSourceSchema(
        name="Meetings",
        description="Scheduled and past meetings with TechFlow team",
        fields=["id", "account_name", "country", "meeting_type", "date", "time", "duration_minutes", "attendees", "agenda", "location", "status"],
        sample_query="Get upcoming meetings in next 2 weeks",
        relationships=["account_summaries", "salesforce_interactions"]
    )
}

# =====================================================
# DATA ACCESS TOOLS
# =====================================================

class DataAccessTool:
    """Base class for data access tools"""
    
    def __init__(self, data_source: DataSource):
        self.data_source = data_source
        self.schema = DATA_SOURCE_SCHEMAS[data_source]
        self.data_manager = self._load_data_manager()
    
    def _load_data_manager(self):
        """Load the data manager"""
        try:
            from data_storage import BankingDataManager
            return BankingDataManager("json", "data")
        except ImportError:
            return None
    
    async def query(self, filters: Dict[str, Any] = None, fields: List[str] = None) -> List[Dict[str, Any]]:
        """Query data with optional filters and field selection"""
        if not self.data_manager:
            return []
        
        # Get all data first
        all_data = self.data_manager.get_all_data()
        data_key = self.data_source.value
        
        if data_key not in all_data:
            return []
        
        data = all_data[data_key]
        
        # Apply filters if provided
        if filters:
            filtered_data = []
            for item in data:
                match = True
                for key, value in filters.items():
                    if key not in item:
                        match = False
                        break
                    
                    if isinstance(value, str):
                        if value.lower() not in str(item[key]).lower():
                            match = False
                            break
                    elif isinstance(value, (int, float)):
                        if item[key] != value:
                            match = False
                            break
                    elif isinstance(value, dict):
                        # Handle range queries like {"amount": {"$gt": 1000000}}
                        if "$gt" in value and item[key] <= value["$gt"]:
                            match = False
                            break
                        if "$lt" in value and item[key] >= value["$lt"]:
                            match = False
                            break
                        if "$gte" in value and item[key] < value["$gte"]:
                            match = False
                            break
                        if "$lte" in value and item[key] > value["$lte"]:
                            match = False
                            break
                
                if match:
                    filtered_data.append(item)
            data = filtered_data
        
        # Select specific fields if provided
        if fields:
            selected_data = []
            for item in data:
                selected_item = {field: item.get(field) for field in fields if field in item}
                selected_data.append(selected_item)
            data = selected_data
        
        return data
    
    async def search(self, query_text: str) -> List[Dict[str, Any]]:
        """Search data using text query"""
        if not self.data_manager:
            return []
        
        # Use existing search functionality
        search_results = self.data_manager.search_data(query_text, [query_text])
        data_key = self.data_source.value
        
        return search_results.get(data_key, [])
    
    async def aggregate(self, group_by: str, metrics: List[str]) -> Dict[str, Any]:
        """Aggregate data by a field"""
        data = await self.query()
        
        aggregated = {}
        for item in data:
            group_value = item.get(group_by, "unknown")
            if group_value not in aggregated:
                aggregated[group_value] = {"count": 0, "items": []}
            
            aggregated[group_value]["count"] += 1
            aggregated[group_value]["items"].append(item)
            
            # Calculate metrics
            for metric in metrics:
                if metric in item and isinstance(item[metric], (int, float)):
                    if f"total_{metric}" not in aggregated[group_value]:
                        aggregated[group_value][f"total_{metric}"] = 0
                    aggregated[group_value][f"total_{metric}"] += item[metric]
        
        return aggregated

# Create tool instances for each data source
DATA_TOOLS = {
    data_source: DataAccessTool(data_source) 
    for data_source in DataSource
}

# =====================================================
# SPECIALIZED AGENTS
# =====================================================

class DataGatheringAgent:
    """Agent specialized in gathering data from multiple sources"""
    
    def __init__(self, llm):
        self.llm = llm
        self.tools = DATA_TOOLS
    
    async def gather_data(self, data_sources: List[str], query_context: str) -> Dict[str, Any]:
        """Gather data from specified sources based on context"""
        gathered_data = {}
        
        for source_name in data_sources:
            try:
                # Convert string to DataSource enum
                data_source = DataSource(source_name)
                tool = self.tools[data_source]
                
                # Query all data for now (could be enhanced with smart filtering)
                data = await tool.query()
                gathered_data[source_name] = data
                
            except (ValueError, KeyError) as e:
                print(f"Warning: Could not access data source {source_name}: {e}")
                gathered_data[source_name] = []
        
        return gathered_data

class AnalysisAgent:
    """Agent specialized in analyzing gathered data"""
    
    def __init__(self, llm):
        self.llm = llm
    
    async def analyze_data(self, data: Dict[str, Any], analysis_type: str, context: str) -> Dict[str, Any]:
        """Analyze data based on specified analysis type"""
        
        prompt = f"""
        Analyze the following TechFlow Industries data for {analysis_type}:
        
        Context: {context}
        
        Data:
        {json.dumps(data, indent=2, default=str)[:5000]}...
        
        Analysis Type: {analysis_type}
        
        Provide analysis in the following format:
        {{
            "summary": "Brief summary of findings",
            "key_insights": ["insight 1", "insight 2", "insight 3"],
            "metrics": {{"metric_name": "value"}},
            "recommendations": ["recommendation 1", "recommendation 2"],
            "risk_factors": ["risk 1", "risk 2"] if applicable
        }}
        
        Focus on actionable insights for banking relationship management.
        """
        
        response = await self.llm.ainvoke([HumanMessage(content=prompt)])
        
        try:
            # Try to parse JSON response
            if "```json" in response.content:
                json_start = response.content.find("```json") + 7
                json_end = response.content.find("```", json_start)
                json_content = response.content[json_start:json_end]
            else:
                # Look for JSON pattern
                start = response.content.find("{")
                end = response.content.rfind("}") + 1
                json_content = response.content[start:end] if start != -1 and end != 0 else "{}"
            
            analysis_result = json.loads(json_content)
            return analysis_result
            
        except json.JSONDecodeError:
            # Fallback to text analysis
            return {
                "summary": response.content[:500],
                "key_insights": ["Analysis completed - see summary"],
                "metrics": {},
                "recommendations": ["Review detailed analysis"],
                "risk_factors": []
            }

class RecommendationAgent:
    """Agent specialized in generating recommendations"""
    
    def __init__(self, llm):
        self.llm = llm
    
    async def generate_recommendations(self, analysis_results: List[Dict[str, Any]], context: str) -> List[Dict[str, Any]]:
        """Generate recommendations based on analysis results"""
        
        prompt = f"""
        Based on the following analysis results for TechFlow Industries, generate specific recommendations:
        
        Context: {context}
        
        Analysis Results:
        {json.dumps(analysis_results, indent=2, default=str)}
        
        Generate 3-5 specific, actionable recommendations in this format:
        [
            {{
                "recommendation": "Specific recommendation text",
                "priority": "high|medium|low",
                "category": "product|risk|relationship|operational",
                "rationale": "Why this recommendation is important",
                "expected_impact": "Expected business impact",
                "timeline": "Suggested implementation timeline"
            }}
        ]
        
        Focus on banking products, risk mitigation, and relationship enhancement.
        """
        
        response = await self.llm.ainvoke([HumanMessage(content=prompt)])
        
        try:
            # Parse JSON response
            if "```json" in response.content:
                json_start = response.content.find("```json") + 7
                json_end = response.content.find("```", json_start)
                json_content = response.content[json_start:json_end]
            else:
                start = response.content.find("[")
                end = response.content.rfind("]") + 1
                json_content = response.content[start:end] if start != -1 and end != 0 else "[]"
            
            recommendations = json.loads(json_content)
            return recommendations
            
        except json.JSONDecodeError:
            # Fallback recommendations
            return [{
                "recommendation": "Review analysis results and develop action plan",
                "priority": "medium",
                "category": "operational",
                "rationale": "Based on comprehensive data analysis",
                "expected_impact": "Improved client relationship management",
                "timeline": "Next 30 days"
            }]

class ConsolidationAgent:
    """Agent that consolidates data from multiple sources and coordinates other agents"""
    
    def __init__(self, llm):
        self.llm = llm
        self.data_gatherer = DataGatheringAgent(llm)
        self.analyzer = AnalysisAgent(llm)
        self.recommender = RecommendationAgent(llm)
    
    async def execute_task(self, task: Dict[str, Any]) -> Dict[str, Any]:
        """Execute a specific task by coordinating data gathering, analysis, and recommendations"""
        
        task_name = task.get("task_name", "Unknown Task")
        task_type = task.get("task_type", "analysis")
        data_sources = task.get("data_sources", [])
        expected_output = task.get("expected_output", "Task results")
        
        print(f"🔄 Executing task: {task_name}")
        
        # Step 1: Gather data from required sources
        gathered_data = await self.data_gatherer.gather_data(data_sources, task_name)
        
        # Step 2: Analyze the data if this is an analysis task
        analysis_results = []
        if task_type in ["analysis", "recommendation", "synthesis"]:
            for source, data in gathered_data.items():
                if data:  # Only analyze if we have data
                    analysis = await self.analyzer.analyze_data(
                        {source: data}, 
                        task_type, 
                        task_name
                    )
                    analysis_results.append(analysis)
        
        # Step 3: Generate recommendations if needed
        recommendations = []
        if task_type in ["recommendation", "synthesis"] and analysis_results:
            recommendations = await self.recommender.generate_recommendations(
                analysis_results, 
                task_name
            )
        
        # Step 4: Consolidate results
        task_result = {
            "task_id": task.get("task_id"),
            "task_name": task_name,
            "status": "completed",
            "data_gathered": {source: len(data) for source, data in gathered_data.items()},
            "analysis_results": analysis_results,
            "recommendations": recommendations,
            "summary": self._create_task_summary(task_name, gathered_data, analysis_results, recommendations)
        }
        
        return task_result
    
    def _create_task_summary(self, task_name: str, data: Dict, analysis: List, recommendations: List) -> str:
        """Create a summary of task execution"""
        data_summary = ", ".join([f"{source}: {len(items)} records" for source, items in data.items()])
        analysis_count = len(analysis)
        rec_count = len(recommendations)
        
        return f"Task '{task_name}' completed. Gathered data from {data_summary}. Generated {analysis_count} analyses and {rec_count} recommendations."

# =====================================================
# EXTENDED ORCHESTRATOR STATE
# =====================================================

@dataclass
class ExtendedOrchestratorState:
    """Extended state for dynamic workflow orchestration"""
    user_query: str
    available_data_summary: str
    identified_intent: str
    confidence_score: float
    decomposed_tasks: List[Dict[str, Any]]
    execution_plan: List[str]
    current_step: str
    step_count: int = 0
    errors: List[str] = field(default_factory=list)
    
    # New fields for extended functionality
    task_results: List[Dict[str, Any]] = field(default_factory=list)
    consolidated_analysis: Dict[str, Any] = field(default_factory=dict)
    final_recommendations: List[Dict[str, Any]] = field(default_factory=list)
    execution_status: Dict[str, str] = field(default_factory=dict)

# =====================================================
# DYNAMIC WORKFLOW CREATION
# =====================================================

def create_dynamic_workflow(tasks: List[Dict[str, Any]]) -> StateGraph:
    """Create a dynamic workflow based on decomposed tasks"""
    
    workflow = StateGraph(ExtendedOrchestratorState)
    
    # Add static nodes
    workflow.add_node("data_summary", data_summary_node)
    workflow.add_node("intent_identification", intent_identification_node) 
    workflow.add_node("task_decomposition", task_decomposition_node)
    workflow.add_node("execution_planning", execution_planning_node)
    
    # Add dynamic task execution nodes
    for i, task in enumerate(tasks):
        task_id = task.get("task_id", f"task_{i}")
        node_name = f"execute_{task_id}"
        
        # Create a closure to capture the task
        def create_task_node(task_def):
            async def task_node(state: ExtendedOrchestratorState) -> ExtendedOrchestratorState:
                return await execute_task_node(state, task_def)
            return task_node
        
        workflow.add_node(node_name, create_task_node(task))
    
    # Add consolidation node
    workflow.add_node("consolidate_results", consolidate_results_node)
    
    # Define workflow edges
    workflow.set_entry_point("data_summary")
    workflow.add_edge("data_summary", "intent_identification")
    workflow.add_edge("intent_identification", "task_decomposition") 
    workflow.add_edge("task_decomposition", "execution_planning")
    
    # Connect execution planning to first task or consolidation
    if tasks:
        first_task_id = tasks[0].get("task_id", "task_0")
        workflow.add_edge("execution_planning", f"execute_{first_task_id}")
        
        # Chain task nodes
        for i in range(len(tasks) - 1):
            current_task_id = tasks[i].get("task_id", f"task_{i}")
            next_task_id = tasks[i + 1].get("task_id", f"task_{i + 1}")
            workflow.add_edge(f"execute_{current_task_id}", f"execute_{next_task_id}")
        
        # Connect last task to consolidation
        last_task_id = tasks[-1].get("task_id", f"task_{len(tasks) - 1}")
        workflow.add_edge(f"execute_{last_task_id}", "consolidate_results")
    else:
        workflow.add_edge("execution_planning", "consolidate_results")
    
    workflow.add_edge("consolidate_results", END)
    
    return workflow.compile()

# =====================================================
# DYNAMIC WORKFLOW NODES
# =====================================================

async def execute_task_node(state: ExtendedOrchestratorState, task: Dict[str, Any]) -> ExtendedOrchestratorState:
    """Execute a specific task node"""
    try:
        # Get API key and initialize LLM
        api_key = os.getenv("OPENAI_API_KEY")
        if not api_key:
            raise ValueError("OPENAI_API_KEY not found")
        
        llm = ChatOpenAI(model="gpt-4o", temperature=0.3, max_tokens=2000, api_key=api_key)
        
        # Execute task using consolidation agent
        consolidation_agent = ConsolidationAgent(llm)
        task_result = await consolidation_agent.execute_task(task)
        
        # Update state
        state.task_results.append(task_result)
        state.execution_status[task.get("task_id", "unknown")] = "completed"
        state.current_step = f"Completed task: {task.get('task_name', 'Unknown')}"
        state.step_count += 1
        
    except Exception as e:
        error_msg = f"Error executing task {task.get('task_name', 'Unknown')}: {str(e)}"
        state.errors.append(error_msg)
        state.execution_status[task.get("task_id", "unknown")] = "failed"
    
    return state

async def consolidate_results_node(state: ExtendedOrchestratorState) -> ExtendedOrchestratorState:
    """Consolidate results from all executed tasks"""
    try:
        # Get API key and initialize LLM
        api_key = os.getenv("OPENAI_API_KEY")
        if not api_key:
            raise ValueError("OPENAI_API_KEY not found")
        
        llm = ChatOpenAI(model="gpt-4o", temperature=0.3, max_tokens=2000, api_key=api_key)
        
        # Consolidate all task results
        consolidation_agent = ConsolidationAgent(llm)
        
        # Extract all analysis results and recommendations
        all_analyses = []
        all_recommendations = []
        
        for task_result in state.task_results:
            all_analyses.extend(task_result.get("analysis_results", []))
            all_recommendations.extend(task_result.get("recommendations", []))
        
        # Generate final consolidated recommendations
        if all_analyses:
            final_recs = await consolidation_agent.recommender.generate_recommendations(
                all_analyses, 
                state.user_query
            )
            state.final_recommendations = final_recs
        
        # Create consolidated analysis
        state.consolidated_analysis = {
            "total_tasks_executed": len(state.task_results),
            "successful_tasks": len([r for r in state.task_results if state.execution_status.get(r.get("task_id"), "") == "completed"]),
            "failed_tasks": len([r for r in state.task_results if state.execution_status.get(r.get("task_id"), "") == "failed"]),
            "total_data_sources": len(set([source for result in state.task_results for source in result.get("data_gathered", {}).keys()])),
            "total_analyses": len(all_analyses),
            "total_recommendations": len(all_recommendations)
        }
        
        state.current_step = "Results consolidated"
        state.step_count += 1
        
    except Exception as e:
        state.errors.append(f"Error consolidating results: {str(e)}")
    
    return state

# Import the existing nodes from the original orchestrator
from langgraph_orchestrator import (
    data_summary_node, intent_identification_node, 
    task_decomposition_node, execution_planning_node
)

# =====================================================
# MAIN EXECUTION FUNCTION WITH DYNAMIC WORKFLOW
# =====================================================

async def run_extended_orchestrator(user_query: str) -> ExtendedOrchestratorState:
    """Run the extended orchestrator with dynamic workflow"""
    
    # Create initial state
    initial_state = ExtendedOrchestratorState(
        user_query=user_query,
        available_data_summary="",
        identified_intent="",
        confidence_score=0.0,
        decomposed_tasks=[],
        execution_plan=[],
        current_step="Starting extended orchestration"
    )
    
    try:
        # First, run the basic orchestration to get decomposed tasks
        print(f"🚀 Starting extended orchestrator for query: {user_query}")
        
        # Step 1-4: Run basic orchestration
        state = await data_summary_node(initial_state)
        state = await intent_identification_node(state)
        state = await task_decomposition_node(state)
        state = await execution_planning_node(state)
        
        print(f"📋 Got {len(state.decomposed_tasks)} tasks to execute dynamically")
        
        # Step 5: Create and run dynamic workflow
        if state.decomposed_tasks:
            dynamic_workflow = create_dynamic_workflow(state.decomposed_tasks)
            
            # Execute the dynamic workflow starting from task execution
            print("🔄 Executing dynamic workflow...")
            
            # Run dynamic task execution
            for task in state.decomposed_tasks:
                state = await execute_task_node(state, task)
            
            # Consolidate results
            state = await consolidate_results_node(state)
        
        print(f"✅ Extended orchestrator completed successfully!")
        return state
        
    except Exception as e:
        print(f"❌ Error in extended orchestrator: {e}")
        state = initial_state
        state.errors.append(f"Extended workflow error: {str(e)}")
        return state

# =====================================================
# STREAMING VERSION FOR EXTENDED ORCHESTRATOR
# =====================================================

async def run_extended_orchestrator_streaming(user_query: str):
    """Run the extended orchestrator with streaming updates"""
    
    initial_state = ExtendedOrchestratorState(
        user_query=user_query,
        available_data_summary="",
        identified_intent="",
        confidence_score=0.0,
        decomposed_tasks=[],
        execution_plan=[],
        current_step="Starting extended orchestration"
    )
    
    try:
        # Stream initial message
        yield {
            "type": "step",
            "step": "initialization",
            "message": f"🎯 Initializing extended orchestrator for: {user_query}",
            "progress": 0
        }
        
        # Basic orchestration steps (20% of progress)
        state = initial_state
        
        yield {"type": "step", "step": "data_summary", "message": "📊 Gathering available data sources...", "progress": 5}
        state = await data_summary_node(state)
        
        yield {"type": "step", "step": "intent_identification", "message": "🎯 Analyzing user intent with AI...", "progress": 10}
        state = await intent_identification_node(state)
        
        yield {"type": "step", "step": "task_decomposition", "message": "⚡ Breaking down query into executable tasks...", "progress": 15}
        state = await task_decomposition_node(state)
        
        yield {"type": "step", "step": "execution_planning", "message": "🗺️ Creating dynamic execution plan...", "progress": 20}
        state = await execution_planning_node(state)
        
        # Dynamic task execution (60% of progress)
        if state.decomposed_tasks:
            task_progress_step = 60 / len(state.decomposed_tasks)
            
            for i, task in enumerate(state.decomposed_tasks):
                progress = 20 + (i * task_progress_step)
                yield {
                    "type": "step",
                    "step": f"execute_task_{i}",
                    "message": f"🔄 Executing: {task.get('task_name', 'Unknown Task')}",
                    "progress": progress
                }
                
                state = await execute_task_node(state, task)
                
                yield {
                    "type": "step_complete", 
                    "step": f"execute_task_{i}",
                    "message": f"✅ Completed: {task.get('task_name', 'Unknown Task')}",
                    "progress": progress + task_progress_step
                }
        
        # Consolidation (20% of progress)
        yield {"type": "step", "step": "consolidation", "message": "🔗 Consolidating results from all tasks...", "progress": 85}
        state = await consolidate_results_node(state)
        
        yield {"type": "step_complete", "step": "consolidation", "message": "✅ Results consolidated successfully", "progress": 100}
        
        # Stream final results
        yield {
            "type": "result",
            "data": {
                "user_query": state.user_query,
                "identified_intent": state.identified_intent,
                "confidence_score": state.confidence_score,
                "decomposed_tasks": state.decomposed_tasks,
                "execution_plan": state.execution_plan,
                "task_results": state.task_results,
                "consolidated_analysis": state.consolidated_analysis,
                "final_recommendations": state.final_recommendations,
                "step_count": state.step_count,
                "errors": state.errors
            }
        }
        
    except Exception as e:
        yield {"type": "error", "message": f"❌ Error in extended orchestrator: {str(e)}"}

# =====================================================
# EXAMPLE USAGE
# =====================================================

# =====================================================
# EXAMPLE USAGE
# =====================================================

async def main():
    """Test the extended orchestrator with sample queries"""
    
    # Set OpenAI API key
    api_key = "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"
    os.environ["OPENAI_API_KEY"] = api_key
    
    # Test queries that will utilize different data sources
    test_queries = [
        "Give me a comprehensive overview of TechFlow Industries across all countries",
        "What are the high-risk opportunities and how should we mitigate them?",
        "Analyze TechFlow's credit utilization and recommend optimization strategies",
        "What meetings should I schedule with TechFlow and what should be the agenda?",
        "Provide a complete relationship health assessment for TechFlow"
    ]
    
    for query in test_queries:
        print(f"\n{'='*100}")
        print(f"TESTING EXTENDED ORCHESTRATOR: {query}")
        print(f"{'='*100}")
        
        try:
            # Run extended orchestrator
            result = await run_extended_orchestrator(query)
            
            # Print comprehensive results
            print_extended_orchestrator_results(result)
            
        except Exception as e:
            print(f"❌ Error testing query: {e}")
            import traceback
            traceback.print_exc()
        
        print("\n" + "="*100)
        
        # Wait between queries
        await asyncio.sleep(3)

def print_extended_orchestrator_results(state: ExtendedOrchestratorState):
    """Print detailed results from extended orchestrator"""
    
    print("\n" + "="*80)
    print("🎯 EXTENDED ORCHESTRATOR RESULTS")
    print("="*80)
    
    print(f"\n📝 USER QUERY:")
    print(f"   {state.user_query}")
    
    print(f"\n🎯 IDENTIFIED INTENT:")
    print(f"   Intent: {state.identified_intent}")
    print(f"   Confidence: {state.confidence_score}%")
    
    print(f"\n📋 DECOMPOSED TASKS ({len(state.decomposed_tasks)} tasks):")
    for i, task in enumerate(state.decomposed_tasks, 1):
        print(f"\n   Task {i}: {task['task_name']}")
        print(f"      ID: {task['task_id']}")
        print(f"      Type: {task['task_type']}")
        print(f"      Priority: {task['priority']}")
        print(f"      Data Sources: {', '.join(task['data_sources'])}")
        print(f"      Expected Output: {task['expected_output']}")
    
    print(f"\n🔄 TASK EXECUTION RESULTS:")
    for i, result in enumerate(state.task_results, 1):
        status = state.execution_status.get(result.get('task_id', ''), 'unknown')
        print(f"\n   Task {i}: {result['task_name']} - Status: {status}")
        print(f"      Data Gathered: {result['data_gathered']}")
        print(f"      Analyses: {len(result.get('analysis_results', []))}")
        print(f"      Recommendations: {len(result.get('recommendations', []))}")
        print(f"      Summary: {result.get('summary', 'No summary')[:200]}...")
    
    print(f"\n📊 CONSOLIDATED ANALYSIS:")
    for key, value in state.consolidated_analysis.items():
        print(f"   {key.replace('_', ' ').title()}: {value}")
    
    print(f"\n💡 FINAL RECOMMENDATIONS ({len(state.final_recommendations)}):")
    for i, rec in enumerate(state.final_recommendations, 1):
        print(f"\n   {i}. {rec.get('recommendation', 'No recommendation')}")
        print(f"      Priority: {rec.get('priority', 'unknown')}")
        print(f"      Category: {rec.get('category', 'unknown')}")
        print(f"      Rationale: {rec.get('rationale', 'No rationale')[:150]}...")
        print(f"      Expected Impact: {rec.get('expected_impact', 'No impact specified')}")
        print(f"      Timeline: {rec.get('timeline', 'No timeline')}")
    
    print(f"\n🗺️  EXECUTION PLAN:")
    for step in state.execution_plan:
        print(f"   {step}")
    
    if state.errors:
        print(f"\n❌ ERRORS:")
        for error in state.errors:
            print(f"   {error}")
    
    print(f"\n✅ COMPLETED IN {state.step_count} STEPS")
    print("="*80)

# =====================================================
# UTILITY FUNCTIONS
# =====================================================

def get_available_data_sources() -> Dict[str, DataSourceSchema]:
    """Get information about all available data sources"""
    return {source.value: schema for source, schema in DATA_SOURCE_SCHEMAS.items()}

def get_data_source_relationships() -> Dict[str, List[str]]:
    """Get relationship mapping between data sources"""
    relationships = {}
    for source, schema in DATA_SOURCE_SCHEMAS.items():
        relationships[source.value] = schema.relationships
    return relationships

async def test_data_access_tools():
    """Test all data access tools"""
    print("🧪 Testing Data Access Tools")
    print("="*50)
    
    for data_source in DataSource:
        tool = DATA_TOOLS[data_source]
        print(f"\n📊 Testing {data_source.value}:")
        
        try:
            # Test basic query
            data = await tool.query()
            print(f"   ✅ Query successful: {len(data)} records")
            
            # Test search
            search_results = await tool.search("TechFlow")
            print(f"   ✅ Search successful: {len(search_results)} results")
            
            # Test aggregation
            if data and len(data) > 0:
                first_record = data[0]
                group_field = None
                
                # Find a good field to group by
                for field in ["country", "account_name", "category", "status", "priority"]:
                    if field in first_record:
                        group_field = field
                        break
                
                if group_field:
                    agg_results = await tool.aggregate(group_field, ["amount"] if "amount" in first_record else [])
                    print(f"   ✅ Aggregation successful: {len(agg_results)} groups by {group_field}")
                else:
                    print(f"   ⚠️  No suitable grouping field found")
            
        except Exception as e:
            print(f"   ❌ Error testing {data_source.value}: {e}")

# =====================================================
# INTEGRATION WITH MAIN APPLICATION
# =====================================================

# Export the main functions for use in main.py
__all__ = [
    "run_extended_orchestrator",
    "run_extended_orchestrator_streaming", 
    "print_extended_orchestrator_results",
    "get_available_data_sources",
    "get_data_source_relationships",
    "test_data_access_tools",
    "ExtendedOrchestratorState",
    "DataSource",
    "DATA_SOURCE_SCHEMAS",
    "DATA_TOOLS"
]

if __name__ == "__main__":
    asyncio.run(main())