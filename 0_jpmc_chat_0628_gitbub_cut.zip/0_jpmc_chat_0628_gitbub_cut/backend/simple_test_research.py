from flask import Flask, request, jsonify, Response
from flask_cors import CORS
import json
import time
import threading
from queue import Queue

app = Flask(__name__)
CORS(app)

# Simple test without the actual BankerResearchTool first
progress_queue = Queue()

@app.route('/research-client', methods=['POST'])
def research_client():
    print("Received research request!")  # Debug print
    
    try:
        data = request.get_json()
        ticker_symbol = data.get('ticker_symbol', 'NVDA')
        print(f"Ticker symbol: {ticker_symbol}")
        
        def run_test_research():
            print("Starting test research...")
            steps = [
                "Initializing research tool...",
                "Fetching company news...",
                "Analyzing fundamentals...",
                "Processing financial statements...",
                "Identifying competitors...",
                "Generating final report..."
            ]
            
            for i, step in enumerate(steps):
                progress = int((i + 1) / len(steps) * 90)
                print(f"Step {i+1}: {step} ({progress}%)")
                
                progress_queue.put({
                    "type": "step",
                    "message": f"📊 {step}",
                    "progress": progress
                })
                time.sleep(2)  # Simulate work
            
            # Final result
            progress_queue.put({
                "type": "result", 
                "message": f"## 🏦 Test Banking Report for {ticker_symbol}\n\nThis is a test report to verify the integration is working correctly.\n\n### Analysis Complete\n- Connection: ✅ Working\n- Progress Updates: ✅ Working\n- Final Report: ✅ Working",
                "progress": 100
            })
            print("Test research completed!")
        
        # Start research in background
        research_thread = threading.Thread(target=run_test_research)
        research_thread.daemon = True
        research_thread.start()
        
        return jsonify({
            "status": "started",
            "message": "Test research process initiated"
        })
        
    except Exception as e:
        print(f"Error: {e}")
        return jsonify({
            "status": "error", 
            "message": str(e)
        }), 500

@app.route('/research-stream', methods=['GET'])
def research_stream():
    print("Stream endpoint called!")
    
    def generate():
        print("Starting event stream...")
        while True:
            try:
                if not progress_queue.empty():
                    progress_data = progress_queue.get_nowait()
                    print(f"Sending: {progress_data}")
                    yield f"data: {json.dumps(progress_data)}\n\n"
                    
                    if progress_data.get("type") in ["result", "error"]:
                        print("Research complete, ending stream")
                        break
                else:
                    # Send keepalive
                    yield f"data: {json.dumps({'type': 'keepalive'})}\n\n"
                
                time.sleep(1)
                
            except Exception as e:
                print(f"Stream error: {e}")
                yield f"data: {json.dumps({'type': 'error', 'message': str(e)})}\n\n"
                break
    
    return Response(
        generate(),
        mimetype='text/event-stream',
        headers={
            'Cache-Control': 'no-cache',
            'Connection': 'keep-alive',
            'Access-Control-Allow-Origin': '*'
        }
    )

@app.route('/health', methods=['GET'])
def health():
    return jsonify({"status": "healthy"})

if __name__ == '__main__':
    print("Starting test server on http://localhost:8000")
    app.run(debug=True, host='0.0.0.0', port=8000, threaded=True)