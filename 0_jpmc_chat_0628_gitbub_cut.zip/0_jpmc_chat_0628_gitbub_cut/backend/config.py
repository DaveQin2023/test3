"""
Configuration settings for Banking Orchestrator System
Centralizes all configuration parameters for easy management
"""

import os
from typing import Dict, List
from dataclasses import dataclass, field
from enum import Enum

# =====================================================
# ENVIRONMENT CONFIGURATION
# =====================================================

class Environment(Enum):
    DEVELOPMENT = "development"
    STAGING = "staging"
    PRODUCTION = "production"

# Get environment from env variable, default to development
ENVIRONMENT = Environment(os.getenv("ENVIRONMENT", "development"))

# =====================================================
# API CONFIGURATION
# =====================================================

@dataclass
class APIConfig:
    """API and service configuration"""
    
    # OpenAI Configuration
    OPENAI_API_KEY: str = os.getenv("OPENAI_API_KEY", "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")
    OPENAI_MODEL: str = os.getenv("OPENAI_MODEL", "gpt-4o")
    OPENAI_TEMPERATURE: float = float(os.getenv("OPENAI_TEMPERATURE", "0.3"))
    OPENAI_MAX_TOKENS: int = int(os.getenv("OPENAI_MAX_TOKENS", "1500"))
    
    # FastAPI Configuration
    FASTAPI_HOST: str = os.getenv("FASTAPI_HOST", "0.0.0.0")
    FASTAPI_PORT: int = int(os.getenv("FASTAPI_PORT", "8000"))
    FASTAPI_RELOAD: bool = os.getenv("FASTAPI_RELOAD", "True").lower() == "true"
    
    # CORS Configuration
    CORS_ORIGINS: List[str] = field(default_factory=lambda: [
        "http://localhost:3000",
        "http://localhost:5173", 
        "http://localhost:5174",
        "http://127.0.0.1:3000",
        "http://127.0.0.1:5173",
        "http://127.0.0.1:5174"
    ])
    
    # Rate Limiting
    RATE_LIMIT_REQUESTS: int = int(os.getenv("RATE_LIMIT_REQUESTS", "100"))
    RATE_LIMIT_WINDOW: int = int(os.getenv("RATE_LIMIT_WINDOW", "3600"))  # 1 hour
    
    # Request Timeout
    REQUEST_TIMEOUT: int = int(os.getenv("REQUEST_TIMEOUT", "30"))  # seconds

# =====================================================
# BANKING DATA CONFIGURATION
# =====================================================

@dataclass
class BankingConfig:
    """Banking-specific configuration parameters"""
    
    # Risk Rating Thresholds
    HIGH_RISK_THRESHOLD: float = 3.0  # PD above this is high risk
    MEDIUM_RISK_THRESHOLD: float = 1.5  # PD between medium and high
    
    # Utilization Rate Alerts
    HIGH_UTILIZATION_THRESHOLD: float = 80.0  # % utilization
    MEDIUM_UTILIZATION_THRESHOLD: float = 60.0
    
    # Exposure Limits (in millions)
    SINGLE_CLIENT_EXPOSURE_LIMIT: float = 10.0
    PORTFOLIO_EXPOSURE_LIMIT: float = 100.0
    
    # Product Categories
    LENDING_PRODUCTS: List[str] = field(default_factory=lambda: [
        "Revolving Credit Line",
        "Term Loan", 
        "Equipment Financing",
        "Real Estate Loan"
    ])
    
    TREASURY_PRODUCTS: List[str] = field(default_factory=lambda: [
        "Treasury Management Suite",
        "Cash Management",
        "FX Services",
        "Liquidity Management"
    ])
    
    CAPITAL_MARKETS_PRODUCTS: List[str] = field(default_factory=lambda: [
        "ESG Bond Financing",
        "Corporate Bonds",
        "Syndicated Loans",
        "Structured Finance"
    ])
    
    TRADE_PRODUCTS: List[str] = field(default_factory=lambda: [
        "Trade Finance Solutions",
        "Letters of Credit",
        "Trade Documentation",
        "Supply Chain Finance"
    ])
    
    # Meeting Types and Priorities
    HIGH_PRIORITY_MEETINGS: List[str] = field(default_factory=lambda: [
        "Credit Review",
        "Risk Assessment", 
        "Covenant Breach Discussion",
        "Restructuring Meeting"
    ])
    
    MEDIUM_PRIORITY_MEETINGS: List[str] = field(default_factory=lambda: [
        "Business Review",
        "Product Presentation",
        "Opportunity Discussion"
    ])
    
    LOW_PRIORITY_MEETINGS: List[str] = field(default_factory=lambda: [
        "Quarterly Check-in",
        "Relationship Maintenance",
        "Market Update"
    ])

# =====================================================
# ORCHESTRATOR CONFIGURATION
# =====================================================

@dataclass
class OrchestratorConfig:
    """LangGraph orchestrator configuration"""
    
    # Agent Configuration
    MAX_AGENT_ITERATIONS: int = 10
    AGENT_TIMEOUT: int = 60  # seconds per agent
    
    # Data Processing
    MAX_ENTITIES_PER_QUERY: int = 10
    MAX_RECOMMENDATIONS: int = 5
    MAX_INSIGHTS: int = 6
    MAX_MEETING_SUGGESTIONS: int = 4
    
    # Intent Classification Confidence Thresholds
    HIGH_CONFIDENCE_THRESHOLD: float = 0.8
    MEDIUM_CONFIDENCE_THRESHOLD: float = 0.6
    
    # Response Formatting
    INCLUDE_CONFIDENCE_SCORES: bool = True
    INCLUDE_PROCESSING_TIME: bool = True
    INCLUDE_DATA_SOURCES: bool = True
    
    # Caching Configuration
    ENABLE_CACHING: bool = True
    CACHE_TTL: int = 3600  # 1 hour
    
    # Parallel Processing
    ENABLE_PARALLEL_AGENTS: bool = True
    MAX_CONCURRENT_AGENTS: int = 4

# =====================================================
# LOGGING CONFIGURATION
# =====================================================

@dataclass 
class LoggingConfig:
    """Logging configuration"""
    
    LOG_LEVEL: str = os.getenv("LOG_LEVEL", "INFO")
    LOG_FORMAT: str = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    LOG_FILE: str = os.getenv("LOG_FILE", "banking_orchestrator.log")
    
    # Structured logging for production
    STRUCTURED_LOGGING: bool = ENVIRONMENT == Environment.PRODUCTION
    
    # Log retention
    LOG_ROTATION_SIZE: str = "10MB"
    LOG_BACKUP_COUNT: int = 5
    
    # What to log
    LOG_USER_QUERIES: bool = True
    LOG_AGENT_RESPONSES: bool = True
    LOG_PERFORMANCE_METRICS: bool = True
    LOG_ERROR_DETAILS: bool = True

# =====================================================
# DATABASE CONFIGURATION (for future real data sources)
# =====================================================

@dataclass
class DatabaseConfig:
    """Database configuration for future integration"""
    
    # Salesforce API
    SALESFORCE_USERNAME: str = os.getenv("SALESFORCE_USERNAME", "")
    SALESFORCE_PASSWORD: str = os.getenv("SALESFORCE_PASSWORD", "")
    SALESFORCE_SECURITY_TOKEN: str = os.getenv("SALESFORCE_SECURITY_TOKEN", "")
    SALESFORCE_DOMAIN: str = os.getenv("SALESFORCE_DOMAIN", "login")
    
    # Core Banking System
    CORE_BANKING_HOST: str = os.getenv("CORE_BANKING_HOST", "")
    CORE_BANKING_PORT: int = int(os.getenv("CORE_BANKING_PORT", "1433"))
    CORE_BANKING_DATABASE: str = os.getenv("CORE_BANKING_DATABASE", "")
    CORE_BANKING_USERNAME: str = os.getenv("CORE_BANKING_USERNAME", "")
    CORE_BANKING_PASSWORD: str = os.getenv("CORE_BANKING_PASSWORD", "")
    
    # Email System
    EMAIL_HOST: str = os.getenv("EMAIL_HOST", "")
    EMAIL_PORT: int = int(os.getenv("EMAIL_PORT", "993"))
    EMAIL_USERNAME: str = os.getenv("EMAIL_USERNAME", "")
    EMAIL_PASSWORD: str = os.getenv("EMAIL_PASSWORD", "")
    
    # Connection Pooling
    DB_POOL_SIZE: int = int(os.getenv("DB_POOL_SIZE", "10"))
    DB_POOL_TIMEOUT: int = int(os.getenv("DB_POOL_TIMEOUT", "30"))

# =====================================================
# SECURITY CONFIGURATION
# =====================================================

@dataclass
class SecurityConfig:
    """Security and authentication configuration"""
    
    # JWT Configuration
    JWT_SECRET_KEY: str = os.getenv("JWT_SECRET_KEY", "your-secret-key-change-in-production")
    JWT_ALGORITHM: str = "HS256"
    JWT_EXPIRATION_HOURS: int = int(os.getenv("JWT_EXPIRATION_HOURS", "24"))
    
    # API Key Authentication
    API_KEY_HEADER: str = "X-API-Key"
    VALID_API_KEYS: List[str] = field(default_factory=lambda: os.getenv("VALID_API_KEYS", "").split(",") if os.getenv("VALID_API_KEYS") else [])
    
    # Encryption
    ENCRYPTION_KEY: str = os.getenv("ENCRYPTION_KEY", "")
    
    # Data Privacy
    MASK_SENSITIVE_DATA: bool = True
    SENSITIVE_FIELDS: List[str] = field(default_factory=lambda: [
        "ssn", "tax_id", "account_number", 
        "routing_number", "credit_card"
    ])
    
    # Audit Configuration
    ENABLE_AUDIT_LOGGING: bool = True
    AUDIT_RETENTION_DAYS: int = 90

# =====================================================
# PERFORMANCE CONFIGURATION
# =====================================================

@dataclass
class PerformanceConfig:
    """Performance monitoring and optimization"""
    
    # Response Time Targets (in seconds)
    TARGET_RESPONSE_TIME: float = 5.0
    WARNING_RESPONSE_TIME: float = 10.0
    CRITICAL_RESPONSE_TIME: float = 30.0
    
    # Memory Management
    MAX_MEMORY_USAGE_MB: int = 1024
    GARBAGE_COLLECTION_THRESHOLD: int = 100  # requests
    
    # Concurrent Processing
    MAX_CONCURRENT_REQUESTS: int = 20
    QUEUE_SIZE_LIMIT: int = 100
    
    # Metrics Collection
    ENABLE_METRICS: bool = True
    METRICS_RETENTION_DAYS: int = 30
    
    # Health Checks
    HEALTH_CHECK_INTERVAL: int = 60  # seconds
    HEALTH_CHECK_TIMEOUT: int = 5  # seconds

# =====================================================
# GLOBAL CONFIGURATION INSTANCE
# =====================================================

# Create configuration instances based on environment
if ENVIRONMENT == Environment.PRODUCTION:
    # Production settings - more restrictive
    API_CONFIG = APIConfig(
        OPENAI_TEMPERATURE=0.1,  # More deterministic
        FASTAPI_RELOAD=False,
        REQUEST_TIMEOUT=60
    )
    ORCHESTRATOR_CONFIG = OrchestratorConfig(
        ENABLE_CACHING=True,
        INCLUDE_CONFIDENCE_SCORES=False,  # Less verbose
        MAX_CONCURRENT_AGENTS=6
    )
    LOGGING_CONFIG = LoggingConfig(
        LOG_LEVEL="WARNING",
        STRUCTURED_LOGGING=True
    )
    PERFORMANCE_CONFIG = PerformanceConfig(
        TARGET_RESPONSE_TIME=3.0,
        MAX_CONCURRENT_REQUESTS=50
    )
elif ENVIRONMENT == Environment.STAGING:
    # Staging settings - balanced
    API_CONFIG = APIConfig(
        OPENAI_TEMPERATURE=0.2,
        FASTAPI_RELOAD=False
    )
    ORCHESTRATOR_CONFIG = OrchestratorConfig(
        ENABLE_CACHING=True,
        INCLUDE_CONFIDENCE_SCORES=True
    )
    LOGGING_CONFIG = LoggingConfig(
        LOG_LEVEL="INFO"
    )
    PERFORMANCE_CONFIG = PerformanceConfig()
else:
    # Development settings - more verbose and flexible
    API_CONFIG = APIConfig(
        OPENAI_TEMPERATURE=0.3,
        FASTAPI_RELOAD=True
    )
    ORCHESTRATOR_CONFIG = OrchestratorConfig(
        ENABLE_CACHING=False,  # Easier debugging
        INCLUDE_CONFIDENCE_SCORES=True,
        INCLUDE_PROCESSING_TIME=True
    )
    LOGGING_CONFIG = LoggingConfig(
        LOG_LEVEL="DEBUG"
    )
    PERFORMANCE_CONFIG = PerformanceConfig(
        TARGET_RESPONSE_TIME=10.0  # More lenient for dev
    )

# Common configurations
BANKING_CONFIG = BankingConfig()
DATABASE_CONFIG = DatabaseConfig()
SECURITY_CONFIG = SecurityConfig()

# =====================================================
# CONFIGURATION VALIDATION
# =====================================================

def validate_config():
    """Validate configuration settings"""
    errors = []
    
    # Check required API keys
    if not API_CONFIG.OPENAI_API_KEY:
        errors.append("OPENAI_API_KEY is required")
    
    # Check security settings in production
    if ENVIRONMENT == Environment.PRODUCTION:
        if SECURITY_CONFIG.JWT_SECRET_KEY == "your-secret-key-change-in-production":
            errors.append("JWT_SECRET_KEY must be changed in production")
        
        if not SECURITY_CONFIG.ENCRYPTION_KEY:
            errors.append("ENCRYPTION_KEY is required in production")
    
    # Check database settings if not using mock data
    # (Add validation logic here when integrating real data sources)
    
    if errors:
        raise ValueError(f"Configuration validation failed: {', '.join(errors)}")
    
    return True

# =====================================================
# CONFIGURATION HELPER FUNCTIONS
# =====================================================

def get_config_summary() -> Dict:
    """Get a summary of current configuration (for debugging)"""
    return {
        "environment": ENVIRONMENT.value,
        "api_model": API_CONFIG.OPENAI_MODEL,
        "fastapi_port": API_CONFIG.FASTAPI_PORT,
        "caching_enabled": ORCHESTRATOR_CONFIG.ENABLE_CACHING,
        "log_level": LOGGING_CONFIG.LOG_LEVEL,
        "max_concurrent_agents": ORCHESTRATOR_CONFIG.MAX_CONCURRENT_AGENTS
    }

def is_development() -> bool:
    """Check if running in development mode"""
    return ENVIRONMENT == Environment.DEVELOPMENT

def is_production() -> bool:
    """Check if running in production mode"""
    return ENVIRONMENT == Environment.PRODUCTION

# =====================================================
# EXPORT MAIN CONFIGS
# =====================================================

__all__ = [
    "API_CONFIG",
    "BANKING_CONFIG", 
    "ORCHESTRATOR_CONFIG",
    "LOGGING_CONFIG",
    "DATABASE_CONFIG",
    "SECURITY_CONFIG",
    "PERFORMANCE_CONFIG",
    "ENVIRONMENT",
    "validate_config",
    "get_config_summary",
    "is_development",
    "is_production"
]