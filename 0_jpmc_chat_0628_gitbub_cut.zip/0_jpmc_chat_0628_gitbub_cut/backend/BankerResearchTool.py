import os
import textwrap
import pandas as pd
from datetime import datetime
from openai import OpenAI
from gnews import GNews
import yfinance as yf


openai_api_key='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'
tavily_api_key='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'
anthropic_api_key='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'


class BankerResearchTool:
    def __init__(self, openai_api_key, tavily_api_key=None, anthropic_api_key=None):
        """
        Initialize the Banker Research Tool
        
        Args:
            openai_api_key (str): OpenAI API key
            tavily_api_key (str, optional): Tavily API key for web search
            anthropic_api_key (str, optional): Anthropic API key
        """
        # Set environment variables
        os.environ['OPENAI_API_KEY'] = openai_api_key
        if tavily_api_key:
            os.environ['TAVILY_API_KEY'] = tavily_api_key
        if anthropic_api_key:
            os.environ['ANTHROPIC_API_KEY'] = anthropic_api_key
        
        # Initialize OpenAI client
        self.client = OpenAI(api_key=openai_api_key)
    
    def format_text(self, text):
        """Clean up and format text"""
        text = text.strip("'")
        wrapper = textwrap.TextWrapper(width=80, subsequent_indent='    ')
        formatted_text = "\n".join([wrapper.fill(line.strip()) for line in text.splitlines()])
        return formatted_text
    
    def llm_summarize(self, context):
        """
        Summarize context with 4 bullet points:
        - Positive Highlights
        - Concerns and Challenges
        - Sentiments
        - Key Takeaways for Investors
        """
        prompt = f"""
        You are a financial research assistant. Please summarize the context {context} with the following 4 bulletpoints:
        . Positive Highlights
        . Concerns and Challenges
        . Sentiments
        . Key Takeaways for Investors.
        """
        
        response = self.client.chat.completions.create(
            model="gpt-4o",
            messages=[
                {"role": "system", "content": "You are a financial research assistant."},
                {"role": "user", "content": prompt}
            ],
            max_tokens=1000,
            temperature=0.1,
        )
        
        result = response.choices[0].message.content
        formatted_result = self.format_text(result)
        return formatted_result.replace('**', '')
    
    def llm_summarize_finance(self, context):
        """Simple financial summarization"""
        prompt = f"""
        You are a financial research assistant. Please summarize {context}
        """
        
        response = self.client.chat.completions.create(
            model="gpt-4o",
            messages=[
                {"role": "system", "content": "You are a financial research assistant."},
                {"role": "user", "content": prompt}
            ],
            max_tokens=1000,
            temperature=0.1,
        )
        
        result = response.choices[0].message.content
        formatted_result = self.format_text(result)
        return formatted_result.replace('**', '')
    
    def llm_top_competitors(self, company):
        """Find top 3 competitors for a company"""
        prompt = f"""
        You are a financial research assistant. Please find out the top 3 competitors for {company} 
        and return me just a list competitor1,competitor2,competitor3, nothing else.
        """
        
        response = self.client.chat.completions.create(
            model="gpt-4o",
            messages=[
                {"role": "system", "content": "You are a financial research assistant."},
                {"role": "user", "content": prompt}
            ],
            max_tokens=1000,
            temperature=0.1,
        )
        
        result = response.choices[0].message.content
        formatted_result = self.format_text(result)
        return formatted_result.replace('**', '')
    
    def google_news_llm_summary(self, query):
        """Fetch Google news and create LLM summary"""
        try:
            google_news = GNews()
            news = google_news.get_news(query)
            
            title_list = []
            for article in news:
                title = article.get("title")
                publication_date_string = article.get("published date")
                if publication_date_string:
                    try:
                        publication_date = datetime.strptime(publication_date_string, "%a, %d %b %Y %H:%M:%S %Z")
                        title_list.append([publication_date, title])
                    except ValueError:
                        # Handle different date formats or skip if parsing fails
                        title_list.append([datetime.now(), title])
                else:
                    title_list.append([datetime.now(), title])
            
            if not title_list:
                return f"No news found for {query}"
            
            title_list_df = pd.DataFrame(title_list, columns=['publish_date', 'title'])
            title_list_df = title_list_df.sort_values(by='publish_date', ascending=False)
            
            # Get top titles
            top_titles = title_list_df.head(50)['title'].str.cat(sep=' | ')
            
            # Get LLM summary from top titles
            summary = self.llm_summarize(top_titles)
            return summary
            
        except Exception as e:
            return f"Error fetching news for {query}: {str(e)}"
    
    def get_company_fundamentals(self, ticker_symbol):
        """Get basic company information using yfinance"""
        try:
            ticker = yf.Ticker(ticker_symbol)
            info = ticker.info
            
            fundamentals = {
                "Company Name": info.get("longName"),
                "Sector": info.get("sector"),
                "Industry": info.get("industry"),
                "Market Cap": info.get("marketCap"),
                "Trailing PE": info.get("trailingPE"),
                "Forward PE": info.get("forwardPE"),
                "Price-to-Book": info.get("priceToBook"),
                "Beta": info.get("beta"),
                "Dividend Yield": info.get("dividendYield"),
                "52-Week Low": info.get("fiftyTwoWeekLow"),
                "52-Week High": info.get("fiftyTwoWeekHigh"),
                "Revenue Growth": info.get("revenueGrowth"),
                "Earnings Growth": info.get("earningsGrowth")
            }
            
            return fundamentals
            
        except Exception as e:
            return f"Error fetching fundamentals for {ticker_symbol}: {str(e)}"
    
    def get_financial_statements(self, ticker_symbol):
        """Get financial statements (income, balance sheet, cash flow)"""
        try:
            ticker = yf.Ticker(ticker_symbol)
            
            statements = {
                "quarterly_income": ticker.quarterly_financials,
                "quarterly_balance": ticker.quarterly_balance_sheet,
                "quarterly_cashflow": ticker.quarterly_cashflow,
                "annual_income": ticker.financials,
                "annual_balance": ticker.balance_sheet,
                "annual_cashflow": ticker.cashflow
            }
            
            return statements
            
        except Exception as e:
            return f"Error fetching financial statements for {ticker_symbol}: {str(e)}"
    
    def analyze_competitors(self, company):
        """Analyze top competitors for a company"""
        try:
            # Get top 3 competitors
            competitors_str = self.llm_top_competitors(company)
            competitors_list = [comp.strip() for comp in competitors_str.split(',')]
            
            competitor_summaries = {}
            
            for competitor in competitors_list:
                print(f"Analyzing competitor: {competitor}")
                competitor_summary = self.google_news_llm_summary(competitor)
                competitor_summaries[competitor] = competitor_summary
            
            return competitor_summaries
            
        except Exception as e:
            return f"Error analyzing competitors for {company}: {str(e)}"
    
    def generate_financial_report(self, ticker_symbol):
        """
        Generate comprehensive financial report for a given ticker
        
        Args:
            ticker_symbol (str): Stock ticker symbol (e.g., 'NVDA', 'AAPL')
        
        Returns:
            str: Comprehensive financial report
        """
        print(f"Generating financial report for {ticker_symbol}...")
        
        # 1. Get company news summary
        print("Fetching company news...")
        company_news_summary = self.google_news_llm_summary(ticker_symbol)
        
        # 2. Get sector/industry news
        fundamentals = self.get_company_fundamentals(ticker_symbol)
        if isinstance(fundamentals, dict) and fundamentals.get("Industry"):
            print(f"Fetching industry news for {fundamentals['Industry']}...")
            industry_summary = self.google_news_llm_summary(fundamentals["Industry"])
        else:
            industry_summary = "Industry information not available"
        
        # 3. Get financial statements and analyze
        print("Analyzing financial statements...")
        statements = self.get_financial_statements(ticker_symbol)
        
        if isinstance(statements, dict):
            quarterly_income_summary = self.llm_summarize_finance(statements["quarterly_income"])
            quarterly_balance_summary = self.llm_summarize_finance(statements["quarterly_balance"])
            quarterly_cashflow_summary = self.llm_summarize_finance(statements["quarterly_cashflow"])
        else:
            quarterly_income_summary = "Financial statements not available"
            quarterly_balance_summary = "Balance sheet not available"
            quarterly_cashflow_summary = "Cash flow statement not available"
        
        # 4. Analyze competitors
        print("Analyzing competitors...")
        competitor_summaries = self.analyze_competitors(ticker_symbol)
        
        # 5. Generate comprehensive report
        print("Generating final report...")
        
        # Prepare competitor summaries for the prompt
        competitor_text = ""
        if isinstance(competitor_summaries, dict):
            for comp, summary in competitor_summaries.items():
                competitor_text += f"{comp} news summary: {summary}\n"
        
        prompt = f"""
        You are a financial research expert. Please create a comprehensive financial report for {ticker_symbol} based on the following information:
        
        Company News Summary: {company_news_summary}
        
        Industry News Summary: {industry_summary}
        
        Quarterly Income Statement Summary: {quarterly_income_summary}
        
        Quarterly Balance Sheet Summary: {quarterly_balance_summary}
        
        Quarterly Cash Flow Summary: {quarterly_cashflow_summary}
        
        Competitor Analysis:
        {competitor_text}
        
        Please structure the report with clear sections and provide actionable insights for investors.
        """
        
        response = self.client.chat.completions.create(
            model="gpt-4o",
            messages=[
                {"role": "system", "content": "You are a financial research expert."},
                {"role": "user", "content": prompt}
            ],
            max_tokens=2000,
            temperature=0.1,
        )
        
        result = response.choices[0].message.content
        formatted_result = self.format_text(result)
        final_report = formatted_result.replace('**', '')
        
        return final_report

# Example usage
def main():
    """Example usage of the BankerResearchTool"""
    
    # Initialize the tool (you need to provide your API keys)
    #
    
    try:
        tool = BankerResearchTool(openai_api_key=openai_api_key)
        # Generate report for a company
        ticker = "NVDA"  # You can change this to any ticker symbol
        report = tool.generate_financial_report(ticker)
        
        print(f"\n{'='*80}")
        print(f"FINANCIAL REPORT FOR {ticker}")
        print(f"{'='*80}")
        print(report)
        
        # You can also use individual methods
        print("\n" + "="*50)
        print("COMPANY FUNDAMENTALS")
        print("="*50)
        fundamentals = tool.get_company_fundamentals(ticker)
        for key, value in fundamentals.items():
            print(f"{key}: {value}")
    
    except Exception as e:
        print(f"Error: {e}")
        print("Please make sure to:")
        print("1. Install required packages: pip install openai gnews pandas yfinance")
        print("2. Set your OpenAI API key")

if __name__ == "__main__":
    main()