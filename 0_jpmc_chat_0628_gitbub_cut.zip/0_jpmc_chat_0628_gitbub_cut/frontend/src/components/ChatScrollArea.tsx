import { useEffect, useRef, useState } from 'react';
import { Copy, Check, Play, Square } from 'lucide-react';

const ChatScrollArea = () => {
  const [messages, setMessages] = useState<string[]>([]);
  const [orchestratorLogs, setOrchestratorLogs] = useState<string[]>([]);
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);
  const [isStreaming, setIsStreaming] = useState(false);
  const [streamingProgress, setStreamingProgress] = useState(0);
  const [isSimulatingLogs, setIsSimulatingLogs] = useState(false);
  const bottomRef = useRef<HTMLDivElement | null>(null);
  const logBottomRef = useRef<HTMLDivElement | null>(null);
  const eventSourceRef = useRef<EventSource | null>(null);

  // Load initial messages from localStorage
  useEffect(() => {
    const saved = localStorage.getItem("chat_history");
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        setMessages(Array.isArray(parsed) ? parsed : []);
      } catch (error) {
        console.error('Error parsing chat history:', error);
        setMessages([]);
      }
    }
  }, []);

  const clearOrchestratorLogs = () => {
    setOrchestratorLogs([]);
  };

  // Listen for new messages and orchestrator logs
  useEffect(() => {
    const handleNewMessage = (e: CustomEvent) => {
      const newMessages = e.detail as string[];
      setMessages(prev => {
        const updated = [...prev, ...newMessages];
        return updated;
      });
      
      // Check for orchestrator messages and start real-time logging
      newMessages.forEach(msg => {
        if (msg.includes('ORCHESTRATOR_LOG:') && msg.includes('ORCHESTRATOR_RESULT:')) {
          // Only start simulation if not already running
          if (!isSimulatingLogs) {
            startRealtimeLogging();
          }
        } 
        // Fallback for orchestrator messages without markers
        else if (isOrchestratorMessage(msg) && !isSimulatingLogs) {
          startRealtimeLogging();
        }
      });
    };

    const handleOrchestratorLog = (e: CustomEvent) => {
      const logEntry = e.detail as string;
      setOrchestratorLogs(prev => [...prev, logEntry]);
    };

    const handleClearChat = () => {
      setMessages([]);
      console.log("Cleared conversation messages");
    };

    window.addEventListener("new_chat", handleNewMessage as EventListener);
    window.addEventListener("orchestrator_log", handleOrchestratorLog as EventListener);
    window.addEventListener("clear_chat", handleClearChat as EventListener);
    
    return () => {
      window.removeEventListener("new_chat", handleNewMessage as EventListener);
      window.removeEventListener("orchestrator_log", handleOrchestratorLog as EventListener);
      window.removeEventListener("clear_chat", handleClearChat as EventListener);
    };
  }, []);

  // Auto-scroll to BOTTOM for new messages (traditional chat)
  useEffect(() => {
    if (messages.length > 0) {
      setTimeout(() => {
        bottomRef.current?.scrollIntoView({ 
          behavior: "smooth", 
          block: "end" // This positions new messages at the bottom
        });
      }, 100);
    }
  }, [messages]);

  // Auto-scroll orchestrator logs to bottom
  useEffect(() => {
    if (orchestratorLogs.length > 0) {
      setTimeout(() => {
        logBottomRef.current?.scrollIntoView({ behavior: "smooth" });
      }, 100);
    }
  }, [orchestratorLogs]);

  const clearChat = () => {
    localStorage.removeItem("chat_history");
    setMessages([]);
  };

  const simulateRealtimeLogs = (tasks: string[], taskCount: number = 5) => {
    // Prevent multiple simulations from running simultaneously
    if (isSimulatingLogs) {
      return;
    }
    
    setIsSimulatingLogs(true);
    const timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    
    // Clear existing logs and start fresh
    setOrchestratorLogs([]);
    
    // Add initial message immediately
    setTimeout(() => {
      setOrchestratorLogs(prev => [...prev, `[${timestamp}] 📋 Got ${taskCount} tasks to execute dynamically`]);
    }, 100);
    
    // Add workflow start message
    setTimeout(() => {
      setOrchestratorLogs(prev => [...prev, `[${timestamp}] 🔄 Executing dynamic workflow...`]);
    }, 500);
    
    // Add each task execution with delays
    tasks.forEach((task, index) => {
      setTimeout(() => {
        setOrchestratorLogs(prev => [...prev, `[${timestamp}] 🔄 Executing task: ${task}`]);
      }, 1000 + (index * 800)); // 800ms between each task
    });
    
    // Add completion message
    setTimeout(() => {
      setOrchestratorLogs(prev => [...prev, `[${timestamp}] ✅ Completed ${taskCount}/${taskCount} tasks successfully`]);
    }, 1000 + (tasks.length * 800) + 500);
    
    // Add final completion and reset flag
    setTimeout(() => {
      setOrchestratorLogs(prev => [...prev, `[${timestamp}] 🏁 Extended orchestrator workflow completed`]);
      setIsSimulatingLogs(false); // Reset flag when simulation completes
    }, 1000 + (tasks.length * 800) + 1000);
  };

  const startRealtimeLogging = () => {
    // Don't start if already simulating
    if (isSimulatingLogs) {
      return;
    }
    
    const sampleTasks = [
      "Gather Account Summaries and Basic Info",
      "Collect Recent Interactions and Emails", 
      "Review Current Products and Services",
      "Check Outstanding Tasks and Opportunities",
      "Analyze Credit Exposure and Utilization"
    ];
    
    simulateRealtimeLogs(sampleTasks, 5);
  };

  const addOrchestratorLog = (message: string, type: string = 'info') => {
    const timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    const logEntry = `[${timestamp}] ${message}`;
    setOrchestratorLogs(prev => [...prev, logEntry]);
  };

  const startStreamingOrchestrator = async (query: string) => {
    if (isStreaming) return;
    
    setIsStreaming(true);
    setStreamingProgress(0);
    addOrchestratorLog("🚀 Starting streaming orchestrator...", "start");
    
    try {
      // Make a POST request to the streaming endpoint
      const response = await fetch('http://localhost:8000/chat-streaming', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ message: query })
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const reader = response.body?.getReader();
      if (!reader) {
        throw new Error('Failed to get response reader');
      }

      const decoder = new TextDecoder();
      let buffer = '';

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() || ''; // Keep incomplete line in buffer

        for (const line of lines) {
          if (line.startsWith('data: ')) {
            try {
              const data = JSON.parse(line.slice(6));
              handleStreamingUpdate(data);
            } catch (e) {
              console.error('Error parsing streaming data:', e);
            }
          }
        }
      }

    } catch (error) {
      console.error('Streaming error:', error);
      addOrchestratorLog(`❌ Streaming error: ${error}`, "error");
    } finally {
      setIsStreaming(false);
      setStreamingProgress(0);
    }
  };

  const handleStreamingUpdate = (data: any) => {
    switch (data.type) {
      case 'status':
      case 'step':
        addOrchestratorLog(data.message, "step");
        if (data.progress) {
          setStreamingProgress(data.progress);
        }
        break;
      case 'step_complete':
        addOrchestratorLog(data.message, "complete");
        if (data.progress) {
          setStreamingProgress(data.progress);
        }
        break;
      case 'result':
        addOrchestratorLog("📋 Final result received", "result");
        // You could also update the main chat with the result here
        break;
      case 'complete':
        addOrchestratorLog(data.message, "complete");
        break;
      case 'error':
        addOrchestratorLog(data.message, "error");
        break;
    }
  };

  const stopStreaming = () => {
    if (eventSourceRef.current) {
      eventSourceRef.current.close();
      eventSourceRef.current = null;
    }
    setIsStreaming(false);
    setStreamingProgress(0);
    addOrchestratorLog("⏹️ Streaming stopped by user", "stop");
  };

  const copyMessage = async (message: string, index: number) => {
    try {
      await navigator.clipboard.writeText(formatMessage(message));
      setCopiedIndex(index);
      setTimeout(() => setCopiedIndex(null), 2000); // Reset after 2 seconds
    } catch (error) {
      console.error('Failed to copy message:', error);
    }
  };

  const isOrchestratorMessage = (msg: string) => {
    const cleanMsg = msg.replace(/^(You: |AI: )/, "");
    return cleanMsg.includes('🏦 Banking Intelligence Report') || 
           cleanMsg.includes('DECOMPOSED TASKS') ||
           cleanMsg.includes('EXECUTION PLAN') ||
           cleanMsg.includes('orchestrator_used') ||
           cleanMsg.includes('📋 Task ID:') ||
           cleanMsg.includes('🎯 Executing plan') ||
           cleanMsg.includes('CONSOLIDATED ANALYSIS');
  };

  // New function to extract only the detailed consolidated analysis sections
  const extractConsolidatedAnalysis = (msg: string) => {
    const cleanMsg = msg.replace(/^(You: |AI: )/, "");
    
    // Check if this is an orchestrator message
    if (!isOrchestratorMessage(cleanMsg)) {
      return cleanMsg; // Return as-is if not an orchestrator message
    }

    let result = '';
    
    // Extract Query Analysis section
    const queryStart = cleanMsg.indexOf('## 📝 Query Analysis');
    if (queryStart !== -1) {
      const queryEnd = cleanMsg.indexOf('## 📋 DECOMPOSED TASKS', queryStart);
      if (queryEnd !== -1) {
        const querySection = cleanMsg.substring(queryStart, queryEnd).trim();
        result += querySection + '\n\n';
      }
    }

    // Extract Task Execution Results section if available
    const executionStart = cleanMsg.indexOf('## 🔄 TASK EXECUTION RESULTS:');
    if (executionStart !== -1) {
      const executionEnd = cleanMsg.indexOf('## 📊 CONSOLIDATED ANALYSIS:', executionStart);
      if (executionEnd !== -1) {
        const executionSection = cleanMsg.substring(executionStart, executionEnd).trim();
        result += executionSection + '\n\n';
      }
    }

    // Extract Consolidated Analysis section
    const consolidatedStart = cleanMsg.indexOf('## 📊 CONSOLIDATED ANALYSIS:');
    if (consolidatedStart !== -1) {
      let consolidatedEnd = cleanMsg.length;
      
      // Find the end of consolidated analysis section
      const nextSectionStart = cleanMsg.indexOf('## 💡 FINAL RECOMMENDATIONS', consolidatedStart);
      if (nextSectionStart !== -1) {
        consolidatedEnd = nextSectionStart;
      } else {
        const nextSectionStart2 = cleanMsg.indexOf('## 🗺️', consolidatedStart);
        if (nextSectionStart2 !== -1) {
          consolidatedEnd = nextSectionStart2;
        } else {
          const nextSectionStart3 = cleanMsg.indexOf('---', consolidatedStart);
          if (nextSectionStart3 !== -1) {
            consolidatedEnd = nextSectionStart3;
          }
        }
      }

      const consolidatedSection = cleanMsg.substring(consolidatedStart, consolidatedEnd).trim();
      result += consolidatedSection + '\n\n';
    }

    // Extract Final Recommendations section
    const recommendationsStart = cleanMsg.indexOf('## 💡 FINAL RECOMMENDATIONS');
    if (recommendationsStart !== -1) {
      let recommendationsEnd = cleanMsg.length;
      
      const nextSectionStart = cleanMsg.indexOf('## 🗺️', recommendationsStart);
      if (nextSectionStart !== -1) {
        recommendationsEnd = nextSectionStart;
      } else {
        const nextSectionStart2 = cleanMsg.indexOf('---', recommendationsStart);
        if (nextSectionStart2 !== -1) {
          recommendationsEnd = nextSectionStart2;
        }
      }

      const recommendationsSection = cleanMsg.substring(recommendationsStart, recommendationsEnd).trim();
      result += recommendationsSection + '\n\n';
    }

    // If no detailed sections found, show a fallback
    if (!result.trim()) {
      return `📊 **Analysis Complete**\nOrchestrator analysis completed successfully.\n\nNo detailed consolidated analysis available for this response.`;
    }

    // Clean up the result
    return result
      .replace(/============================================================/g, '')
      .replace(/\n\s*\n\s*\n/g, '\n\n') // Remove excessive blank lines
      .trim();
  };

  const formatMessage = (msg: string) => {
    // Remove "You: " or "AI: " prefix for display
    const cleanMsg = msg.replace(/^(You: |AI: )/, "");
    
    // Check if this looks like an orchestrator report
    const isOrchestratorReport = cleanMsg.includes('🏦 Banking Intelligence Report') || 
                                cleanMsg.includes('DECOMPOSED TASKS') ||
                                cleanMsg.includes('EXECUTION PLAN') ||
                                cleanMsg.includes('CONSOLIDATED ANALYSIS');
    
    if (isOrchestratorReport) {
      // For orchestrator reports, extract only consolidated analysis
      return extractConsolidatedAnalysis(msg);
    }
    
    return cleanMsg;
  };

  const isUserMessage = (msg: string) => {
    return msg.startsWith("You:");
  };

  const getMessageTime = () => {
    return new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <div className="flex flex-col gap-4 mt-6">
      {/* Main Conversation Area */}
      <div className="bg-[#0F2C44] rounded-xl border border-[#1E3D55] shadow-md flex flex-col h-96">
        {/* Header */}
        <div className="flex justify-between items-center p-4 border-b border-[#1E3D55]">
          <h3 className="text-lg font-semibold flex items-center gap-2">
            <span className="text-blue-400 text-lg">💬</span>
            Conversation
            <span className="text-xs text-[#D9E3EA] opacity-60 ml-2">(Traditional Chat)</span>
          </h3>
          {messages.length > 0 && (
            <button 
              className="text-red-400 hover:text-red-300 text-sm flex items-center gap-1 px-2 py-1 rounded hover:bg-red-900/20 transition-colors" 
              onClick={clearChat}
            >
              <span className="text-xs">🗑️</span>
              Clear Chat
            </button>
          )}
        </div>

        {/* Messages Area */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {messages.length === 0 ? (
            <div className="text-center text-[#D9E3EA] opacity-70 mt-8">
              <span className="text-blue-400 text-4xl block mb-2">🤖</span>
              <p>Start a conversation with the AI assistant</p>
              <p className="text-xs mt-2 opacity-60">Messages will appear at the bottom like traditional chat</p>
            </div>
          ) : (
            <>
              {messages.map((msg, idx) => {
                const isUser = isUserMessage(msg);
                const formattedMessage = formatMessage(msg);
                
                return (
                  <div 
                    key={idx} 
                    data-message-index={idx}
                    className={`flex ${isUser ? "justify-end" : "justify-start"} animate-slide-in`}
                  >
                    <div className={`max-w-[95%] rounded-lg p-3 relative ${
                      isUser 
                        ? "bg-blue-600 text-white" 
                        : "bg-[#12283C] text-[#D9E3EA] border border-[#2B4C66]"
                    }`}>
                      {/* Copy button - only show for AI messages */}
                      {!isUser && (
                        <button
                          onClick={() => copyMessage(msg, idx)}
                          className="absolute top-2 right-2 p-1 rounded hover:bg-[#2B4C66] text-[#D9E3EA] hover:text-white transition-colors duration-200"
                          title="Copy message"
                        >
                          {copiedIndex === idx ? (
                            <Check size={14} className="text-green-400" />
                          ) : (
                            <Copy size={14} />
                          )}
                        </button>
                      )}
                      
                      <div className="flex items-start gap-2">
                        {!isUser && <span className="text-blue-400 mt-1 flex-shrink-0">🤖</span>}
                        {isUser && <span className="text-white mt-1 flex-shrink-0">👤</span>}
                        <div className="flex-1">
                          <div className="text-sm leading-relaxed pr-6 whitespace-pre-wrap font-mono">
                            {formattedMessage}
                          </div>
                          <span className="text-xs opacity-70 mt-1 block">
                            {getMessageTime()}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
              {/* Bottom reference for scrolling to latest messages */}
              <div ref={bottomRef} />
            </>
          )}
        </div>
      </div>

      {/* Orchestrator Logs Area - Shows detailed progress */}
      <div className="bg-[#0F1C2A] rounded-xl border border-[#1E3D55] shadow-md flex flex-col h-24 relative">
        {/* Clear Log button positioned like Clear Chat */}
        {orchestratorLogs.length > 0 && (
          <button 
            className="absolute top-2 right-2 text-red-400 hover:text-red-300 text-xs flex items-center gap-1 px-2 py-1 rounded hover:bg-red-900/20 transition-colors z-10 font-mono" 
            onClick={clearOrchestratorLogs}
            title="Clear orchestrator logs"
          >
            🗑️ Clear Log
          </button>
        )}
        
        {/* Logs Area - Shows detailed orchestrator progress */}
        <div className="flex-1 overflow-y-auto p-3 space-y-1">
          {/* Progress Bar */}
          {isStreaming && (
            <div className="mb-2">
              <div className="w-full bg-[#1A2B3D] rounded-full h-2">
                <div 
                  className="bg-green-400 h-2 rounded-full transition-all duration-300 ease-out"
                  style={{ width: `${streamingProgress}%` }}
                ></div>
              </div>
            </div>
          )}
          
          {orchestratorLogs.length === 0 ? (
            <div className="text-center text-[#D9E3EA] opacity-50 mt-2">
              <span className="text-green-400 text-lg block mb-1">📊</span>
              <p className="text-xs">Real-time research execution progress</p>
              <p className="text-xs mt-1 opacity-70">BankerResearchTool progress and workflow status</p>
            </div>
          ) : (
            <>
              {orchestratorLogs.map((log, idx) => (
                <div 
                  key={idx}
                  className="text-xs font-mono text-[#D9E3EA] bg-[#0A1520] rounded p-2 border border-[#1A2B3D] whitespace-pre-wrap leading-relaxed"
                >
                  {log}
                </div>
              ))}
              <div ref={logBottomRef} />
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default ChatScrollArea;