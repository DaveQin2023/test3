import { useState, useEffect } from 'react';

const ChatBox = () => {
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [hasMessages, setHasMessages] = useState(false);

  // Check if there are messages to determine layout
  useEffect(() => {
    const checkMessages = () => {
      const saved = localStorage.getItem("chat_history");
      if (saved) {
        try {
          const parsed = JSON.parse(saved);
          setHasMessages(Array.isArray(parsed) && parsed.length > 0);
        } catch (error) {
          setHasMessages(false);
        }
      } else {
        setHasMessages(false);
      }
    };

    checkMessages();
    
    const handleNewMessage = () => {
      checkMessages();
    };

    window.addEventListener("new_chat", handleNewMessage);
    return () => window.removeEventListener("new_chat", handleNewMessage);
  }, []);

  const handleSubmit = async () => {
    if (!input.trim() || loading) return;
    
    setLoading(true);
    try {
      const userMessage = `You: ${input}`;
      
      // Get existing chat history
      const existing = localStorage.getItem("chat_history");
      const history = existing ? JSON.parse(existing) : [];
      const updated = [...history, userMessage];
      
      // Save user message and dispatch event
      localStorage.setItem("chat_history", JSON.stringify(updated));
      window.dispatchEvent(new CustomEvent("new_chat", { detail: [userMessage] }));

      // Call the backend (fixed port to 8000)
      const res = await fetch('http://localhost:8000/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: input }),
      });

      if (!res.ok) {
        throw new Error(`HTTP error! status: ${res.status}`);
      }

      const data = await res.json();
      const aiReply = `AI: ${data.reply}`;
      
      // Save AI response and dispatch event
      const updatedFinal = [...updated, aiReply];
      localStorage.setItem("chat_history", JSON.stringify(updatedFinal));
      window.dispatchEvent(new CustomEvent("new_chat", { detail: [aiReply] }));
      
      setInput('');
    } catch (err) {
      console.error('Error fetching from backend:', err);
      
      // Add error message to chat
      const errorMessage = `AI: Sorry, I encountered an error. Please make sure the backend is running on port 8000 and try again.`;
      const existing = localStorage.getItem("chat_history");
      const history = existing ? JSON.parse(existing) : [];
      const withError = [...history, errorMessage];
      localStorage.setItem("chat_history", JSON.stringify(withError));
      window.dispatchEvent(new CustomEvent("new_chat", { detail: [errorMessage] }));
    } finally {
      setLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  return (
    <div className="bg-[#112B45] p-6 rounded-xl border border-[#1E3D55] shadow-md">
      {/* Only show header when there are messages (chat mode) */}
      {hasMessages && (
        <div className="flex items-center gap-2 mb-4">
          <span className="text-blue-400 text-xl">🤖</span>
          <h2 className="text-xl font-bold">How can I assist you today</h2>
        </div>
      )}
      
      <div className="flex items-center gap-3">
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyPress={handleKeyPress}
          className="flex-1 p-3 pr-12 rounded-lg bg-[#0F1923] text-white border border-[#2B4C66] focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-colors"
          placeholder={hasMessages ? "Continue the conversation..." : "Ask me anything about your banking portfolio..."}
          disabled={loading}
        />
        <button
          onClick={handleSubmit}
          disabled={loading || !input.trim()}
          className="bg-blue-600 hover:bg-blue-700 disabled:bg-gray-600 disabled:opacity-50 px-6 py-3 rounded-lg text-white font-medium transition-colors flex items-center gap-2"
        >
          {loading ? (
            <>
              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
              Thinking...
            </>
          ) : (
            <>
              <span className="text-lg">➤</span>
              Send
            </>
          )}
        </button>
      </div>
    </div>
  );
};

export default ChatBox;