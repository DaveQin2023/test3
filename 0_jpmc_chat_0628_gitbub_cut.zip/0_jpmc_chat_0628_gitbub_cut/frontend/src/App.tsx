import React, { useState } from "react";
import {
  Calendar,
  CheckSquare,
  Sparkles,
  Briefcase,
  Inbox,
  Link,
  Activity,
  Wrench,
  Compass,
  Microscope,
  Database,
  Lightbulb,
  FileText,
  Search
} from "lucide-react";
import Sidebar from "./components/Sidebar";
import ChatBox from "./components/ChatBox";
import ChatScrollArea from "./components/ChatScrollArea";

const App = () => {
  const [isResearching, setIsResearching] = useState(false);

  // Research Client execution function
  const executeResearchTool = async () => {
    console.log("Research Client button clicked!");
    
    if (isResearching) {
      console.log("Already researching, returning early");
      return;
    }
    
    console.log("Setting isResearching to true");
    setIsResearching(true);
    
    // Clear old conversation when starting new research
    localStorage.removeItem("chat_history");
    window.dispatchEvent(new CustomEvent("clear_chat"));
    
    // Add the user question to start fresh conversation
    const userQuestion = "You: Execute BankerResearchTool for NVDA stock analysis with comprehensive financial report";
    const updated = [userQuestion]; // Start with just the new question
    localStorage.setItem("chat_history", JSON.stringify(updated));
    
    // Dispatch with slight delay to ensure proper processing
    setTimeout(() => {
      window.dispatchEvent(new CustomEvent("new_chat", { detail: [userQuestion] }));
      console.log("Added user question to fresh conversation:", userQuestion);
    }, 100);
    
    try {
      console.log("Adding initial message to orchestrator logs...");
      // Add initial message to orchestrator logs instead of main chat
      const timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
      const initialLogEntry = `[${timestamp}] 🔬 Initiating Independent Banking Research Tool execution...`;
      window.dispatchEvent(new CustomEvent("orchestrator_log", { detail: initialLogEntry }));

      console.log("Making request to independent research backend on port 8001...");
      // Start the independent research process
      const startResponse = await fetch('http://localhost:8001/research-start', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ticker_symbol: 'NVDA'
        }),
      });

      console.log("Backend response status:", startResponse.status);

      if (!startResponse.ok) {
        throw new Error(`Failed to start research: ${startResponse.status}`);
      }

      const responseData = await startResponse.json();
      console.log("Backend response data:", responseData);

      console.log("Setting up EventSource for independent backend...");
      // Set up Server-Sent Events for real-time progress
      const eventSource = new EventSource('http://localhost:8001/research-stream');
      
      eventSource.onopen = function() {
        console.log("Independent research EventSource connection opened");
      };
      
      eventSource.onmessage = function(event) {
        console.log("Received EventSource message:", event.data);
        try {
          const data = JSON.parse(event.data);
          console.log("Parsed data:", data);
          
          if (data.type === 'step') {
            // Show progress step in orchestrator logs instead of main conversation
            const timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
            const logEntry = `[${timestamp}] ${data.message}`;
            
            // Dispatch to orchestrator logs
            window.dispatchEvent(new CustomEvent("orchestrator_log", { detail: logEntry }));
            console.log("Added step message to orchestrator logs:", data.message);
            
          } else if (data.type === 'result') {
            // Show final report in main conversation
            console.log("Processing final report, length:", data.message.length);
            
            // Modify the report to avoid orchestrator filtering
            let reportContent = data.message;
            reportContent = reportContent.replace(/## 🏦 Banking Intelligence Report/g, '## 🏦 Financial Research Report');
            reportContent = reportContent.replace(/ORCHESTRATOR_LOG:/g, 'RESEARCH_LOG:');
            reportContent = reportContent.replace(/ORCHESTRATOR_RESULT:/g, 'RESEARCH_RESULT:');
            reportContent = reportContent.replace(/orchestrator_used/g, 'research_tool_used');
            reportContent = reportContent.replace(/DECOMPOSED TASKS/g, 'RESEARCH TASKS');
            reportContent = reportContent.replace(/EXECUTION PLAN/g, 'ANALYSIS PLAN');
            reportContent = reportContent.replace(/CONSOLIDATED ANALYSIS/g, 'FINANCIAL ANALYSIS');
            
            // Add to main conversation at top
            const reportMessage = `AI: ${reportContent}`;
            const finalHistory = JSON.parse(localStorage.getItem("chat_history") || "[]");
            const finalUpdated = [reportMessage, ...finalHistory]; // Add to top
            localStorage.setItem("chat_history", JSON.stringify(finalUpdated));
            window.dispatchEvent(new CustomEvent("new_chat", { detail: [reportMessage] }));
            console.log("Added final report to main conversation");
            
            // Close the event source
            eventSource.close();
            setIsResearching(false);
            console.log("Research completed, EventSource closed");
            
          } else if (data.type === 'error') {
            // Show error message in main conversation
            const errorMessage = `AI: ❌ ${data.message}`;
            const errorHistory = JSON.parse(localStorage.getItem("chat_history") || "[]");
            const errorUpdated = [errorMessage, ...errorHistory]; // Add to top
            localStorage.setItem("chat_history", JSON.stringify(errorUpdated));
            window.dispatchEvent(new CustomEvent("new_chat", { detail: [errorMessage] }));
            console.log("Added error message to main conversation:", errorMessage);
            
            // Close the event source
            eventSource.close();
            setIsResearching(false);
          } else if (data.type === 'keepalive') {
            // Just ignore keepalive messages
            console.log("Received keepalive");
          }
          
        } catch (parseError) {
          console.error('Error parsing progress data:', parseError);
          console.error('Raw event data:', event.data);
        }
      };

      eventSource.onerror = function(error) {
        console.error('Independent research EventSource failed:', error);
        eventSource.close();
        
        const errorMessage = "AI: ❌ Lost connection to independent research progress stream";
        const errorHistory = JSON.parse(localStorage.getItem("chat_history") || "[]");
        const errorUpdated = [errorMessage, ...errorHistory]; // Add to top
        localStorage.setItem("chat_history", JSON.stringify(errorUpdated));
        window.dispatchEvent(new CustomEvent("new_chat", { detail: [errorMessage] }));
        setIsResearching(false);
      };

    } catch (error) {
      console.error('Independent research tool execution failed:', error);
      const errorMessage = `AI: ❌ Independent research tool execution failed: ${error.message}. Make sure the independent research backend is running on port 8001.`;
      const errorHistory = JSON.parse(localStorage.getItem("chat_history") || "[]");
      const errorUpdated = [errorMessage, ...errorHistory]; // Add to top
      localStorage.setItem("chat_history", JSON.stringify(errorUpdated));
      window.dispatchEvent(new CustomEvent("new_chat", { detail: [errorMessage] }));
      setIsResearching(false);
    }
  };

  return (
    <div className="flex min-h-screen bg-[#0B1D2D] text-white font-sans text-sm">
      {/* Sidebar */}
      <Sidebar />

      {/* Main Content */}
      <main className="flex-1 pt-4 px-10">
        {/* Header */}
        <div className="flex justify-center mb-6">
          <h1 className="text-2xl font-semibold">Welcome, John</h1>
        </div>
        
        {/* Chat Interface */}
        <div className="space-y-4">
          <ChatBox />
          <ChatScrollArea />
        </div>
      </main>

      {/* Right Panel */}
      <aside className="w-80 bg-[#0E2940] p-6 space-y-6 border-l border-[#1C3A52]">
        {/* To-Do List */}
        <div className="mt-10">
          <h3 className="text-md font-semibold mb-2 flex items-center gap-1">
            <CheckSquare size={16} /> To-Do List
          </h3>
          <ul className="text-sm space-y-1 text-[#D9E3EA]">
            <li><input type="checkbox" defaultChecked className="mr-2" /> Call Client B about renewal</li>
            <li><input type="checkbox" className="mr-2" /> Email Client A treasury in</li>
            <li><input type="checkbox" className="mr-2" /> Follow up on loan terms</li>
            <li><input type="checkbox" className="mr-2" /> Schedule treasury pitch for next week</li>
          </ul>
        </div>

        {/* Today's Calendar */}
        <div>
          <h3 className="text-md font-semibold mb-2 flex items-center gap-1">
            <Calendar size={16} /> Today's Calendar
          </h3>
          <ul className="text-sm space-y-1 text-[#D9E3EA]">
            <li>- 9:00 AM — Client call: Nova Inc</li>
            <li>- 1:30 PM — Internal credit committee</li>
            <li>- 4:00 PM — Pitch: ESG product</li>
          </ul>
        </div>

        {/* Inbox Highlights */}
        <div>
          <h3 className="text-md font-semibold mb-2 flex items-center gap-1">
            <Inbox size={16} /> Inbox Highlights
          </h3>
          <ul className="text-sm space-y-1 text-[#D9E3EA]">
            <li>- [Client] Term sheet review ready</li>
            <li>- [Legal] Draft contract updated</li>
          </ul>
        </div>

        {/* My Shortcuts */}
        <div>
          <h3 className="text-md font-semibold mb-2 flex items-center gap-1">
            <Link size={16} /> My Shortcuts
          </h3>
          <ul className="text-sm space-y-1 text-[#D9E3EA]">
            <li className="flex items-center gap-2 cursor-pointer hover:text-white transition-colors">
              <FileText size={16} /> Portfolio Management
            </li>
            <li className="flex items-center gap-2 cursor-pointer hover:text-white transition-colors">
              <Activity size={16} /> Engagement Center
            </li>
            <li className="flex items-center gap-2 cursor-pointer hover:text-white transition-colors">
              <Sparkles size={16} /> Smart Email Reply Assistant
            </li>
          </ul>
        </div>

        {/* Tools */}
        <div>
          <h3 className="text-md font-semibold mb-2 flex items-center gap-1">
            <Wrench size={16} /> Tools
          </h3>
          <ul className="text-sm space-y-1 text-[#D9E3EA]">
            <li className="flex items-center gap-2 cursor-pointer hover:text-white transition-colors">
              <Compass size={16} /> Explore Product
            </li>
            <li className="flex items-center gap-2 cursor-pointer hover:text-white transition-colors">
              <Search size={16} /> Search Document
            </li>
            <li 
              className={`flex items-center gap-2 cursor-pointer transition-colors ${
                isResearching 
                  ? 'text-blue-300 pointer-events-none' 
                  : 'hover:text-white'
              }`}
              onClick={executeResearchTool}
            >
              <Microscope size={16} className={isResearching ? 'animate-pulse' : ''} /> 
              {isResearching ? 'Researching Client...' : 'Research Client'}
              {isResearching && (
                <div className="w-4 h-4 border-2 border-blue-300 border-t-transparent rounded-full animate-spin ml-2"></div>
              )}
            </li>
            <li className="flex items-center gap-2 cursor-pointer hover:text-white transition-colors">
              <Database size={16} /> Show me
            </li>
            <li className="flex items-center gap-2 cursor-pointer hover:text-white transition-colors">
              <Lightbulb size={16} /> Generate Insights
            </li>
          </ul>
          {isResearching && (
            <p className="text-xs text-blue-400 mt-2 animate-pulse">
              Executing comprehensive financial analysis...
            </p>
          )}
        </div>
      </aside>
    </div>
  );
};

export default App;